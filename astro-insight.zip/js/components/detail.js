/* ============================================================
 * AstroInsight - Detail Screen Component（v5）
 * 要件§11 §12 §13 §18 共通の詳細画面：
 *   - ホロスコープ図SVG（ネイタル単独 ↔ 二重円切替）
 *   - 天体タップでツールチップ表示
 *   - AI生成テキスト（トランジット影響・アドバイス／相性総合読み解き）
 *   - 「AIに質問」ボタン → チャットへ文脈引き継ぎ遷移
 *   - 🔄更新ボタンで強制再生成
 *
 * 開き方:
 *   - openForToday({theme,summary,advice,impact,segment})  ← 「今日」サマリーカードから
 *   - openForForecast({period,theme,description,impact,forecastType})  ← 「予報」カードから
 *   - openForCompat(friend)  ← 「相性」リストカードから
 * ============================================================ */

class DetailComponent {
    constructor(app) {
        this.app = app;
        this.db = app.db;
        this.currentMode = null; // 'today' | 'forecast' | 'compat'
        this.currentPayload = null;
        this.currentFriend = null;
        this.renderer = null;
        this._tooltipEl = null;
    }

    _ensureRenderer() {
        if (this.renderer) return;
        const svg = document.getElementById('detail-horoscope-svg');
        if (!svg) return;
        this.renderer = new HoroscopeRenderer(svg, {
            size: 320,
            onPlanetTap: (key, ring) => this._showTooltip(key, ring)
        });
        // ツールチップ外タップで閉じる（要件§8）
        document.addEventListener('click', (e) => {
            if (this._tooltipEl && !this._tooltipEl.contains(e.target) && !e.target.closest('#detail-horoscope-svg')) {
                this._hideTooltip();
            }
        });
    }

    onClose() {
        this._hideTooltip();
        this.currentMode = null;
        this.currentPayload = null;
        this.currentFriend = null;
    }

    // ---- 「今日」から ----
    async openForToday(payload) {
        this.currentMode = 'today';
        this.currentPayload = payload;
        this.currentFriend = null;
        document.getElementById('detail-title').textContent = `${payload.segment === 'day' ? '今日' : payload.segment === 'week' ? '今週' : '今月'}の詳細`;
        this._ensureRenderer();
        // チャート: ネイタル + トランジット(現在)
        const profile = await this.db.get('profile') || {};
        const natal = AstrologyCompute.computeChart(profile, null);
        const transit = AstrologyCompute.computeChart(profile, new Date());
        this.renderer.setCharts(natal, transit, 'dual');
        // テキスト初期化
        document.getElementById('detail-text').innerHTML = '<p class="text-slate-400 text-sm">解説を生成中…</p>';
        this.app.ui.openDetail();
        // AI生成
        await this._generateForToday(payload);
    }

    async _generateForToday(payload) {
        const me = await this.app.profile.getProfileString();
        if (!me) return;
        if (!await this.app.auth.consumeTrial()) {
            document.getElementById('detail-text').innerHTML = '<p class="text-red-500 text-sm">ログインしてください。（無料試用は3回までです）</p>';
            return;
        }
        const sysPrompt = await this.app.config.getPrompt('prompt_detail');
        const period = payload.segment === 'day' ? '今日' : payload.segment === 'week' ? '今週' : '今月';
        const prompt = `${sysPrompt}\n\n【ネイタル】${me}\n【期間】${period}\n【サマリーテーマ】${payload.theme}\n【概要】${payload.summary || ''}\nこの人物の出生図に対する${period}の星の影響を、各天体のアスペクトとともに具体的に解説し、行動アドバイスを与えてください。`;
        const taskId = `detail-today-${Date.now()}`;
        await this.app.startGeneration({
            taskId,
            taskLabel: `${period}の詳細を解説中…`,
            prompt,
            isJson: false,
            onProgress: (text) => {
                document.getElementById('detail-text').innerHTML = marked.parse(text + ' ▍');
            },
            onDone: (text) => {
                document.getElementById('detail-text').innerHTML = marked.parse(text);
                this.app.snackbar.succeed(taskId, '✓ 解説を生成しました');
            },
            onError: (msg) => this.app.snackbar.fail(taskId, msg, () => this._generateForToday(payload))
        });
    }

    // ---- 「予報」から ----
    async openForForecast(payload) {
        this.currentMode = 'forecast';
        this.currentPayload = payload;
        this.currentFriend = null;
        document.getElementById('detail-title').textContent = `予報: ${payload.period}`;
        this._ensureRenderer();
        const profile = await this.db.get('profile') || {};
        const natal = AstrologyCompute.computeChart(profile, null);
        // 期間中心日のトランジット（簡易: 期間文字列から日付を推測できなければ「今」）
        const when = this._guessDateFromPeriod(payload.period) || new Date();
        const transit = AstrologyCompute.computeChart(profile, when);
        this.renderer.setCharts(natal, transit, 'dual');
        document.getElementById('detail-text').innerHTML = '<p class="text-slate-400 text-sm">解説を生成中…</p>';
        this.app.ui.openDetail();
        await this._generateForForecast(payload);
    }

    _guessDateFromPeriod(s) {
        if (!s) return null;
        // YYYY-MM 形式
        let m = s.match(/^(\d{4})-(\d{2})/);
        if (m) return new Date(parseInt(m[1]), parseInt(m[2]) - 1, 15);
        // MM/DD
        m = s.match(/^(\d{1,2})\/(\d{1,2})/);
        if (m) {
            const now = new Date();
            return new Date(now.getFullYear(), parseInt(m[1]) - 1, parseInt(m[2]));
        }
        return null;
    }

    async _generateForForecast(payload) {
        const me = await this.app.profile.getProfileString();
        if (!me) return;
        if (!await this.app.auth.consumeTrial()) {
            document.getElementById('detail-text').innerHTML = '<p class="text-red-500 text-sm">ログインしてください。（無料試用は3回までです）</p>';
            return;
        }
        const sysPrompt = await this.app.config.getPrompt('prompt_detail');
        const prompt = `${sysPrompt}\n\n【ネイタル】${me}\n【予報期間】${payload.period}\n【テーマ】${payload.theme}\n【概要】${payload.description}\nこの期間のトランジット詳細・アスペクト解説と、具体的な行動アドバイスを丁寧に記述してください。`;
        const taskId = `detail-forecast-${Date.now()}`;
        await this.app.startGeneration({
            taskId,
            taskLabel: '予報の詳細を解説中…',
            prompt,
            isJson: false,
            onProgress: (text) => {
                document.getElementById('detail-text').innerHTML = marked.parse(text + ' ▍');
            },
            onDone: (text) => {
                document.getElementById('detail-text').innerHTML = marked.parse(text);
                this.app.snackbar.succeed(taskId, '✓ 解説を生成しました');
            },
            onError: (msg) => this.app.snackbar.fail(taskId, msg, () => this._generateForForecast(payload))
        });
    }

    // ---- 「相性」から ----
    async openForCompat(friend) {
        this.currentMode = 'compat';
        this.currentFriend = friend;
        this.currentPayload = null;
        document.getElementById('detail-title').textContent = `${friend.name} さんとの相性`;
        this._ensureRenderer();
        const profile = await this.db.get('profile') || {};
        const me = AstrologyCompute.computeChart(profile, null);
        const them = AstrologyCompute.computeChart({ name: friend.name, date: friend.date, time: friend.time, place: friend.place }, null);
        this.renderer.setCharts(me, them, 'dual');
        // テキストエリア
        const txt = document.getElementById('detail-text');
        if (friend.compat) {
            txt.innerHTML = this._renderCompatHtml(friend.compat);
        } else {
            txt.innerHTML = '<p class="text-slate-400 text-sm">相性分析を生成中…</p>';
            // 自動再生成（未生成の場合）
            this.app.compat.generateCompatibility(friend);
        }
        this.app.ui.openDetail();
    }

    _renderCompatHtml(c) {
        const s = c.scores || {}, m = c.comments || {};
        const row = (label, key) => `
            <div class="flex items-center gap-3 mb-2">
                <div class="w-24 text-xs font-bold text-slate-700">${label}</div>
                <div class="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div class="h-full bg-astro" style="width:${Math.max(0, Math.min(100, parseInt(s[key] || 0)))}%"></div>
                </div>
                <div class="w-10 text-right text-sm font-bold text-astro">${parseInt(s[key] || 0)}</div>
            </div>
            <p class="text-xs text-slate-600 ml-24 mb-3">${this._esc(m[key] || '')}</p>
        `;
        const total = parseInt(s.total || 0);
        return `
            <div class="bg-white rounded-2xl border border-slate-100 p-4 mb-3">
                <div class="text-center mb-3">
                    <div class="text-xs text-slate-500">総合相性</div>
                    <div class="text-4xl font-bold text-astro">${total}</div>
                </div>
                ${row('💗 恋愛', 'romance')}
                ${row('🤝 友情', 'friendship')}
                ${row('💼 仕事', 'work')}
                ${row('💬 コミュニケーション', 'communication')}
            </div>
            <div class="bg-white rounded-2xl border border-slate-100 p-4 markdown-body">
                <h3>総合的な読み解き</h3>
                <p>${this._esc(c.summary || '')}</p>
            </div>`;
    }

    /** 🔄更新ボタン */
    refresh() {
        if (this.currentMode === 'today') this._generateForToday(this.currentPayload);
        else if (this.currentMode === 'forecast') this._generateForForecast(this.currentPayload);
        else if (this.currentMode === 'compat' && this.currentFriend) {
            this.app.compat.generateCompatibility(this.currentFriend);
        }
    }

    /** ホロスコープのモード切替（要件§8 ネイタル単独 ↔ 二重円） */
    toggleMode() {
        if (!this.renderer) return;
        const next = this.renderer.mode === 'dual' ? 'natal' : 'dual';
        this.renderer.setMode(next);
        const btn = document.getElementById('detail-mode-toggle');
        if (btn) btn.textContent = next === 'dual' ? '🪐 二重円' : '◯ ネイタルのみ';
    }

    /** 「AIに質問」 → チャットへ文脈引き継ぎ（要件§14） */
    async askInChat() {
        let context = '';
        if (this.currentMode === 'today' && this.currentPayload) {
            context = `今日(${this.currentPayload.segment})の運勢「${this.currentPayload.theme}」について`;
        } else if (this.currentMode === 'forecast' && this.currentPayload) {
            context = `予報「${this.currentPayload.period} - ${this.currentPayload.theme}」について`;
        } else if (this.currentMode === 'compat' && this.currentFriend) {
            context = `${this.currentFriend.name} さんとの相性について`;
        }
        this.app.chat.setContext(context);
        this.app.ui.closeDetail();
        this.app.ui.switchTab('chat');
    }

    // ---- 天体ツールチップ（要件§8） ----
    _showTooltip(planetKey, ring) {
        const info = this.renderer.getTooltipInfo(planetKey, ring);
        if (!info) return;
        if (this._tooltipEl) this._tooltipEl.remove();
        const el = document.createElement('div');
        el.className = 'fixed left-1/2 -translate-x-1/2 bottom-24 z-50 bg-white border border-slate-200 rounded-2xl shadow-2xl p-4 max-w-sm w-[90%] text-left';
        const aspectsHtml = info.aspects.length
            ? info.aspects.slice(0, 5).map((a) => `<li class="text-xs text-slate-600">${a.p1} <span style="color:${a.color}">${a.aspect}(${a.angle}°)</span> ${a.p2} (オーブ${a.orb}°)</li>`).join('')
            : '<li class="text-xs text-slate-400">主要アスペクトなし</li>';
        el.innerHTML = `
            <div class="flex justify-between items-start mb-2">
                <div>
                    <div class="text-2xl font-bold">${info.symbol} ${this._esc(info.name_ja)} <span class="text-xs text-slate-400">(${info.name_en})</span></div>
                    <div class="text-xs text-slate-500 mt-0.5">${info.signSymbol} ${this._esc(info.sign)} ${info.degInSign}° / ${info.house}ハウス${info.ring === 'B' ? '（外側）' : '（ネイタル）'}</div>
                </div>
                <button class="text-slate-400 text-xl leading-none">&times;</button>
            </div>
            <p class="text-xs text-slate-700 mb-2"><b>意味:</b> ${this._esc(info.meaning)}</p>
            <div class="text-xs">
                <b>主要アスペクト:</b>
                <ul class="mt-1 space-y-0.5">${aspectsHtml}</ul>
            </div>
        `;
        el.querySelector('button').addEventListener('click', () => this._hideTooltip());
        document.body.appendChild(el);
        this._tooltipEl = el;
    }

    _hideTooltip() {
        if (this._tooltipEl) { this._tooltipEl.remove(); this._tooltipEl = null; }
    }

    _esc(s) {
        return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }
}

window.DetailComponent = DetailComponent;
