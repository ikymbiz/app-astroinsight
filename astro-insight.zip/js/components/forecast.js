/* ============================================================
 * AstroInsight - Forecast Component（v5）
 * 要件§12：
 *   - 粒度: 月次/週次/日次/時間
 *   - 期間: 月次=2ヶ月前→1.5年後 / 週次=2ヶ月前→3ヶ月後 /
 *           日次=2ヶ月前→2週間後 / 時間=2日前→3日後
 *   - Chart.js 折れ線（現在地マーカー、過去グレーアウト、グラフ点タップでカード連動）
 *   - 期間カードに「詳細を見る」 → 詳細スライドイン
 *   - キャッシュキー: {uid}_forecast_{粒度}_{生成基準日}
 *   - 🔄更新ボタン（表示中の粒度のみ）
 * ============================================================ */

class ForecastComponent {
    constructor(app) {
        this.app = app;
        this.db = app.db;
        this.forecastType = 'monthly';
    }

    _baseDate() {
        return new Date().toISOString().slice(0, 10);
    }
    cacheKey() {
        return `forecast_${this.forecastType}_${this._baseDate()}`;
    }

    async load() {
        const c = await this.db.cacheGet(this.cacheKey());
        if (c) this._render(c.data);
        else this._renderEmpty();
    }

    async refresh() {
        await this.db.cacheDelete(this.cacheKey());
        this.generate();
    }

    async generate() {
        const p = await this.app.profile.getProfileString();
        if (!p) return alert('プロフィールを設定してください。');
        if (!await this.app.auth.consumeTrial()) {
            return alert('ログインしてください。\n（無料試用は3回までです）');
        }
        const info = {
            monthly: { desc: '2ヶ月前から1.5年後（月次、合計約20ヶ月）', fmt: 'YYYY-MM', count: 20 },
            weekly:  { desc: '2ヶ月前から3ヶ月後（週次、合計約20週）', fmt: 'YYYY年M月第W週', count: 20 },
            daily:   { desc: '2ヶ月前から2週間後（日次、合計約75日）', fmt: 'MM/DD', count: 30 },
            hourly:  { desc: '2日前から3日後（時間粒度、合計約30区間）', fmt: 'MM/DD HH:00', count: 30 }
        }[this.forecastType];
        const sysPrompt = await this.app.config.getPrompt('prompt_forecast');
        const prompt = `${sysPrompt}\n\nプロフィール: ${p}
【期間】${info.desc}
【出力】必ず以下のJSON配列のみ。Markdown修飾(\`\`\`json等)は一切不要。直接 [ から始めること。
[{"period":"期間文字列(${info.fmt})","impact":0-100の整数,"theme":"主要テーマ","description":"アドバイス"}]
要素数: ${info.count}個程度。`;
        const taskId = `forecast-${this.forecastType}`;
        await this.app.startGeneration({
            taskId,
            taskLabel: `予報（${this.forecastType}）を生成中…`,
            prompt,
            isJson: true,
            onDone: async (text) => {
                const data = this._parseJsonArray(text);
                if (!data) {
                    this.app.snackbar.fail(taskId, '解析失敗', () => this.generate());
                    return;
                }
                await this.db.cacheSet(this.cacheKey(), { data, ts: Date.now() });
                this._render(data);
                this.app.snackbar.succeed(taskId, '✓ 更新しました');
            },
            onError: (msg) => this.app.snackbar.fail(taskId, msg, () => this.generate())
        });
    }

    /** 「今日」タブを開いたときに裏で月次を生成（要件§17 プリフェッチ） */
    async prefetchMonthlyInBackground() {
        if (this._prefetched) return;
        this._prefetched = true;
        const old = this.forecastType;
        this.forecastType = 'monthly';
        const has = await this.db.cacheGet(this.cacheKey());
        this.forecastType = old;
        if (!has) {
            // 静かに実行（snackbarには出すが、UIはブロックしない）
            const tmp = this.forecastType;
            this.forecastType = 'monthly';
            this.generate().catch(() => {});
            this.forecastType = tmp;
        }
    }

    _parseJsonArray(text) {
        try {
            let clean = text.replace(/```json/gi, '').replace(/```/g, '').trim();
            const s = clean.indexOf('[');
            const e = clean.lastIndexOf(']');
            if (s !== -1 && e !== -1) clean = clean.substring(s, e + 1);
            const arr = JSON.parse(clean);
            if (Array.isArray(arr)) return arr;
            return null;
        } catch (e) { return null; }
    }

    _renderEmpty() {
        const cont = document.getElementById('forecast-cards');
        if (cont) cont.innerHTML = `<div class="text-center text-slate-400 py-6 w-full"><p class="text-sm">「予測開始」を押すと予測データを生成します。</p></div>`;
        const cv = document.getElementById('forecastChart');
        if (cv && this.app.chartInstance) {
            this.app.chartInstance.destroy();
            this.app.chartInstance = null;
        }
    }

    _render(data) {
        if (!data || !data.length) return;
        // グラフ
        const labels = data.map((d) => d.period);
        const impacts = data.map((d) => parseInt(d.impact) || 0);
        // 過去/未来判定（簡易: 半分を過去としてグレーアウト）
        const nowIdx = Math.floor(data.length / 3); // 「2ヶ月前から」始まるので、開始 0 - 1/3 が過去
        const colors = data.map((_, i) => i < nowIdx ? '#cbd5e1' : '#4f46e5');
        const ctx = document.getElementById('forecastChart').getContext('2d');
        if (this.app.chartInstance) this.app.chartInstance.destroy();
        const pointBg = data.map((_, i) => i === nowIdx ? '#ef4444' : '#fff');
        const pointRad = data.map((_, i) => i === nowIdx ? 8 : 4);

        this.app.chartInstance = new Chart(ctx, {
            type: 'line',
            data: {
                labels,
                datasets: [{
                    label: '影響度',
                    data: impacts,
                    borderColor: '#4f46e5',
                    backgroundColor: 'rgba(79,70,229,0.18)',
                    segment: {
                        borderColor: (c) => c.p0DataIndex < nowIdx ? '#cbd5e1' : '#4f46e5'
                    },
                    tension: 0.4,
                    fill: true,
                    pointBackgroundColor: pointBg,
                    pointBorderColor: '#4f46e5',
                    pointBorderWidth: 2,
                    pointRadius: pointRad
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: { y: { min: 0, max: 100 }, x: { ticks: { maxTicksLimit: 6 } } },
                plugins: { legend: { display: false } },
                animation: { duration: 400 },
                onClick: (evt, els) => {
                    if (!els || !els.length) return;
                    const idx = els[0].index;
                    const cont = document.getElementById('forecast-cards');
                    const card = cont?.children[idx];
                    if (card) card.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
            }
        });

        // カード
        const cont = document.getElementById('forecast-cards');
        if (!cont) return;
        cont.innerHTML = '';
        data.forEach((it, i) => {
            const card = document.createElement('div');
            const isPast = i < nowIdx;
            card.className = `bg-white rounded-2xl shadow-sm border border-slate-100 p-4 mb-3 border-l-4 ${isPast ? 'border-l-slate-300 opacity-70' : 'border-l-astro'}`;
            const impact = Math.max(0, Math.min(100, parseInt(it.impact || 0)));
            card.innerHTML = `
                <div class="flex justify-between items-center mb-2">
                    <h4 class="font-bold text-slate-800 text-sm">${this._esc(it.period)}</h4>
                    <span class="text-xs font-bold px-2 py-1 rounded-full ${isPast ? 'bg-slate-100 text-slate-500' : 'bg-astro-light text-astro border border-indigo-200'}">影響度: ${impact}</span>
                </div>
                <h5 class="text-sm font-bold ${isPast ? 'text-slate-500' : 'text-astro'} mb-1"><i class="fa-solid fa-star mr-1"></i>${this._esc(it.theme || '')}</h5>
                <p class="text-xs text-slate-600 leading-relaxed mb-2">${this._esc(it.description || '')}</p>
                <button class="w-full bg-slate-50 hover:bg-slate-100 text-astro border border-slate-200 font-bold py-1.5 rounded-lg text-xs transition active:scale-95">
                    <i class="fa-solid fa-arrow-right-long mr-1"></i> 詳細を見る
                </button>
            `;
            card.querySelector('button').addEventListener('click', () => {
                this.app.detail.openForForecast({ ...it, forecastType: this.forecastType });
            });
            cont.appendChild(card);
        });
    }

    _esc(s) {
        return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }
}

window.ForecastComponent = ForecastComponent;
