/* ============================================================
 * AstroInsight - Settings Component（v5）
 * 要件§15 通常設定 + §16 管理者設定 を実装する。
 *
 * 通常設定（§15）:
 *   - AIモデル設定（一覧、＋追加、APIキー、プロキシ対応モデルはログイン時にAPIキーをグレーアウト）
 *   - システムプロンプト設定（機能ごとに編集、デフォルトに戻す）
 *   - プロフィール管理（編集、ネイタル分析手動再生成）
 *   - アカウント管理（未ログイン:ログインボタン+試用回数 / ログイン済み:アカウント名+ログアウト+ゲスト→UID移行）
 *   - データ管理（バックアップDL/復元/全消去）
 *
 * 管理者設定（§16・isAdminのみ表示）:
 *   - フィーチャーフラグ（max_tokens, temperature, top_p, guest_trial_max, ads_enabled, premium_enabled, app_name 等）
 *   - APIキー（プロキシで使用する実APIキー）
 *   - プロキシ設定（ベースURL）
 *   - Firebase認証設定（apiKey, authDomain, projectId）
 *   - デフォルトプロンプトJSON管理
 * ============================================================ */

class SettingsComponent {
    constructor(app) {
        this.app = app;
        this.db = app.db;
    }

    async load() {
        await this._renderModelSection();
        await this._renderPromptSection();
        await this.app.profile.load();
        await this._renderAccountSection();
        this._renderAdminButton();
    }

    // ===================== AIモデル =====================
    async _renderModelSection() {
        const select = document.getElementById('set-model-select');
        if (!select) return;
        const models = await this.app.config.getMergedModels();
        const current = (await this.db.get('selected_model')) || (models[0]?.id || '');
        select.innerHTML = '';
        for (const m of models) {
            const op = document.createElement('option');
            op.value = m.id;
            op.textContent = m.name + (m.recommended ? ' ★' : '');
            if (m.id === current) op.selected = true;
            select.appendChild(op);
        }
        select.onchange = () => {
            this.db.set('selected_model', select.value);
            this._renderApiKeyField(select.value);
        };
        await this._renderApiKeyField(current);

        // 一覧（カスタムモデル削除・デフォルト非表示切替）
        const listEl = document.getElementById('set-model-list');
        if (listEl) {
            const all = this.app.config.getAllDefaultModels();
            const custom = (await this.db.get('custom_models')) || [];
            const hidden = (await this.db.get('hidden_default_models')) || [];
            listEl.innerHTML = '';
            const mkRow = (m, isCustom) => {
                const row = document.createElement('div');
                row.className = 'flex items-center justify-between bg-slate-50 rounded-lg px-3 py-2 mb-1 text-xs';
                const isHidden = hidden.includes(m.id);
                row.innerHTML = `
                    <div>
                        <div class="font-bold">${this._esc(m.name)}</div>
                        <div class="text-slate-500">${this._esc(m.id)} / ${this._esc(m.provider)}${m.proxySupported ? ' / proxy' : ''}</div>
                    </div>
                    <div class="flex gap-2">
                        ${isCustom
                            ? `<button class="del text-red-500 hover:text-red-700"><i class="fa-solid fa-trash"></i></button>`
                            : `<button class="hide ${isHidden ? 'text-slate-400' : 'text-astro'} hover:text-astro-dark"><i class="fa-solid fa-${isHidden ? 'eye-slash' : 'eye'}"></i></button>`}
                    </div>`;
                if (isCustom) {
                    row.querySelector('.del').addEventListener('click', async () => {
                        if (!confirm(`カスタムモデル "${m.name}" を削除しますか？`)) return;
                        await this.app.config.removeCustomModel(m.id);
                        await this._renderModelSection();
                    });
                } else {
                    row.querySelector('.hide').addEventListener('click', async () => {
                        await this.app.config.toggleDefaultHidden(m.id);
                        await this._renderModelSection();
                    });
                }
                listEl.appendChild(row);
            };
            all.forEach((m) => mkRow(m, false));
            custom.forEach((m) => mkRow(m, true));
        }
    }

    async _renderApiKeyField(modelId) {
        const input = document.getElementById('set-api-key');
        const note = document.getElementById('set-api-key-note');
        if (!input) return;
        const m = await this.app.config.getModelById(modelId);
        const apiKey = (await this.db.get(`apikey_${modelId}`)) || '';
        input.value = apiKey;
        const loggedIn = this.app.auth.isLoggedIn();
        const proxyOk = m && m.proxySupported && loggedIn && this.app.proxy.isConfigured();
        input.disabled = proxyOk; // 要件§15: ログイン+プロキシ対応モデルはグレーアウト
        if (note) note.textContent = proxyOk
            ? '（プロキシ経由のためAPIキーは任意です）'
            : '（このモデルにはAPIキーの入力が必要です）';
    }

    /** 「APIキー保存」ボタン */
    async saveApiKey() {
        const select = document.getElementById('set-model-select');
        const input = document.getElementById('set-api-key');
        if (!select || !input) return;
        await this.db.set(`apikey_${select.value}`, input.value);
        this.app.snackbar.start('save-key', 'APIキー保存中…');
        this.app.snackbar.succeed('save-key', '✓ APIキーを保存しました');
    }

    /** 「＋ モデル追加」フォーム送信（要件§4 §15） */
    async addCustomModel() {
        const id = document.getElementById('set-newmodel-id').value.trim();
        const name = document.getElementById('set-newmodel-name').value.trim();
        const provider = document.getElementById('set-newmodel-provider').value;
        const endpoint = document.getElementById('set-newmodel-endpoint').value.trim();
        const proxy = document.getElementById('set-newmodel-proxy').checked;
        if (!id || !name || !endpoint) return alert('ID・表示名・エンドポイントは必須です。');
        await this.app.config.addCustomModel({
            id, name, provider, endpoint, streaming: 'sse', recommended: false, proxySupported: proxy
        });
        // フォーム初期化
        ['set-newmodel-id', 'set-newmodel-name', 'set-newmodel-endpoint'].forEach((i) => {
            const e = document.getElementById(i); if (e) e.value = '';
        });
        await this._renderModelSection();
        this.app.snackbar.start('add-model', 'モデル追加中…');
        this.app.snackbar.succeed('add-model', '✓ モデルを追加しました');
    }

    // ===================== プロンプト =====================
    async _renderPromptSection() {
        const cont = document.getElementById('set-prompts');
        if (!cont) return;
        const prompts = await this.app.config.getAllCurrentPrompts();
        cont.innerHTML = '';
        for (const key of Object.keys(prompts)) {
            const p = prompts[key];
            const row = document.createElement('div');
            row.className = 'mb-3';
            row.innerHTML = `
                <div class="flex justify-between items-center mb-1">
                    <label class="text-xs font-bold text-slate-700">${this._esc(p.label)}</label>
                    <button data-reset="${this._esc(key)}" class="text-xs text-astro hover:text-astro-dark"><i class="fa-solid fa-rotate-left mr-1"></i>デフォルトに戻す</button>
                </div>
                <p class="text-[10px] text-slate-500 mb-1">${this._esc(p.description || '')}</p>
                <textarea data-key="${this._esc(key)}" rows="3" class="w-full text-xs p-2 border border-slate-300 rounded-lg">${this._esc(p.value || '')}</textarea>`;
            cont.appendChild(row);
            row.querySelector('textarea').addEventListener('blur', async (e) => {
                await this.app.config.saveUserPrompt(key, e.target.value);
            });
            row.querySelector('button').addEventListener('click', async () => {
                await this.app.config.resetUserPrompt(key);
                await this._renderPromptSection();
            });
        }
    }

    // ===================== プロフィール =====================
    async saveProfile() {
        await this.app.profile.save();
    }
    async regenerateNatal() {
        if (!confirm('ネイタル分析を再生成しますか？')) return;
        // キャッシュ削除→再生成
        const k = `natal_${await this.app.profile.getProfileHash()}`;
        await this.db.cacheDelete(k);
        await this.app.natal.generate();
    }

    // ===================== アカウント（要件§15） =====================
    async _renderAccountSection() {
        const el = document.getElementById('set-account');
        if (!el) return;
        const u = this.app.auth.user;
        if (u) {
            el.innerHTML = `
                <div class="flex items-center gap-3">
                    ${u.photoURL ? `<img src="${u.photoURL}" class="w-12 h-12 rounded-full">` : `<i class="fa-solid fa-user-circle text-4xl text-astro"></i>`}
                    <div class="flex-1">
                        <div class="font-bold text-slate-800">${this._esc(u.name || u.email || 'ユーザー')}</div>
                        <div class="text-xs text-slate-500">${this._esc(u.email || '')}</div>
                        ${u.isAdmin ? '<span class="text-[10px] bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full">管理者</span>' : ''}
                    </div>
                </div>
                <button id="btn-logout" class="mt-3 w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-2 rounded-xl text-sm"><i class="fa-solid fa-right-from-bracket mr-1"></i>ログアウト</button>`;
            el.querySelector('#btn-logout').addEventListener('click', async () => {
                await this.app.auth.signOut();
                location.reload();
            });
        } else {
            const remain = await this.app.auth.remainingTrials();
            el.innerHTML = `
                <p class="text-sm text-slate-700 mb-2">未ログインです。</p>
                <p class="text-xs text-slate-500 mb-3">無料試用 残り <b class="text-astro">${remain}</b> 回 / 上限3回</p>
                <button id="btn-login" class="w-full bg-astro hover:bg-astro-dark text-white font-bold py-2 rounded-xl text-sm"><i class="fa-brands fa-google mr-1"></i> Googleでログイン</button>
                <p class="text-[10px] text-slate-400 mt-2">ログインするとデータをアカウントに紐付けて永続化できます。</p>`;
            el.querySelector('#btn-login').addEventListener('click', () => this.app.auth.signInGoogle());
        }
    }

    // ===================== データ管理（要件§15） =====================
    async backupDownload() {
        // store / cache / friends / auth(local) を JSON で出力
        const out = { exportedAt: new Date().toISOString(), uidPrefix: this.db.getUidPrefix(), data: {} };
        const stores = ['store', 'cache', 'friends'];
        for (const s of stores) {
            out.data[s] = await this._dumpStore(s);
        }
        const blob = new Blob([JSON.stringify(out, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url; a.download = 'astroinsight-backup.json';
        a.click();
        URL.revokeObjectURL(url);
    }

    async restoreFromFile(file) {
        try {
            const txt = await file.text();
            const data = JSON.parse(txt);
            for (const s of Object.keys(data.data || {})) {
                for (const item of data.data[s]) {
                    await this.db.setRaw(s, item.key, item.value);
                }
            }
            alert('復元しました。');
            location.reload();
        } catch (e) {
            alert('復元に失敗しました: ' + e.message);
        }
    }

    async clearAllData() {
        if (!confirm('全データを削除します。本当によろしいですか？\n（バックアップを取っていない場合は復元できません）')) return;
        await this.db.clearAll();
        alert('削除しました。リロードします。');
        location.reload();
    }

    async _dumpStore(storeName) {
        if (!this.db.db) await this.db.init();
        return new Promise((res) => {
            const out = [];
            const tx = this.db.db.transaction(storeName);
            const o = tx.objectStore(storeName);
            const req = o.openCursor();
            req.onsuccess = (e) => {
                const cur = e.target.result;
                if (cur) { out.push({ key: cur.key, value: cur.value }); cur.continue(); }
                else res(out);
            };
            req.onerror = () => res([]);
        });
    }

    // ===================== 管理者（要件§16） =====================
    _renderAdminButton() {
        const el = document.getElementById('set-admin-btn');
        if (!el) return;
        if (this.app.auth.isAdmin()) {
            el.classList.remove('hidden');
            el.onclick = () => this.openAdminPanel();
        } else {
            el.classList.add('hidden');
        }
    }

    async openAdminPanel() {
        const panel = document.getElementById('admin-panel');
        if (!panel) return;
        const flags = this.app.flags.flags;
        const adminCfg = (await this.db.getRaw('auth', 'admin_config')) || {};
        const fb = (await this.db.getRaw('auth', 'firebase_config')) || {};
        const apiKeys = (await this.db.getRaw('auth', 'admin_api_keys')) || {};
        panel.classList.remove('hidden');
        panel.innerHTML = `
            <div class="space-y-4">
                <div class="bg-white rounded-xl p-3 border border-slate-200">
                    <h3 class="font-bold text-sm mb-2">📊 フィーチャーフラグ</h3>
                    <label class="text-xs">max_tokens <input id="adm-max-tokens" class="w-full text-xs border p-1 rounded" type="number" value="${flags.ai_max_tokens}"></label>
                    <label class="text-xs">temperature <input id="adm-temp" class="w-full text-xs border p-1 rounded" type="number" step="0.1" value="${flags.ai_temperature}"></label>
                    <label class="text-xs">top_p <input id="adm-top-p" class="w-full text-xs border p-1 rounded" type="number" step="0.05" value="${flags.ai_top_p}"></label>
                    <label class="text-xs">未ログイン試用回数上限 <input id="adm-trial" class="w-full text-xs border p-1 rounded" type="number" value="${flags.guest_trial_max}"></label>
                    <label class="text-xs flex items-center gap-2 mt-1"><input id="adm-ads" type="checkbox" ${flags.ads_enabled ? 'checked' : ''}> ADS_ENABLED</label>
                    <label class="text-xs flex items-center gap-2"><input id="adm-premium" type="checkbox" ${flags.premium_enabled ? 'checked' : ''}> PREMIUM_ENABLED (スタブ・常にtrue推奨)</label>
                    <label class="text-xs">アプリ名 <input id="adm-app-name" class="w-full text-xs border p-1 rounded" value="${this._esc(flags.app_name)}"></label>
                    <button id="adm-save-flags" class="mt-2 w-full bg-astro text-white text-xs font-bold py-2 rounded-lg">保存</button>
                </div>

                <div class="bg-white rounded-xl p-3 border border-slate-200">
                    <h3 class="font-bold text-sm mb-2">☁️ Cloudflareプロキシ</h3>
                    <label class="text-xs">ベースURL <input id="adm-proxy-url" class="w-full text-xs border p-1 rounded" value="${this._esc(adminCfg.proxy_base_url || '')}" placeholder="https://your-worker.example.workers.dev"></label>
                    <button id="adm-save-proxy" class="mt-2 w-full bg-astro text-white text-xs font-bold py-2 rounded-lg">保存</button>
                </div>

                <div class="bg-white rounded-xl p-3 border border-slate-200">
                    <h3 class="font-bold text-sm mb-2">🔑 プロキシ用APIキー（フロント露出なし、ローカル保管のみ）</h3>
                    <label class="text-xs">Google <input id="adm-key-google" class="w-full text-xs border p-1 rounded" type="password" value="${this._esc(apiKeys.google || '')}"></label>
                    <label class="text-xs">Anthropic <input id="adm-key-anthropic" class="w-full text-xs border p-1 rounded" type="password" value="${this._esc(apiKeys.anthropic || '')}"></label>
                    <label class="text-xs">OpenAI <input id="adm-key-openai" class="w-full text-xs border p-1 rounded" type="password" value="${this._esc(apiKeys.openai || '')}"></label>
                    <label class="text-xs">xAI <input id="adm-key-xai" class="w-full text-xs border p-1 rounded" type="password" value="${this._esc(apiKeys.xai || '')}"></label>
                    <button id="adm-save-keys" class="mt-2 w-full bg-astro text-white text-xs font-bold py-2 rounded-lg">保存</button>
                </div>

                <div class="bg-white rounded-xl p-3 border border-slate-200">
                    <h3 class="font-bold text-sm mb-2">🔐 Firebase認証設定</h3>
                    <label class="text-xs">apiKey <input id="adm-fb-key" class="w-full text-xs border p-1 rounded" value="${this._esc(fb.apiKey || '')}"></label>
                    <label class="text-xs">authDomain <input id="adm-fb-dom" class="w-full text-xs border p-1 rounded" value="${this._esc(fb.authDomain || '')}"></label>
                    <label class="text-xs">projectId <input id="adm-fb-pid" class="w-full text-xs border p-1 rounded" value="${this._esc(fb.projectId || '')}"></label>
                    <button id="adm-save-fb" class="mt-2 w-full bg-astro text-white text-xs font-bold py-2 rounded-lg">保存</button>
                </div>

                <div class="bg-white rounded-xl p-3 border border-slate-200">
                    <h3 class="font-bold text-sm mb-2">📜 デフォルトプロンプトJSON管理</h3>
                    <textarea id="adm-prompts-json" rows="6" class="w-full text-[10px] border p-1 rounded font-mono"></textarea>
                    <div class="flex gap-2 mt-2">
                        <button id="adm-load-prompts" class="flex-1 bg-slate-100 text-xs font-bold py-2 rounded-lg">現在の値を読込</button>
                        <button id="adm-save-prompts" class="flex-1 bg-astro text-white text-xs font-bold py-2 rounded-lg">配布として保存</button>
                    </div>
                </div>

                <button id="adm-close" class="w-full bg-slate-200 text-slate-700 font-bold py-2 rounded-xl text-sm">閉じる</button>
            </div>`;

        // バインド
        panel.querySelector('#adm-save-flags').addEventListener('click', async () => {
            await this.app.flags.save({
                ai_max_tokens: parseInt(panel.querySelector('#adm-max-tokens').value),
                ai_temperature: parseFloat(panel.querySelector('#adm-temp').value),
                ai_top_p: parseFloat(panel.querySelector('#adm-top-p').value),
                guest_trial_max: parseInt(panel.querySelector('#adm-trial').value),
                ads_enabled: panel.querySelector('#adm-ads').checked,
                premium_enabled: panel.querySelector('#adm-premium').checked,
                app_name: panel.querySelector('#adm-app-name').value
            });
            this.app.ads.refresh();
            this.app.snackbar.start('flags', '保存中…'); this.app.snackbar.succeed('flags', '✓ フィーチャーフラグを保存');
        });
        panel.querySelector('#adm-save-proxy').addEventListener('click', async () => {
            await this.app.proxy.setBaseUrl(panel.querySelector('#adm-proxy-url').value.trim());
            this.app.snackbar.start('proxy', '保存中…'); this.app.snackbar.succeed('proxy', '✓ プロキシURLを保存');
        });
        panel.querySelector('#adm-save-keys').addEventListener('click', async () => {
            const obj = {
                google: panel.querySelector('#adm-key-google').value,
                anthropic: panel.querySelector('#adm-key-anthropic').value,
                openai: panel.querySelector('#adm-key-openai').value,
                xai: panel.querySelector('#adm-key-xai').value
            };
            await this.db.setRaw('auth', 'admin_api_keys', obj);
            this.app.snackbar.start('keys', '保存中…'); this.app.snackbar.succeed('keys', '✓ APIキーを保存');
        });
        panel.querySelector('#adm-save-fb').addEventListener('click', async () => {
            const obj = {
                apiKey: panel.querySelector('#adm-fb-key').value.trim(),
                authDomain: panel.querySelector('#adm-fb-dom').value.trim(),
                projectId: panel.querySelector('#adm-fb-pid').value.trim()
            };
            await this.db.setRaw('auth', 'firebase_config', obj);
            this.app.snackbar.start('fb', '保存中…'); this.app.snackbar.succeed('fb', '✓ Firebase設定を保存。リロードして反映してください');
        });
        panel.querySelector('#adm-load-prompts').addEventListener('click', async () => {
            const all = this.app.config.getAllPromptDefs();
            const out = {};
            for (const k of Object.keys(all)) out[k] = all[k];
            panel.querySelector('#adm-prompts-json').value = JSON.stringify(out, null, 2);
        });
        panel.querySelector('#adm-save-prompts').addEventListener('click', async () => {
            try {
                const o = JSON.parse(panel.querySelector('#adm-prompts-json').value);
                await this.db.setRaw('auth', 'distributed_prompts', { prompts: o, updated_at: new Date().toISOString() });
                this.app.snackbar.start('p', '保存中…'); this.app.snackbar.succeed('p', '✓ デフォルトプロンプトを配布保存');
            } catch (e) {
                alert('JSONパース失敗: ' + e.message);
            }
        });
        panel.querySelector('#adm-close').addEventListener('click', () => panel.classList.add('hidden'));
    }

    _esc(s) {
        return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }
}

window.SettingsComponent = SettingsComponent;
