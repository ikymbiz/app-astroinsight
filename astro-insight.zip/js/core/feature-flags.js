/* ============================================================
 * AstroInsight - Feature Flags（v5）
 * 要件§3 §16 §22 を実装する：
 *   - ADS_ENABLED(uid): 広告表示の一括ON/OFF。管理者は常にfalse。
 *   - PREMIUM_ENABLED(uid): スタブ。常にtrue（全機能を全ユーザーに開放、要件§3「課金UI実装しない」）。
 *   - 管理者設定で上書き可能。Firestore/CloudflareKV移行時はここのfetch先を差し替えるだけ。
 *
 * 管理可能な変数（要件§16）:
 *   - max_tokens, temperature, top_p
 *   - guest_trial_max（未ログイン試用回数上限。デフォルト3）
 *   - ads_enabled
 *   - premium_enabled（スタブ）
 *   - app_name, app_description, theme_color
 *   - cache_ttl
 * ============================================================ */

class FeatureFlags {
    constructor(db, auth) {
        this.db = db;
        this.auth = auth;
        this.flags = this._defaults();
    }

    _defaults() {
        return {
            ads_enabled: true,
            premium_enabled: true, // 要件§3：常にtrue（全機能開放）
            guest_trial_max: 3,
            ai_max_tokens: 4096,
            ai_temperature: 0.7,
            ai_top_p: 1.0,
            app_name: 'AstroInsight',
            app_description: 'AI占星術＆自己分析',
            theme_color: '#4f46e5',
            cache_ttl_seconds: 3600 * 24 * 7 // 1週間
        };
    }

    /** 起動時に管理者設定を反映（要件§16「アプリ起動時に取得」） */
    async load() {
        const admin = (await this.db.getRaw('auth', 'feature_flags')) || {};
        this.flags = Object.assign(this._defaults(), admin);
        // guest_trial_maxを authサービス側にも伝える
        if (this.auth) await this.db.setRaw('auth', 'guest_trial_max', this.flags.guest_trial_max);
    }

    /** 管理者画面から保存 */
    async save(partial) {
        const admin = (await this.db.getRaw('auth', 'feature_flags')) || {};
        const next = Object.assign({}, admin, partial);
        await this.db.setRaw('auth', 'feature_flags', next);
        await this.load();
    }

    get(key) {
        return this.flags[key];
    }

    /** 要件§3 ADS_ENABLED(uid) */
    ADS_ENABLED(uid) {
        if (this.auth?.isAdmin()) return false; // 管理者は広告非表示
        return !!this.flags.ads_enabled;
    }

    /** 要件§3 §22 PREMIUM_ENABLED(uid) スタブ。常にtrue */
    PREMIUM_ENABLED(uid) {
        return !!this.flags.premium_enabled;
    }
}

window.FeatureFlags = FeatureFlags;
