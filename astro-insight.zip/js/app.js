/* ============================================================
 * AstroInsight - Main App（v5）
 * 全体のオーケストレーション。要件§1 §2 §17 §20 §22 等を統合。
 *
 * 起動順:
 *   1) DB init → guest_temp クリア
 *   2) Auth init（Firebase/モック復元）
 *   3) FeatureFlags load
 *   4) Proxy init
 *   5) Config loadDefaults
 *   6) 各コンポーネントのload
 *   7) UIController setupEventListeners
 *   8) Onboarding maybeShow（プロフ未保存なら表示） / 保存済みなら今日タブへ
 * ============================================================ */

class AstroApp {
    constructor() {
        this.db = new AstroDB();
        this.auth = new AuthService(this.db);
        this.proxy = new ProxyService(this.db);
        this.flags = new FeatureFlags(this.db, this.auth);
        this.snackbar = new Snackbar();
        this.config = new ConfigLoader(this.db);
        this.workerMgr = new AIWorkerManager('./js/workers/ai-worker.js', 4);

        this.ui = new UIController(this);
        this.profile = new ProfileComponent(this);
        this.natal = new NatalComponent(this);
        this.today = new TodayComponent(this);
        this.forecast = new ForecastComponent(this);
        this.compat = new CompatComponent(this);
        this.chat = new ChatComponent(this);
        this.detail = new DetailComponent(this);
        this.settings = new SettingsComponent(this);
        this.onboarding = new OnboardingComponent(this);
        this.ads = new AdsComponent(this);

        this.chartInstance = null;
        this._wakeLock = null;
    }

    async init() {
        await this.db.init();
        await this.auth.init();
        await this.flags.load();
        await this.proxy.init();
        await this.config.loadDefaults();
        // 認証状態が変わったらUI更新
        this.auth.onChange(() => {
            this.settings._renderAccountSection?.();
            this.ads.refresh();
        });
        // 初期データロード
        await this.settings.load();
        await this.profile.load();
        await this.natal.load();
        await this.today.load();
        await this.forecast.load();
        await this.compat.load();
        await this.chat.load();
        // UIイベント
        this.ui.setupEventListeners();
        // 広告
        this.ads.refresh();
        // オンボーディング判定（要件§9）
        const showed = await this.onboarding.maybeShow();
        if (!showed) this.ui.switchTab('today');
    }

    // ==========================================================
    // 統合: AI生成エントリーポイント（要件§20 ルーティング）
    // ==========================================================
    /**
     * @param {Object} opts - {
     *   taskId, taskLabel, prompt, isJson,
     *   onProgress(text), onDone(text), onError(msg)
     * }
     */
    async startGeneration(opts) {
        const { taskId, taskLabel, prompt, isJson } = opts;
        const modelId = (await this.db.get('selected_model')) || 'gemini-2.5-flash';
        const modelMeta = await this.config.getModelById(modelId);
        if (!modelMeta) {
            opts.onError && opts.onError('モデルが見つかりません: ' + modelId);
            return;
        }
        // ルーティング判定
        const loggedIn = this.auth.isLoggedIn();
        const useProxy = this.proxy.canUseProxy(modelMeta, loggedIn);
        const proxyReq = useProxy ? this.proxy.buildProxyRequest(modelMeta) : null;
        const apiKey = (await this.db.get(`apikey_${modelId}`)) || '';
        if (!useProxy && !apiKey) {
            opts.onError && opts.onError(`APIキーが未設定です。設定画面で「${modelMeta.name}」のAPIキーを入力してください。`);
            return;
        }
        // スナックバー開始（要件§17）
        this.snackbar.start(taskId, taskLabel || '生成中…');
        // Wake Lock（要件§20 生成中スリープ防止）
        this._acquireWakeLock();

        this.workerMgr.submit(taskId, {
            apiKey, model: modelId, modelMeta, prompt, isJson, proxy: proxyReq
        }, {
            onChunk: (msg) => {
                if (typeof opts.onProgress === 'function') opts.onProgress(msg.text);
                this.snackbar.update(taskId, taskLabel + '…');
            },
            onDone: (msg) => {
                opts.onDone && opts.onDone(msg.text);
                if (this.workerMgr.active.size === 0) this._releaseWakeLock();
            },
            onError: (msg) => {
                opts.onError && opts.onError(msg.message);
                if (this.workerMgr.active.size === 0) this._releaseWakeLock();
            }
        });
    }

    async _acquireWakeLock() {
        if (this._wakeLock || !('wakeLock' in navigator)) return;
        try {
            this._wakeLock = await navigator.wakeLock.request('screen');
        } catch (e) {}
    }
    _releaseWakeLock() {
        if (this._wakeLock) {
            try { this._wakeLock.release(); } catch (e) {}
            this._wakeLock = null;
        }
    }

    handleChatSubmit(e) {
        return this.chat.handleSubmit(e);
    }
}

// 起動
window.addEventListener('DOMContentLoaded', async () => {
    window.app = new AstroApp();
    await window.app.init();
    // PWA（要件§1）
    if ('serviceWorker' in navigator) {
        try { await navigator.serviceWorker.register('./sw.js'); } catch (e) {}
    }
});
