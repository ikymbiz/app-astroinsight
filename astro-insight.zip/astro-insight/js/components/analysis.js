/* ============================================================
 * AstroInsight - Analysis Component
 * 既存 AstroApp.loadAnalysis / generateAnalysis / resumeGeneration / checkResumeState を分離独立化。
 * 機能キー: prompt_natal を使用。
 * ============================================================ */

class AnalysisComponent {
    /** @param {AstroApp} app */
    constructor(app) {
        this.app = app;
        this.db = app.db;
    }

    async load() {
        const res = await this.db.get('analysis_result');
        if (res) document.getElementById('analysis-result').innerHTML = marked.parse(res);
    }

    async generate() {
        const p = this.app.profile.getProfileString();
        if (!p) return alert('プロフィールを入力してください。');
        // システムプロンプト（ネイタル）を取得
        const sysPrompt = await this.app.config.getPrompt('prompt_natal');
        const prompt = `${sysPrompt}\n\n以下のプロフィールから自己分析を行ってください。専門用語は避け絵文字を使ってください。\nプロフィール: ${p}`;
        document.getElementById('analysis-result').innerHTML = '';
        this.app.startGeneration('analysis', prompt, false);
    }

    async checkResumeState() {
        const s = await this.db.get('resume_state');
        if (s && s.text && s.task === 'analysis')
            document.getElementById('resume-notice').classList.remove('hidden');
    }

    async resume() {
        const s = await this.db.get('resume_state');
        if (s && s.task === 'analysis') {
            document.getElementById('resume-notice').classList.add('hidden');
            document.getElementById('analysis-result').innerHTML =
                marked.parse(s.text) + '\n*(中断)*';
            this.app.ui.switchTab('analysis');
        }
    }
}

window.AnalysisComponent = AnalysisComponent;
