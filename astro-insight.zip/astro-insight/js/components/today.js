/* ============================================================
 * AstroInsight - Today Component
 * 既存 AstroApp.generateToday を分離独立化。
 * 機能キー: prompt_today を使用。
 * ============================================================ */

class TodayComponent {
    /** @param {AstroApp} app */
    constructor(app) {
        this.app = app;
        this.db = app.db;
    }

    async generate(type) {
        const p = this.app.profile.getProfileString();
        if (!p) return alert('プロフィールを設定してください。');
        const period = type === 'day' ? '今日1日' : '今週1週間';
        const sysPrompt = await this.app.config.getPrompt('prompt_today');
        const prompt = `${sysPrompt}\n\nプロフィール情報（ネイタル）に対し、${period}の星の配置（トランジット）の影響を分析し、運勢とアドバイスを出力してください。\nプロフィール: ${p}`;
        document.getElementById('today-result').innerHTML = '';
        this.app.startGeneration('today', prompt, false);
    }
}

window.TodayComponent = TodayComponent;
