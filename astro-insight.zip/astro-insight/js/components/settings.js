/* ============================================================
 * AstroInsight - Settings Component
 * 既存 AstroApp.loadSettings / saveSettings / getActiveAIConfig /
 * exportData / importData / syncToFileSystem / clearAllData を分離独立化。
 *
 * 拡張：
 *  - models.json をベースにしたモデル選択リスト動的生成
 *  - カスタムモデルの追加・削除・デフォルトモデル非表示切替
 *  - システムプロンプトの機能ごとの個別編集UI
 * ============================================================ */

class SettingsComponent {
    /** @param {AstroApp} app */
    constructor(app) {
        this.app = app;
        this.db = app.db;
        this.config = app.config;
    }

    /** 起動時に呼ばれる：設定UIにDB値を反映 */
    async load() {
        await this.renderModelSelect();
        await this.renderPromptEditors();
        await this.renderCustomModelsList();

        const settings =
            (await this.db.get('settings')) || { model: 'gemini-2.5-flash', keys: {}, prompt: '' };
        const sel = document.getElementById('api-model-select');
        if (sel) {
            // セレクトに含まれているモデルなら選択、そうでなければ先頭を選択
            const exists = Array.from(sel.options).some((o) => o.value === settings.model);
            sel.value = exists ? settings.model : sel.options[0]?.value || '';
        }
        document.getElementById('api-key-input').value = settings.keys?.[sel.value] || '';
        document.getElementById('system-prompt-input').value = settings.prompt || '';

        // モデル切替時にAPIキー入力欄を自動更新（既存挙動）
        sel.addEventListener('change', async (e) => {
            const model = e.target.value;
            const s = (await this.db.get('settings')) || { keys: {} };
            document.getElementById('api-key-input').value = s.keys?.[model] || '';
        });
    }

    /** models.json + カスタムモデル をマージしてセレクトを再構築 */
    async renderModelSelect() {
        const sel = document.getElementById('api-model-select');
        if (!sel) return;
        const models = await this.config.getMergedModels();
        sel.innerHTML = models
            .map(
                (m) =>
                    `<option value="${m.id}">${m.name}${
                        m.recommended ? '' : ''
                    }</option>`
            )
            .join('');
    }

    /** 機能ごとのシステムプロンプト編集UIを生成 */
    async renderPromptEditors() {
        const container = document.getElementById('prompt-editors');
        if (!container) return;
        const all = await this.config.getAllCurrentPrompts();
        container.innerHTML = '';
        for (const key of Object.keys(all)) {
            const item = all[key];
            const wrap = document.createElement('div');
            wrap.className = 'border-t border-slate-100 pt-3';
            wrap.innerHTML = `
                <div class="flex justify-between items-center mb-1">
                    <label class="text-xs font-bold text-slate-700">${item.label}</label>
                    <button data-key="${key}" class="prompt-reset-btn text-[10px] text-slate-500 underline">デフォルトに戻す</button>
                </div>
                <textarea data-key="${key}" rows="3"
                    class="prompt-editor w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs outline-none focus:ring-2 focus:ring-astro"
                    placeholder="${item.description || ''}">${this._esc(item.value)}</textarea>
            `;
            container.appendChild(wrap);
        }
        // textarea変更で保存（debounce）
        container.querySelectorAll('.prompt-editor').forEach((ta) => {
            ta.addEventListener(
                'input',
                this.app.debounce(async (ev) => {
                    const key = ev.target.dataset.key;
                    await this.config.saveUserPrompt(key, ev.target.value);
                }, 700)
            );
        });
        // リセットボタン
        container.querySelectorAll('.prompt-reset-btn').forEach((btn) => {
            btn.addEventListener('click', async (ev) => {
                ev.preventDefault();
                const key = btn.dataset.key;
                await this.config.resetUserPrompt(key);
                await this.renderPromptEditors();
            });
        });
    }

    /** カスタムモデル一覧 + 非表示トグル UI を再描画 */
    async renderCustomModelsList() {
        const container = document.getElementById('custom-models-list');
        if (!container) return;

        const customs = (await this.db.get('custom_models')) || [];
        const hidden = (await this.db.get('hidden_default_models')) || [];
        const defaults = this.config.getAllDefaultModels();

        let html = '<div class="text-xs font-bold text-slate-700 mb-1">デフォルトモデル（非表示切替）</div>';
        html += '<ul class="space-y-1 mb-3">';
        for (const m of defaults) {
            const isHidden = hidden.includes(m.id);
            html += `
                <li class="flex justify-between items-center text-xs bg-slate-50 px-2 py-1 rounded">
                    <span class="${isHidden ? 'line-through text-slate-400' : 'text-slate-700'}">${m.name} <span class="text-[10px] text-slate-400">[${m.id}]</span></span>
                    <button data-action="toggle-hidden" data-id="${m.id}" class="text-[10px] underline ${isHidden ? 'text-emerald-600' : 'text-red-500'}">${isHidden ? '表示' : '非表示'}</button>
                </li>`;
        }
        html += '</ul>';

        html += '<div class="text-xs font-bold text-slate-700 mb-1">カスタムモデル</div>';
        if (customs.length === 0) {
            html += '<div class="text-[11px] text-slate-400 mb-2">カスタムモデルはまだありません。</div>';
        } else {
            html += '<ul class="space-y-1 mb-2">';
            for (const m of customs) {
                html += `
                    <li class="flex justify-between items-center text-xs bg-amber-50 px-2 py-1 rounded">
                        <span class="text-slate-700">${m.name} <span class="text-[10px] text-slate-400">[${m.id}] (${m.provider})</span></span>
                        <button data-action="remove-custom" data-id="${m.id}" class="text-[10px] underline text-red-500">削除</button>
                    </li>`;
            }
            html += '</ul>';
        }

        container.innerHTML = html;

        container.querySelectorAll('button[data-action]').forEach((btn) => {
            btn.addEventListener('click', async (e) => {
                e.preventDefault();
                const action = btn.dataset.action;
                const id = btn.dataset.id;
                if (action === 'toggle-hidden') await this.config.toggleDefaultHidden(id);
                else if (action === 'remove-custom') {
                    if (!confirm(`カスタムモデル「${id}」を削除しますか？`)) return;
                    await this.config.removeCustomModel(id);
                }
                await this.renderModelSelect();
                await this.renderCustomModelsList();
            });
        });
    }

    /** 「＋ モデルを追加」フォーム送信時 */
    async addCustomModel() {
        const id = document.getElementById('add-model-id').value.trim();
        const name = document.getElementById('add-model-name').value.trim();
        const provider = document.getElementById('add-model-provider').value;
        const endpoint = document.getElementById('add-model-endpoint').value.trim();
        const proxySupported = document.getElementById('add-model-proxy').checked;
        if (!id || !name || !provider) return alert('モデルID・表示名・プロバイダーは必須です。');
        try {
            await this.config.addCustomModel({
                id,
                name,
                provider,
                endpoint: endpoint || undefined,
                streaming: 'sse',
                recommended: false,
                proxySupported
            });
            document.getElementById('add-model-id').value = '';
            document.getElementById('add-model-name').value = '';
            document.getElementById('add-model-endpoint').value = '';
            await this.renderModelSelect();
            await this.renderCustomModelsList();
            alert('カスタムモデルを追加しました。');
        } catch (e) {
            alert('追加に失敗: ' + e.message);
        }
    }

    /** 設定保存（既存挙動踏襲） */
    async save() {
        const model = document.getElementById('api-model-select').value;
        const key = document.getElementById('api-key-input').value.trim();
        const prompt = document.getElementById('system-prompt-input').value.trim();
        if (!key) return alert('APIキーを入力してください。');

        let settings = (await this.db.get('settings')) || { keys: {} };
        if (!settings.keys) settings.keys = {};
        settings.model = model;
        settings.keys[model] = key;
        settings.prompt = prompt;
        await this.db.set('settings', settings);
        alert('設定を保存しました。');
    }

    /** 現在のAI設定（モデル・APIキー・任意の追加システムプロンプト・モデルメタ）を返す */
    async getActiveAIConfig() {
        const s = await this.db.get('settings');
        if (!s || !s.model || !s.keys?.[s.model]) return null;
        const meta = await this.config.getModelById(s.model);
        return { model: s.model, apiKey: s.keys[s.model], prompt: s.prompt, modelMeta: meta };
    }

    /** データ管理：既存ロジックそのまま */
    async exportData() {
        const keys = [
            'settings',
            'profile',
            'analysis_result',
            'timeline_monthly',
            'timeline_weekly',
            'timeline_daily',
            'timeline_hourly',
            'chat_history',
            'horoscope_history',
            'custom_models',
            'hidden_default_models',
            'user_prompts'
        ];
        const data = {};
        for (let k of keys) data[k] = await this.db.get(k);
        const a = document.createElement('a');
        a.href = URL.createObjectURL(new Blob([JSON.stringify(data)], { type: 'application/json' }));
        a.download = 'astro_backup.json';
        a.click();
    }

    importData(e) {
        const f = e.target.files[0];
        if (!f) return;
        const reader = new FileReader();
        const db = this.db;
        reader.onload = async (ev) => {
            try {
                const data = JSON.parse(ev.target.result);
                for (let k in data) await db.set(k, data[k]);
                alert('復元しました。再読込します。');
                location.reload();
            } catch (err) {
                alert('失敗しました。');
            }
        };
        reader.readAsText(f);
    }

    async syncToFileSystem() {
        try {
            const handle = await window.showSaveFilePicker({
                suggestedName: 'astro_chat.json',
                types: [{ description: 'JSON', accept: { 'application/json': ['.json'] } }]
            });
            const w = await handle.createWritable();
            await w.write(JSON.stringify(await this.db.get('chat_history'), null, 2));
            await w.close();
            alert('保存しました。');
        } catch (e) {
            console.error(e);
        }
    }

    async clearAll() {
        if (confirm('全消去しますか？')) {
            await this.db.clearAll();
            location.reload();
        }
    }

    _esc(s) {
        return String(s || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }
}

window.SettingsComponent = SettingsComponent;
