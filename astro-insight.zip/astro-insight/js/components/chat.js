/* ============================================================
 * AstroInsight - Chat Component
 * 既存 AstroApp.loadChat / handleChatSubmit / addChatMessage を分離独立化。
 * 機能キー: prompt_chat を使用。
 * ============================================================ */

class ChatComponent {
    /** @param {AstroApp} app */
    constructor(app) {
        this.app = app;
        this.db = app.db;
    }

    async load() {
        const chats = (await this.db.get('chat_history')) || [];
        const cont = document.getElementById('chat-messages');
        if (chats.length > 0) {
            cont.innerHTML = '';
            chats.forEach((c) => this.app.ui.appendChatBubble(c.role, c.text));
            setTimeout(() => (cont.scrollTop = cont.scrollHeight), 100);
        }
    }

    async handleSubmit(e) {
        e.preventDefault();
        const input = document.getElementById('chat-input');
        const text = input.value.trim();
        if (!text) return;
        input.value = '';
        await this.add('user', text);
        const p = this.app.profile.getProfileString() || '未設定';
        const a = (await this.db.get('analysis_result')) || 'なし';
        let chats = (await this.db.get('chat_history')) || [];
        const hist = chats
            .slice(-6)
            .map((c) => `${c.role}: ${c.text}`)
            .join('\n');
        const sysPrompt = await this.app.config.getPrompt('prompt_chat');
        const prompt = `${sysPrompt}\n\nユーザーからの質問に答えてください。\n【プロフ】${p}\n【分析】${a.substring(
            0,
            200
        )}\n【履歴】${hist}\n最新の質問: ${text}\n回答:`;
        this.app.startGeneration('chat', prompt, false);
    }

    async add(role, text) {
        let chats = (await this.db.get('chat_history')) || [];
        chats.push({ role, text, time: Date.now() });
        await this.db.set('chat_history', chats);
        this.app.ui.appendChatBubble(role, text);
    }
}

window.ChatComponent = ChatComponent;
