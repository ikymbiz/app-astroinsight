/* ============================================================
 * AstroInsight - Timeline (Forecast) Component
 * 既存 AstroApp.generateTimeline / processTimelineResult /
 * loadTimeline / renderTimeline を分離独立化。
 * 機能キー: prompt_forecast を使用。
 * ============================================================ */

class TimelineComponent {
    /** @param {AstroApp} app */
    constructor(app) {
        this.app = app;
        this.db = app.db;
    }

    async generate() {
        const p = this.app.profile.getProfileString();
        if (!p) return alert('プロフィールを設定してください。');
        const typeInfo = {
            monthly: { desc: '今月から1年半（18ヶ月間）', fmt: 'YYYY-MM', count: 18 },
            weekly: { desc: '今週から3ヶ月間（12週間）', fmt: 'YYYY年M月第W週', count: 12 },
            daily: { desc: '今日から2週間（14日間）', fmt: 'MM/DD', count: 14 },
            hourly: {
                desc: '現在から3日間（72時間ごとではなく、3時間区切りで24期間等、適度に丸めて合計約24個）',
                fmt: 'MM/DD HH:00',
                count: 24
            }
        };
        const info = typeInfo[this.app.forecastType];
        const sysPrompt = await this.app.config.getPrompt('prompt_forecast');
        const prompt = `${sysPrompt}\n\nプロフィールを持つ人物の【${info.desc}】の星の影響を予測してください。
【重要】出力は必ず以下のJSON配列形式のみとしてください。Markdown修飾(\`\`\`jsonなど)は一切不要です。直接 [ で開始してください。
フォーマット: [{"period": "期間文字列(${info.fmt})", "impact": 0〜100の数値, "theme": "主要テーマ", "description": "アドバイス" }, ...(${info.count}個)]\nプロフィール: ${p}`;
        this.app.startGeneration('timeline', prompt, true);
    }

    async processResult(text) {
        try {
            let clean = text.replace(/```json/gi, '').replace(/```/g, '').trim();
            const s = clean.indexOf('[');
            const e = clean.lastIndexOf(']');
            if (s !== -1 && e !== -1) clean = clean.substring(s, e + 1);
            else throw new Error('JSON配列が見つかりません。');
            const data = JSON.parse(clean);
            if (!Array.isArray(data)) throw new Error('不正なデータ');
            await this.db.set(`timeline_${this.app.forecastType}`, data);
            this.render(data);
        } catch (e) {
            this.app.handleError('データ解析失敗(AI出力の乱れ): ' + e.message);
        }
    }

    async load() {
        const d = await this.db.get(`timeline_${this.app.forecastType}`);
        if (d) this.render(d);
        else
            document.getElementById('timeline-details').innerHTML =
                '<div class="text-center text-slate-400 py-6 w-full"><p class="text-sm">予測データがありません。「予測開始」を押してください。</p></div>';
    }

    render(data) {
        if (!data || data.length === 0) return;
        const labels = data.map((d) => d.period);
        const impacts = data.map((d) => d.impact);
        const ctx = document.getElementById('timelineChart').getContext('2d');
        if (this.app.chartInstance) this.app.chartInstance.destroy();
        const pointBg = new Array(data.length).fill('#fff');
        const pointRad = new Array(data.length).fill(4);
        pointBg[0] = '#4f46e5';
        pointRad[0] = 8;

        this.app.chartInstance = new Chart(ctx, {
            type: 'line',
            data: {
                labels,
                datasets: [
                    {
                        label: '影響度',
                        data: impacts,
                        borderColor: '#4f46e5',
                        backgroundColor: 'rgba(79, 70, 229, 0.2)',
                        tension: 0.4,
                        fill: true,
                        pointBackgroundColor: pointBg,
                        pointBorderColor: '#4f46e5',
                        pointBorderWidth: 2,
                        pointRadius: pointRad
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: { y: { min: 0, max: 100 }, x: { ticks: { maxTicksLimit: 6 } } },
                plugins: { legend: { display: false } },
                animation: { duration: 500 }
            }
        });

        const cont = document.getElementById('timeline-details');
        cont.innerHTML = '';
        data.forEach((item) => {
            const card = document.createElement('div');
            card.className =
                'timeline-card bg-white rounded-xl shadow-sm border border-slate-100 p-5 border-t-4 border-t-astro h-full flex flex-col';
            card.innerHTML = `<div class="flex justify-between items-center mb-3 shrink-0"><h4 class="font-bold text-slate-800 text-lg">${item.period}</h4><span class="text-xs font-bold px-3 py-1 rounded-full bg-astro-light text-astro border border-indigo-200">影響度: ${item.impact}</span></div><h5 class="text-sm font-bold text-astro mb-2 shrink-0"><i class="fa-solid fa-star mr-1"></i>${item.theme}</h5><div class="flex-1 overflow-y-auto pr-1"><p class="text-sm text-slate-600 leading-relaxed">${item.description}</p></div>`;
            cont.appendChild(card);
        });

        cont.onscroll = () => {
            if (!cont.children[0]) return;
            const w = cont.children[0].offsetWidth + 16;
            const idx = Math.min(Math.max(Math.round(cont.scrollLeft / w), 0), data.length - 1);
            const chart = this.app.chartInstance;
            chart.data.datasets[0].pointBackgroundColor = data.map((_, i) =>
                i === idx ? '#4f46e5' : '#fff'
            );
            chart.data.datasets[0].pointRadius = data.map((_, i) => (i === idx ? 8 : 4));
            chart.update('none');
        };
    }
}

window.TimelineComponent = TimelineComponent;
