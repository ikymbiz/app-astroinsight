/* ============================================================
 * AstroInsight - Horoscope (Detail) Component
 * 既存 AstroApp.loadHoroscope / generateHoroscope と
 * finishGeneration内の horoscope分岐を分離独立化。
 * 機能キー: prompt_detail を使用。
 * ============================================================ */

class HoroscopeComponent {
    /** @param {AstroApp} app */
    constructor(app) {
        this.app = app;
        this.db = app.db;
    }

    async load() {
        const h = (await this.db.get('horoscope_history')) || [];
        this.app.horoscopeHistory = h;
        this.app.ui.renderHoroscopeHistory(h);
        if (h.length > 0) this.app.ui.selectHoroscopeHistory(h[0].id);
    }

    async generate() {
        const d = document.getElementById('horoscope-date').value;
        const t = document.getElementById('horoscope-time').value;
        const p = this.app.profile.getProfileString();
        if (!p || !d) return alert('プロフィールと年月日が必要です。');
        document.getElementById('horoscope-details').removeAttribute('open');
        const sysPrompt = await this.app.config.getPrompt('prompt_detail');
        const prompt = `${sysPrompt}\n\n出生情報に対し、指定日時の星の配置の影響を詳細に分析してください。\nネイタル: ${p}\nトランジット日時: ${d} ${t}`;
        document.getElementById('horoscope-result').innerHTML = '';
        this.app.startGeneration('horoscope', prompt, false);
    }

    /** finishGeneration から呼ばれる：履歴に追加 */
    async pushHistory(finalText) {
        let history = (await this.db.get('horoscope_history')) || [];
        const timestamp = Date.now();
        history.unshift({
            id: timestamp,
            date: document.getElementById('horoscope-date').value,
            time: document.getElementById('horoscope-time').value,
            text: finalText
        });
        await this.db.set('horoscope_history', history);
        this.app.horoscopeHistory = history;
        this.app.ui.renderHoroscopeHistory(history);
        this.app.ui.selectHoroscopeHistory(timestamp);
    }
}

window.HoroscopeComponent = HoroscopeComponent;
