/* ============================================================
 * AstroInsight - Profile Component
 * 既存 AstroApp.loadProfile / saveProfile / getProfileString を分離独立化。
 * ============================================================ */

class ProfileComponent {
    /** @param {AstroApp} app */
    constructor(app) {
        this.app = app;
        this.db = app.db;
    }

    async load() {
        const p = await this.db.get('profile');
        if (p) {
            ['name', 'date', 'time', 'place'].forEach(
                (k) => (document.getElementById(`profile-${k}`).value = p[k] || '')
            );
        }
    }

    async save(silent = false) {
        const p = {
            name: document.getElementById('profile-name').value.trim(),
            date: document.getElementById('profile-date').value,
            time: document.getElementById('profile-time').value,
            place: document.getElementById('profile-place').value.trim()
        };
        if (!silent && (!p.name || !p.date || !p.place)) return alert('必須項目を入力してください。');
        await this.db.set('profile', p);
        if (!silent) {
            this.app.ui.switchTab('analysis');
        }
    }

    getProfileString() {
        const p = {
            name: document.getElementById('profile-name').value.trim(),
            date: document.getElementById('profile-date').value,
            time: document.getElementById('profile-time').value,
            place: document.getElementById('profile-place').value.trim()
        };
        if (!p.name || !p.date) return null;
        return `名前: ${p.name}, 生年月日: ${p.date}, 出生時間: ${p.time || '不明'}, 出生地: ${p.place}`;
    }

    /** プロフィール入力のdebounceサイレント保存をセット */
    bindAutoSave() {
        ['profile-name', 'profile-date', 'profile-time', 'profile-place'].forEach((id) =>
            document.getElementById(id).addEventListener(
                'input',
                this.app.debounce(() => this.save(true), 1000)
            )
        );
    }
}

window.ProfileComponent = ProfileComponent;
