/* ============================================================
 * AstroInsight - UI Controller
 * 既存 index.html 内の UIController クラスを分離独立ファイル化。
 * タブ切替・チャットバブル描画・履歴セレクト・予報粒度切替などのUI操作。
 * 既存ロジックは保持。
 * ============================================================ */

class UIController {
    constructor(app) {
        this.app = app;
    }

    setupEventListeners() {
        document
            .getElementById('chat-form')
            .addEventListener('submit', (e) => this.app.handleChatSubmit(e));
    }

    switchTab(id) {
        document.querySelectorAll('.tab-content').forEach((el) => {
            el.classList.remove('active');
            el.classList.add('hidden');
        });
        const target = document.getElementById(`tab-${id}`);
        if (target) {
            target.classList.add('active');
            target.classList.remove('hidden');
        }
        document.querySelectorAll('.nav-btn').forEach((btn) => btn.classList.remove('active-nav'));
        const m = {
            profile: 0,
            analysis: 1,
            today: 2,
            horoscope: 3,
            timeline: 4,
            chat: 5
        };
        if (m[id] !== undefined) document.querySelectorAll('.nav-btn')[m[id]].classList.add('active-nav');
    }

    appendChatBubble(role, text) {
        const c = document.getElementById('chat-messages');
        const div = document.createElement('div');
        div.className = `flex ${role === 'user' ? 'justify-end' : 'justify-start'} fade-in`;
        const b = document.createElement('div');
        b.className = `px-4 py-3 max-w-[85%] text-sm leading-relaxed ${
            role === 'user' ? 'chat-user' : 'chat-ai'
        }`;
        if (role === 'model') b.innerHTML = marked.parse(text);
        else b.textContent = text;
        div.appendChild(b);
        c.appendChild(div);
        c.scrollTop = c.scrollHeight;
    }

    renderHoroscopeHistory(h) {
        const c = document.getElementById('horoscope-history-container');
        const s = document.getElementById('horoscope-history-select');
        if (!h || h.length === 0) {
            c.classList.add('hidden');
            return;
        }
        c.classList.remove('hidden');
        s.innerHTML = h
            .map((i) => `<option value="${i.id}">指定日: ${i.date} ${i.time || ''}</option>`)
            .join('');
    }

    selectHoroscopeHistory(id) {
        const i = (this.app.horoscopeHistory || []).find((h) => h.id == id);
        if (i) {
            document.getElementById('horoscope-result').innerHTML = marked.parse(i.text);
            document.getElementById('horoscope-history-select').value = id;
        }
    }

    setForecastTab(type) {
        this.app.forecastType = type;
        ['monthly', 'weekly', 'daily', 'hourly'].forEach((t) => {
            const btn = document.getElementById(`fc-btn-${t}`);
            if (t === type) {
                btn.classList.add('active', 'bg-astro', 'text-white');
                btn.classList.remove('bg-white', 'text-slate-600');
            } else {
                btn.classList.remove('active', 'bg-astro', 'text-white');
                btn.classList.add('bg-white', 'text-slate-600');
            }
        });
        this.app.loadTimeline();
    }
}

window.UIController = UIController;
