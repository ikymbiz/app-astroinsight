/* ============================================================
 * AstroInsight - Snackbar / Task Toast（v10）
 * 失敗時のトーストが残り続けないよう、自動消去・閉じる・重複抑制を統一。
 * ============================================================ */

class Snackbar {
    constructor() {
        this.tasks = new Map();
        this.container = null;
        this._lastNotice = { text: '', ts: 0 };
        this._ensure();
    }

    _ensure() {
        if (this.container) return;
        this.container = document.createElement('div');
        this.container.id = 'snackbar-container';
        this.container.className = 'fixed left-0 right-0 bottom-20 z-[90] px-4 space-y-2 pointer-events-none';
        document.body.appendChild(this.container);
    }

    clearAll() {
        for (const id of Array.from(this.tasks.keys())) this._remove(id, true);
    }

    start(taskId, label) {
        this._ensure();
        const existing = this.tasks.get(taskId);
        if (existing) existing.el.remove();
        const el = document.createElement('div');
        el.className = 'pointer-events-auto bg-white border border-slate-200 shadow-lg rounded-2xl px-4 py-3 flex items-center gap-3 text-sm';
        el.innerHTML = `
            <div class="dot-flashing"></div>
            <div class="flex-1 text-slate-700">${this._esc(label || '処理中…')}</div>
            <button class="close text-slate-400 hover:text-slate-700 text-lg leading-none" aria-label="閉じる">&times;</button>
        `;
        el.querySelector('.close')?.addEventListener('click', () => this._remove(taskId));
        this.container.appendChild(el);
        this.tasks.set(taskId, { el, label, timer: null });
    }

    update(taskId, label) {
        const t = this.tasks.get(taskId);
        if (!t) return;
        t.label = label;
        const text = t.el.querySelector('.flex-1');
        if (text) text.textContent = label;
    }

    succeed(taskId, message) {
        const t = this.tasks.get(taskId);
        if (!t) return this.notice(message || '完了しました。', 'success');
        this._setTaskHtml(taskId, `
            <i class="fa-solid fa-circle-check text-emerald-500 text-lg"></i>
            <div class="flex-1 text-slate-700">${this._esc(message || '完了しました。')}</div>
            <button class="close text-slate-400 hover:text-slate-700 text-lg leading-none" aria-label="閉じる">&times;</button>
        `, 2500);
    }

    fail(taskId, message, retryFn) {
        const t = this.tasks.get(taskId);
        if (!t) return this.notice(message || 'エラーが発生しました。', 'error', retryFn);
        t.el.className = 'pointer-events-auto bg-white border border-red-200 shadow-lg rounded-2xl px-4 py-3 flex items-center gap-3 text-sm';
        this._setTaskHtml(taskId, `
            <i class="fa-solid fa-triangle-exclamation text-red-500 text-lg"></i>
            <div class="flex-1 text-red-700 whitespace-pre-line">${this._esc(message || 'エラーが発生しました。')}</div>
            ${retryFn ? '<button class="retry bg-red-50 text-red-700 px-2 py-1 rounded-lg text-xs font-bold">再試行</button>' : ''}
            <button class="close text-slate-400 hover:text-slate-700 text-lg leading-none" aria-label="閉じる">&times;</button>
        `, 6500);
        const cur = this.tasks.get(taskId);
        cur?.el.querySelector('.retry')?.addEventListener('click', () => { this._remove(taskId); retryFn && retryFn(); });
    }

    notice(message, type = 'info', retryFn = null) {
        this._ensure();
        const text = String(message || '');
        const now = Date.now();
        if (this._lastNotice.text === `${type}:${text}` && now - this._lastNotice.ts < 2500) return null;
        this._lastNotice = { text: `${type}:${text}`, ts: now };
        const id = 'notice-' + now + '-' + Math.random().toString(36).slice(2);
        const el = document.createElement('div');
        const isError = type === 'error';
        const isSuccess = type === 'success';
        const icon = isError ? 'fa-triangle-exclamation text-red-500' : isSuccess ? 'fa-circle-check text-emerald-500' : 'fa-circle-info text-astro';
        el.className = `pointer-events-auto bg-white border ${isError ? 'border-red-200' : isSuccess ? 'border-emerald-200' : 'border-slate-200'} shadow-lg rounded-2xl px-4 py-3 flex items-center gap-3 text-sm`;
        el.innerHTML = `
            <i class="fa-solid ${icon} text-lg"></i>
            <div class="flex-1 ${isError ? 'text-red-700' : 'text-slate-700'} whitespace-pre-line">${this._esc(text)}</div>
            ${retryFn ? '<button class="retry bg-red-50 text-red-700 px-2 py-1 rounded-lg text-xs font-bold">再試行</button>' : ''}
            <button class="close text-slate-400 hover:text-slate-700 text-lg leading-none" aria-label="閉じる">&times;</button>
        `;
        this.container.appendChild(el);
        this.tasks.set(id, { el, label: text, timer: null });
        el.querySelector('.close')?.addEventListener('click', () => this._remove(id));
        el.querySelector('.retry')?.addEventListener('click', () => { this._remove(id); retryFn && retryFn(); });
        this._scheduleRemove(id, isError ? 6500 : 3500);
        this._capVisible(4);
        return id;
    }

    _setTaskHtml(taskId, html, timeoutMs) {
        const t = this.tasks.get(taskId);
        if (!t) return;
        if (t.timer) clearTimeout(t.timer);
        t.el.innerHTML = html;
        t.el.querySelector('.close')?.addEventListener('click', () => this._remove(taskId));
        this._scheduleRemove(taskId, timeoutMs);
    }

    _scheduleRemove(taskId, ms) {
        const t = this.tasks.get(taskId);
        if (!t) return;
        if (t.timer) clearTimeout(t.timer);
        t.timer = setTimeout(() => this._remove(taskId), ms);
    }

    _capVisible(max) {
        const ids = Array.from(this.tasks.keys());
        while (ids.length > max) this._remove(ids.shift(), true);
    }

    _remove(taskId, immediate = false) {
        const t = this.tasks.get(taskId);
        if (!t) return;
        if (t.timer) clearTimeout(t.timer);
        if (immediate) t.el.remove();
        else {
            t.el.style.opacity = '0';
            t.el.style.transform = 'translateY(8px)';
            t.el.style.transition = 'all 200ms ease';
            setTimeout(() => t.el.remove(), 220);
        }
        this.tasks.delete(taskId);
    }

    _esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }
}

window.Snackbar = Snackbar;
