/* ============================================================
 * AstroInsight - Chat Component（v6 guardrails）
 *   - チャットのガードレールを追加
 *   - 話し過ぎ防止: 短文回答、短い履歴、低maxTokens、出力トリム
 *   - 高リスク相談はAI生成前に短く安全導線へ誘導
 * ============================================================ */

class ChatComponent {
    constructor(app) {
        this.app = app;
        this.db = app.db;
        this.context = '';
        this.defaults = {
            maxUserChars: 700,
            maxAnswerChars: 420,
            maxHistoryTurns: 4,
            maxHistoryChars: 160,
            maxNatalChars: 180,
            maxProfileChars: 500
        };
    }

    async load() {
        const chats = (await this.db.get('chat_history')) || [];
        const cont = document.getElementById('chat-messages');
        if (!cont) return;
        if (chats.length > 0) {
            cont.innerHTML = '';
            for (const c of chats) this.app.ui.appendChatBubble(c.role, c.text);
            setTimeout(() => (cont.scrollTop = cont.scrollHeight), 100);
        }
        this._renderContextBadge();
    }

    setContext(text) {
        this.context = text || '';
        this._renderContextBadge();
    }

    clearContext() {
        this.context = '';
        this._renderContextBadge();
    }

    _renderContextBadge() {
        const badge = document.getElementById('chat-context-badge');
        if (!badge) return;
        if (this.context) {
            badge.classList.remove('hidden');
            badge.querySelector('span').textContent = `${this.context}を質問中`;
        } else {
            badge.classList.add('hidden');
        }
    }

    async handleSubmit(e) {
        e.preventDefault();
        const input = document.getElementById('chat-input');
        const rawText = input.value.trim();
        if (!rawText) return;
        input.value = '';

        await this.add('user', rawText);

        const cfg = this._cfg();
        const guard = this._guardrail(rawText, cfg);
        if (guard.stop) {
            await this.add('model', guard.reply);
            return;
        }

        const text = guard.text;
        const profileStr = this._short((await this.app.profile.getProfileString()) || '未設定', cfg.maxProfileChars);
        const natalCacheKey = `natal_${await this.app.profile.getProfileHash()}`;
        const natalCached = await this.db.cacheGet(natalCacheKey);
        const natalText = natalCached?.text ? this._short(natalCached.text, cfg.maxNatalChars) : 'なし';
        const chats = (await this.db.get('chat_history')) || [];
        const hist = chats.slice(-(cfg.maxHistoryTurns || 4)).map((c) => `${c.role}: ${this._short(c.text, cfg.maxHistoryChars)}`).join('\n');
        const sysPrompt = await this.app.config.getPrompt('prompt_chat');
        const ctxBlock = this.context ? `【現在の質問文脈】${this._short(this.context, 220)}\n` : '';
        const prompt = `${sysPrompt}\n\n【チャット専用ガードレール】\n・回答は日本語で、原則${cfg.maxAnswerChars}字以内。長くても3項目まで。\n・最初に結論を書く。前置き、免責の長文、占星術用語の羅列は禁止。\n・占星術アプリの相談範囲に収める。医療・法律・金融などの専門判断は断定しない。\n・自傷、他害、虐待、ストーカー、操作・支配、違法行為の依頼には具体的手順を出さない。必要な支援先や安全確保を短く促す。\n・未来を「必ず起きる」と断定しない。根拠がある注意点はありのまま短く書く。\n・ユーザーが「詳しく」と言うまで深掘りしない。\n\nユーザーの質問に短く答えてください。\n【プロフ】${profileStr}\n【ネイタル要約】${natalText}\n${ctxBlock}【履歴】${hist}\n最新の質問: ${text}\n回答:`;
        const taskId = `chat-${Date.now()}`;
        const placeholder = this._appendStreamingBubble();
        await this.app.startGeneration({
            taskId,
            taskLabel: 'チャットを生成中…',
            prompt,
            isJson: false,
            featureId: 'chat.message',
            requiresPayment: true,
            maxTokens: 520,
            temperature: 0.55,
            onProgress: (streamText) => {
                placeholder.innerHTML = this.app.renderMarkdown(this._short(streamText, Math.min(900, cfg.maxAnswerChars + 260)) + ' ▍');
                const cont = document.getElementById('chat-messages');
                if (cont) cont.scrollTop = cont.scrollHeight;
            },
            onDone: async (streamText) => {
                const finalText = this._compactAnswer(streamText, cfg.maxAnswerChars);
                placeholder.innerHTML = this.app.renderMarkdown(finalText);
                await this._persist('model', finalText);
                this.app.snackbar.succeed(taskId, '✓ 回答しました');
            },
            onError: (msg) => {
                placeholder.innerHTML = `<span class="text-red-500 text-sm">回答できませんでした。時間を置いて再試行してください。</span>`;
                this.app.snackbar.fail(taskId, msg, () => {});
            }
        });
    }

    _cfg() {
        const appCfg = this.app.config.getAppConfig?.() || {};
        return { ...this.defaults, ...(appCfg.chat || {}) };
    }

    _guardrail(text, cfg) {
        const src = String(text || '').trim();
        const lower = src.toLowerCase();
        const has = (arr) => arr.some((w) => lower.includes(w));
        if (src.length > (cfg.maxUserChars || 700)) {
            return { stop: true, reply: `質問が長すぎます。要点を${cfg.maxUserChars || 700}字以内で送ってください。` };
        }
        if (has(['死にたい', '自殺', '消えたい', 'リスカ', '自傷', '首を吊', '飛び降り', '殺したい', '刺したい'])) {
            return { stop: true, reply: '今すぐ一人で抱えないでください。身近な人、緊急窓口、救急・警察など現実の支援につないでください。このチャットでは安全確保を最優先にしてください。' };
        }
        if (has(['盗聴', 'ハッキング', '脅迫', '復讐', 'ストーカー', '尾行', '個人情報を抜く', '相手を操る', '洗脳'])) {
            return { stop: true, reply: 'その依頼には対応できません。関係を安全に整理する方法や、自分の行動方針なら短く見ます。' };
        }
        if (has(['診断して', '薬', '病気', '裁判', '訴訟', '税金', '投資しろ', '銘柄', '売買タイミング'])) {
            return { stop: false, text: `${src}\n※専門判断はせず、占星術的な気分整理と行動の注意点に限定して答えて。` };
        }
        if (has(['天気', 'ニュース', '株価', '為替', '試合結果', '最新情報'])) {
            return { stop: true, reply: '最新情報の確認はこのチャットでは扱いません。占星術的な過ごし方や気分の流れなら短く見ます。' };
        }
        return { stop: false, text: src };
    }

    _compactAnswer(text, maxChars) {
        let out = String(text || '').trim();
        out = out.replace(/^(もちろん|はい|わかりました|了解です)[。！!\s]*/g, '');
        if (out.length <= maxChars) return out;
        const slice = out.slice(0, maxChars);
        const idx = Math.max(slice.lastIndexOf('。'), slice.lastIndexOf('\n'), slice.lastIndexOf('！'), slice.lastIndexOf('？'));
        return (idx > 80 ? slice.slice(0, idx + 1) : slice).trim() + '\n\n続きが必要なら「詳しく」と送ってください。';
    }

    _short(text, max) {
        const s = String(text == null ? '' : text).replace(/\s+/g, ' ').trim();
        return s.length > max ? s.slice(0, max) + '…' : s;
    }

    _appendStreamingBubble() {
        const c = document.getElementById('chat-messages');
        const div = document.createElement('div');
        div.className = 'flex justify-start';
        const b = document.createElement('div');
        b.className = 'px-4 py-3 max-w-[85%] text-sm leading-relaxed chat-ai';
        b.innerHTML = '<i class="fa-solid fa-circle-notch animate-spin text-astro"></i>';
        div.appendChild(b);
        c.appendChild(div);
        c.scrollTop = c.scrollHeight;
        return b;
    }

    async add(role, text) {
        await this._persist(role, text);
        this.app.ui.appendChatBubble(role, text);
    }

    async _persist(role, text) {
        const chats = (await this.db.get('chat_history')) || [];
        chats.push({ role, text, time: Date.now() });
        await this.db.set('chat_history', chats.slice(-80));
    }

    async clearHistory() {
        if (!confirm('チャット履歴を消去しますか？')) return;
        await this.db.set('chat_history', []);
        const cont = document.getElementById('chat-messages');
        cont.innerHTML = `
            <div class="flex justify-start">
                <div class="chat-ai px-4 py-3 max-w-[85%] text-sm leading-relaxed">こんにちは。短く答えます。星の流れ、相性、今日の行動を聞いてください。</div>
            </div>`;
    }
}

window.ChatComponent = ChatComponent;
