/* ============================================================
 * AstroInsight - Today Component（v6 rule-based）
 *   - 今日 / 今週 / 今月の初期表示はAIなし
 *   - ForecastEngineのルールベース結果から即時表示
 *   - 詳細ボタンから必要時のみAI解説へ
 * ============================================================ */

class TodayComponent {
    constructor(app) {
        this.app = app;
        this.db = app.db;
        this.segment = 'day';
    }

    _baseDate() {
        const d = new Date();
        if (this.segment === 'day') return d.toISOString().slice(0, 10);
        if (this.segment === 'week') {
            const day = d.getDay() || 7;
            const monday = new Date(d);
            monday.setDate(d.getDate() - (day - 1));
            return monday.toISOString().slice(0, 10);
        }
        return d.toISOString().slice(0, 7);
    }

    cacheKey() { return `today_${this.segment}_${this._baseDate()}`; }

    async load() {
        const cached = await this.db.cacheGet(this.cacheKey());
        if (cached) this._render(cached);
        else {
            const profile = await this.db.get('profile') || {};
            if (profile.date) await this.generate({ silent: true });
            else this._renderEmpty();
        }
    }

    async refresh() {
        await this.db.cacheDelete(this.cacheKey());
        this.generate();
    }

    async generate(opts = {}) {
        const profile = await this.db.get('profile') || {};
        if (!profile.date) return alert('プロフィールを設定してください。');
        if (!window.ForecastEngine) return alert('予報エンジンの読み込みに失敗しました。');
        const periodLabel = this.segment === 'day' ? '今日1日' : this.segment === 'week' ? '今週1週間' : '今月1ヶ月';
        const taskId = `today-local-${this.segment}`;
        try {
            if (!opts.silent) this.app.snackbar.start(taskId, `${periodLabel}を計算中…`);
            const context = await ForecastEngine.getUserContext(this.db);
            const type = this.segment === 'day' ? 'daily' : this.segment === 'week' ? 'weekly' : 'monthly';
            const data = ForecastEngine.generate({ profile, type, appConfig: this.app.config.getAppConfig(), userContext: context, now: new Date() });
            const it = data[0];
            const payload = {
                items: [{
                    theme: it.theme,
                    impact: it.impact,
                    summary: it.description,
                    advice: (it.recommendations?.do || []).join(' / '),
                    raw: it
                }],
                ts: Date.now(),
                segment: this.segment,
                mode: 'rule-based'
            };
            await this.db.cacheSet(this.cacheKey(), payload);
            this._render(payload);
            if (!opts.silent) this.app.snackbar.succeed(taskId, '✓ 更新しました');
        } catch (e) {
            console.error('[today] local generation failed', e);
            this.app.snackbar.fail(taskId, '計算に失敗しました: ' + (e?.message || e), () => this.generate());
        }
    }

    _renderEmpty() {
        const el = document.getElementById('today-cards');
        if (!el) return;
        el.innerHTML = `
            <div class="text-center text-slate-400 py-10">
                <i class="fa-solid fa-cloud-sun text-4xl mb-3 opacity-50"></i>
                <p class="text-sm">プロフィールを設定すると、今日の流れを自動表示します。</p>
                <p class="text-[10px] mt-2">基本表示はAIなしで高速に作成します。詳細だけAIで深掘りできます。</p>
            </div>`;
    }

    _render(payload) {
        const el = document.getElementById('today-cards');
        if (!el) return;
        el.innerHTML = '';
        for (const it of payload.items) {
            const card = document.createElement('div');
            card.className = 'bg-white rounded-2xl shadow-sm border border-slate-100 p-5 mb-3 border-l-4 border-l-astro';
            const impact = Math.max(0, Math.min(100, parseInt(it.impact || 50)));
            const raw = it.raw || {};
            const recs = raw.recommendations?.do || [];
            card.innerHTML = `
                <div class="flex justify-between items-start mb-2">
                    <h3 class="font-bold text-slate-800 text-base">${this._esc(it.theme || 'テーマ')}</h3>
                    <span class="text-xs font-bold px-2 py-1 rounded-full bg-astro-light text-astro border border-indigo-200 shrink-0">体感しやすさ: ${impact}</span>
                </div>
                <p class="text-sm text-slate-600 leading-relaxed mb-3">${this._esc(it.summary || '')}</p>
                ${recs.length ? `<div class="bg-slate-50 rounded-xl p-3 mb-3"><h4 class="text-xs font-bold text-astro mb-1">今日使える行動</h4><ul class="list-disc pl-5 text-xs text-slate-700">${recs.slice(0,3).map((r) => `<li>${this._esc(r)}</li>`).join('')}</ul></div>` : ''}
                <button class="w-full bg-slate-50 hover:bg-slate-100 text-astro border border-slate-200 font-bold py-2 rounded-xl text-sm transition active:scale-95">
                    <i class="fa-solid fa-arrow-right-long mr-1"></i> AIで詳しく読む
                </button>`;
            const detailBtn = card.querySelector('button');
            detailBtn.addEventListener('click', () => {
                this.app.detail.openForToday({
                    theme: it.theme, summary: it.summary, advice: it.advice, impact, segment: this.segment, raw
                });
            });
            el.appendChild(card);
        }
    }

    _esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
}

window.TodayComponent = TodayComponent;
