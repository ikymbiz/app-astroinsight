/* ============================================================
 * AstroInsight - Compatibility Component（v8 local-first）
 *   - 友達登録/編集/削除を確実に保存
 *   - 基本相性はAIなしで即表示。AI失敗や解析失敗で画面を止めない
 *   - AI詳細はユーザー操作時のみ。将来課金対象としてメタ情報を持つ
 * ============================================================ */

class CompatComponent {
    constructor(app) {
        this.app = app;
        this.db = app.db;
        this.editingId = null;
    }

    async load() { await this.renderList(); }

    async renderList() {
        const friends = await this.db.friendList();
        const cont = document.getElementById('compat-list');
        if (!cont) return;
        if (!friends.length) {
            cont.innerHTML = `<div class="text-center text-slate-400 py-10"><i class="fa-solid fa-user-group text-4xl mb-3 opacity-50"></i><p class="text-sm">まだ友達が登録されていません。</p><p class="text-xs mt-1">右下の「＋」から追加できます。</p></div>`;
            return;
        }
        cont.innerHTML = '';
        for (const f of friends.sort((a,b)=>(b.updatedAt||b.ts||0)-(a.updatedAt||a.ts||0))) {
            if (!f.compat || !f.compat.scores) {
                try { f.compat = await this.buildLocalCompatibility(f); await this.db.friendPut(f.id, f); } catch (_) {}
            }
            const c = f.compat || {};
            const score = c.scores?.total ?? '?';
            const precision = this._precisionLabel(f);
            const card = document.createElement('div');
            card.className = 'bg-white rounded-2xl shadow-sm border border-slate-100 p-4 mb-3 active:bg-slate-50 transition cursor-pointer';
            card.innerHTML = `<div class="flex justify-between items-start"><div class="flex-1"><div class="flex items-center gap-2"><i class="fa-solid fa-user-circle text-xl text-astro"></i><h3 class="font-bold text-slate-800 text-base">${this._esc(f.name)}</h3></div><p class="text-xs text-slate-500 mt-1 ml-7">生年月日: ${this._esc(f.date || '?')} / ${this._esc(f.relation || '関係性未設定')}</p><p class="text-[10px] text-slate-400 mt-1 ml-7">出生時間: ${f.time ? 'あり' : '不明'} / 出生地: ${f.place ? 'あり' : '不明'} / 診断精度: ${precision}</p></div><div class="text-right"><div class="text-2xl font-bold text-astro">${score}</div><div class="text-[10px] text-slate-400">相性スコア</div></div></div>`;
            let pressTimer = null;
            card.addEventListener('click', () => { if (this._longPressed) { this._longPressed = false; return; } this.app.detail.openForCompat(f); });
            card.addEventListener('touchstart', () => { pressTimer = setTimeout(() => { this._longPressed = true; this._showFriendMenu(f); }, 600); });
            card.addEventListener('touchend', () => { if (pressTimer) clearTimeout(pressTimer); });
            card.addEventListener('contextmenu', (e) => { e.preventDefault(); this._showFriendMenu(f); });
            cont.appendChild(card);
        }
    }

    _showFriendMenu(friend) {
        const choice = prompt(`${friend.name} さん:\n1) 編集\n2) 削除\nキャンセル: 何もしない\n番号を入力:`, '');
        if (choice === '1') this.openAddForm(friend);
        else if (choice === '2' && confirm(`${friend.name} さんを削除しますか？`)) {
            this.db.friendDelete(friend.id).then(() => { this.app.snackbar.notice('友達を削除しました。', 'success'); this.renderList(); });
        }
    }

    openAddForm(friend = null) {
        this.editingId = friend ? friend.id : null;
        const set = (id, val) => { const e = document.getElementById(id); if (e) e.value = val || ''; };
        set('compat-form-name', friend?.name);
        set('compat-form-date', friend?.date);
        set('compat-form-time', friend?.time);
        set('compat-form-place', friend?.place);
        set('compat-form-relation', friend?.relation);
        set('compat-form-note', friend?.note);
        const err = document.getElementById('compat-form-error');
        if (err) err.remove();
        const title = document.querySelector('#compat-form-screen h2');
        if (title) title.textContent = friend ? '友達を編集' : '友達を追加';
        const el = document.getElementById('compat-form-screen');
        el?.classList.remove('hidden');
        requestAnimationFrame(() => el?.classList.add('slide-in-active'));
    }

    closeAddForm() {
        const el = document.getElementById('compat-form-screen');
        if (!el) return;
        el.classList.remove('slide-in-active');
        setTimeout(() => el.classList.add('hidden'), 250);
    }

    async submitForm() {
        const get = (id) => document.getElementById(id)?.value?.trim?.() || document.getElementById(id)?.value || '';
        const name = get('compat-form-name');
        const date = get('compat-form-date');
        const time = get('compat-form-time');
        const place = get('compat-form-place');
        const relation = get('compat-form-relation');
        const note = get('compat-form-note');
        const error = document.getElementById('compat-form-error');
        if (!name) { this._formError('お名前は必須です。入力内容は保持しています。'); return; }
        if (!date) { this._formError('生年月日は必須です。入力内容は保持しています。'); return; }
        const now = Date.now();
        const id = this.editingId || `f${now}`;
        const old = this.editingId ? (await this.db.friendGet(this.editingId)) : null;
        const friend = { ...(old || {}), id, name, date, time, place, relation, note, compat: null, ts: old?.ts || now, createdAt: old?.createdAt || now, updatedAt: now };
        try {
            friend.compat = await this.buildLocalCompatibility(friend);
            await this.db.friendPut(id, friend);
            this.closeAddForm();
            await this.renderList();
            this.app.snackbar.notice(`${name} さんを登録しました。`, 'success');
            this.app.detail.openForCompat(friend);
        } catch (e) {
            console.error('[compat] save failed', e);
            this._formError('友達を保存できませんでした。入力内容は保持しています。もう一度保存してください。');
            this.app.snackbar.notice('友達登録に失敗しました。', 'error');
            await this._logAI({ feature: 'compat.friend_save', success: false, error: String(e?.message || e), ts: now });
        }
    }

    _formError(msg) {
        let box = document.getElementById('compat-form-error');
        const parent = document.querySelector('#compat-form-screen .bg-white');
        if (!box && parent) {
            box = document.createElement('div');
            box.id = 'compat-form-error';
            box.className = 'bg-red-50 border border-red-200 text-red-700 rounded-xl p-3 text-xs';
            parent.prepend(box);
        }
        if (box) box.textContent = msg;
        this.app.snackbar.notice(msg, 'error');
    }

    async buildLocalCompatibility(friend) {
        const profile = await this.db.get('profile') || {};
        if (!profile.date) throw new Error('自分のプロフィールが未設定です。');
        const me = AstrologyCompute.computeChart(profile, null);
        const them = AstrologyCompute.computeChart({ name: friend.name, date: friend.date, time: friend.time, place: friend.place }, null);
        return this._calculateCompatibility(me, them, friend);
    }

    _calculateCompatibility(me, them, friend) {
        const posA = this._posMap(me.planets), posB = this._posMap(them.planets);
        const aspects = AstrologyCompute.detectAspects(posA, posB, false);
        const score = { romance: 50, friendship: 50, work: 50, communication: 50, stability: 50, tension: 35 };
        const notes = [];
        const add = (k, v, label) => { score[k] = (score[k] || 0) + v; notes.push({ key: k, value: Math.round(v), label }); };
        const signRel = (a, b) => {
            const d = Math.abs((a.signIndex || 0) - (b.signIndex || 0));
            const x = Math.min(d, 12 - d);
            if ([0,4].includes(x)) return 12;
            if ([2].includes(x)) return 7;
            if ([3].includes(x)) return -8;
            if ([6].includes(x)) return -6;
            return 0;
        };
        add('friendship', signRel(me.planets.Sun, them.planets.Sun), '太陽同士の基本テンポ');
        add('tension', -signRel(me.planets.Sun, them.planets.Sun) * 0.25, '太陽同士の違い');
        add('romance', signRel(me.planets.Venus, them.planets.Mars), '金星と火星の惹かれ合い');
        add('communication', signRel(me.planets.Mercury, them.planets.Mercury), '水星同士の会話テンポ');
        add('friendship', signRel(me.planets.Moon, them.planets.Moon), '月同士の安心感');
        for (const a of aspects) {
            const pair = [a.p1, a.p2].sort().join('-');
            const tense = ['square','opposition'].includes(a.aspectEn);
            const flow = ['trine','sextile','conjunction'].includes(a.aspectEn);
            const v = Math.max(4, 12 - parseFloat(a.orb || 0));
            const label = `${this._planet(a.p1)}と相手${this._planet(a.p2)}の${a.aspect}`;
            if (pair.includes('Venus') && pair.includes('Mars')) add('romance', tense ? -v : v, label);
            if (pair.includes('Mercury')) add('communication', tense ? -v : v, label);
            if (pair.includes('Moon')) add('friendship', tense ? -v : v, label);
            if (pair.includes('Saturn')) add('stability', tense ? -v * 0.6 : v, label);
            if (pair.includes('Pluto')) { add('tension', tense ? v : v * 0.5, label); add('romance', v * 0.4, label); }
        }
        Object.keys(score).forEach(k => score[k] = Math.round(Math.max(0, Math.min(100, score[k]))));
        const total = Math.round((score.romance + score.friendship + score.work + score.communication + score.stability + (100 - score.tension)) / 6);
        score.total = Math.max(0, Math.min(100, total));
        const hasTime = !!friend.time;
        const hasPlace = !!friend.place;
        const precision = hasTime && hasPlace ? '高め' : hasTime || hasPlace ? '標準' : '限定';
        const top = Object.entries(score).filter(([k])=>!['total','tension'].includes(k)).sort((a,b)=>b[1]-a[1])[0];
        const weak = Object.entries(score).filter(([k])=>!['total'].includes(k)).sort((a,b)=>a[1]-b[1])[0];
        const comments = {
            romance: this._compatComment('恋愛・惹かれ合い', score.romance),
            friendship: this._compatComment('安心感・友情', score.friendship),
            work: this._compatComment('仕事・協力', score.work),
            communication: this._compatComment('会話・理解', score.communication),
            stability: this._compatComment('長期安定性', score.stability),
            tension: score.tension >= 65 ? '衝突・執着・主導権争いが出やすい相性です。良い面だけでなく、力関係が偏る可能性をそのまま見ておく必要があります。' : '緊張はありますが、扱い方次第で刺激や成長につながります。'
        };
        return {
            mode: 'local-rule', precision, dataStatus: { birthTime: !!friend.time, birthPlace: !!friend.place, note: hasTime && hasPlace ? 'ASC・ハウスも参考にできます。' : '出生時間または出生地がないため、ASC・MC・ハウスは参考度を下げています。' },
            scores: score,
            comments,
            overall: `ふたり全体では「${this._scoreLabel(top?.[0])}」が最も使いやすく、「${this._scoreLabel(weak?.[0])}」は意識的な扱いが必要です。`,
            attraction: comments.romance,
            friction: comments.tension,
            advice: ['相手を変えようとする前に、反応が強く出る場面を特定する', '大事な話は短く結論から伝える', '合う部分とぶつかる部分を分けて見る'],
            summary: `総合相性は${score.total}。${comments.friendship} ${comments.communication} ${comments.tension}`,
            evidence: notes.sort((a,b)=>Math.abs(b.value)-Math.abs(a.value)).slice(0, 10),
            plutoLayer: { active: aspects.some(a => a.p1 === 'Pluto' || a.p2 === 'Pluto'), theme: '強い引力と支配・執着テーマ', note: '冥王星が絡む場合、関係が深くなりやすい一方で、力関係・依存・執着が出る可能性もあります。' },
            ai: { available: true, requiresPayment: true, featureId: 'compat.ai_detail' }
        };
    }

    _compatComment(label, v) {
        if (v >= 75) return `${label}は強いです。自然に噛み合いやすく、関係を進める力になります。`;
        if (v >= 58) return `${label}は使いやすい範囲です。ただし、流れ任せより確認を入れる方が安定します。`;
        if (v >= 42) return `${label}は中程度です。合う部分とズレる部分が混在します。`;
        return `${label}は課題が出やすいです。放置するとすれ違いや不満が積み上がる可能性があります。`;
    }

    async generateCompatibility(friend) {
        // 従来互換: 解析失敗を起こさないため、基本相性は常にローカルで再計算する。
        try {
            friend.compat = await this.buildLocalCompatibility(friend);
            await this.db.friendPut(friend.id, friend);
            await this.renderList();
            this.app.snackbar.notice('基本相性を更新しました。', 'success');
            if (this.app.detail.currentMode === 'compat' && this.app.detail.currentFriend?.id === friend.id) this.app.detail.openForCompat(friend);
        } catch (e) {
            this.app.snackbar.notice('相性の基本計算に失敗しました。', 'error');
        }
    }

    async generateAiDetail(friend) {
        const base = friend.compat || await this.buildLocalCompatibility(friend);
        const me = await this.app.profile.getProfileString();
        if (!me) return this.app.showError('まず自分のプロフィールを設定してください。');
        const featureId = 'compat.ai_explanation';
        const promptBase = await this.app.config.getPrompt('prompt_compat_detail');
        const compactBase = {
            precision: base.precision,
            dataStatus: base.dataStatus,
            scores: base.scores,
            overall: base.overall,
            attraction: base.attraction,
            friction: base.friction,
            advice: base.advice,
            evidence: (base.evidence || []).slice(0, 8),
            plutoLayer: base.plutoLayer
        };
        const prompt = `${promptBase}\n\n【自分】${me}\n【相手】${friend.name} ${friend.date} ${friend.time || '出生時間不明'} ${friend.place || '出生地不明'} ${friend.relation || ''}\n【ローカル相性結果】${JSON.stringify(compactBase)}`;
        const taskId = `compat-ai-${friend.id}-${Date.now()}`;
        await this._logAI({ feature: featureId, provider: 'selected', model: 'selected', requiresPayment: true, startedAt: Date.now(), success: null });
        this._renderAiDetail('<p class="text-xs text-slate-500"><i class="fa-solid fa-circle-notch animate-spin text-astro mr-1"></i>相性AI解説を生成中です。</p>');
        return this.app.startGeneration({
            taskId,
            taskLabel: `${friend.name} さんとの相性AI解説を生成中…`,
            prompt,
            isJson: false,
            costsTrial: false,
            featureId,
            requiresPayment: true,
            maxTokens: 1200,
            temperature: 0.65,
            onProgress: (text) => this._renderAiDetail(String(text || '').slice(0, 2600) + ' ▍'),
            onDone: async (text) => {
                const finalText = String(text || '').trim();
                friend.compat = { ...base, aiDetail: finalText, aiDetailUpdatedAt: Date.now(), aiFeatureId: featureId };
                await this.db.friendPut(friend.id, friend);
                this._renderAiDetail(this.app.renderMarkdown(finalText));
                this.app.snackbar.succeed(taskId, '✓ 相性AI解説を生成しました');
                await this._logAI({ feature: featureId, requiresPayment: true, success: true, outputChars: finalText.length, ts: Date.now() });
            },
            onError: async (msg) => {
                this._renderAiError('相性AI解説の生成に失敗しました。基本相性は表示されています。');
                this.app.snackbar.fail(taskId, msg, () => this.generateAiDetail(friend));
                await this._logAI({ feature: featureId, requiresPayment: true, success: false, error: msg, ts: Date.now() });
            }
        });
    }

    _renderAiDetail(text) {
        const el = document.getElementById('compat-ai-detail');
        if (el) el.innerHTML = this.app.renderMarkdown(text || '');
    }
    _renderAiError(text) { const el = document.getElementById('compat-ai-detail'); if (el) el.innerHTML = `<p class="text-xs text-red-700 bg-red-50 border border-red-100 rounded-xl p-3">${this._esc(text)}</p>`; }

    async _logAI(row) {
        const cur = (await this.db.get('ai_usage_log')) || [];
        cur.push({ ...row, id: `log_${Date.now()}_${Math.random().toString(36).slice(2)}` });
        await this.db.set('ai_usage_log', cur.slice(-200));
    }

    _posMap(planets) { const out = {}; for (const k of Object.keys(planets || {})) out[k] = planets[k].longitude; return out; }
    _planet(k) { return AstrologyCompute.planets().find(p=>p.key===k)?.ja || k; }
    _precisionLabel(f) { return f.time && f.place ? '高め' : f.time || f.place ? '標準' : '限定'; }
    _scoreLabel(k) { return ({ romance:'恋愛・惹かれ合い', friendship:'安心感・友情', work:'仕事・協力', communication:'会話・理解', stability:'長期安定性', tension:'衝突リスク' })[k] || k || '不明'; }
    _friendHash(f) { const s = `${f.name}|${f.date}|${f.time}|${f.place}|${f.relation}|${f.note}`; let h=0; for(let i=0;i<s.length;i++){ h=((h<<5)-h)+s.charCodeAt(i); h|=0; } return Math.abs(h).toString(36); }
    _parseJsonObject(text) { try { let clean = String(text||'').replace(/```json/gi,'').replace(/```/g,'').trim(); const s=clean.indexOf('{'), e=clean.lastIndexOf('}'); if(s!==-1 && e!==-1) clean=clean.substring(s,e+1); return JSON.parse(clean); } catch(e){ return null; } }
    _esc(s) { return String(s == null ? '' : s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
}

window.CompatComponent = CompatComponent;
