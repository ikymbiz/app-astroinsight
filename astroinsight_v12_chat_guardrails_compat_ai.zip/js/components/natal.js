/* ============================================================
 * AstroInsight - Natal Analysis Component（v6）
 *   - 設定画面内の既存ネイタル表示は維持
 *   - メインの「ネイタル」独立タブにも出生図・要約・AI分析を表示
 * ============================================================ */

class NatalComponent {
    constructor(app) {
        this.app = app;
        this.db = app.db;
        this.renderer = null;
    }

    async cacheKey() {
        const h = await this.app.profile.getProfileHash();
        return `natal_${h}`;
    }

    async load() {
        this._renderChartAndSummary();
        const k = await this.cacheKey();
        const cached = await this.db.cacheGet(k);
        if (cached) this._render(cached.text);
        else this._renderEmptyAnalysis();
    }

    /** ネイタル分析を生成（要件§7） */
    async generate(opts = {}) {
        const p = await this.app.profile.getProfileString();
        if (!p) return alert('プロフィールを設定してください。');
        const sysPrompt = await this.app.config.getPrompt('prompt_natal');
        const prompt = `${sysPrompt}\n\n以下のプロフィールから、ネイタルチャート（出生図）に基づく本質的な性格・人生の傾向の分析を行ってください。\n専門用語は避けつつ、絵文字を交えて読みやすく表現してください。\nプロフィール: ${p}`;
        const k = await this.cacheKey();
        await this.app.startGeneration({
            taskId: 'natal',
            taskLabel: 'ネイタル分析を生成中…',
            prompt,
            isJson: false,
            featureId: 'natal.ai_detail',
            requiresPayment: true,
            onProgress: (text) => this._render(text + ' ▍'),
            onDone: async (text) => {
                await this.db.cacheSet(k, { text, ts: Date.now() });
                this._renderChartAndSummary();
                this._render(text);
                if (typeof opts.onComplete === 'function') opts.onComplete(text);
            },
            onError: (msg) => {
                if (typeof opts.onError === 'function') opts.onError(msg);
                else this.app.snackbar.fail('natal', msg, () => this.generate());
            }
        });
    }

    _render(text) {
        ['natal-result', 'natal-tab-result', 'onb-natal-result'].forEach((id) => {
            const el = document.getElementById(id);
            if (el) el.innerHTML = this.app.renderMarkdown(text || '');
        });
    }

    _renderEmptyAnalysis() {
        const el = document.getElementById('natal-tab-result');
        if (el) el.innerHTML = '<p class="text-sm text-slate-400">「詳しく生成」を押すと、AIによるネイタル総合分析を作成します。出生図と要約はAIなしで表示されています。</p>';
    }

    async _renderChartAndSummary() {
        const profile = await this.db.get('profile') || {};
        const svg = document.getElementById('natal-tab-horoscope-svg');
        const summary = document.getElementById('natal-tab-summary');
        if (!profile.date) {
            if (summary) summary.innerHTML = '<p class="text-sm text-slate-400">プロフィールを設定すると出生図を表示します。</p>';
            return;
        }
        let chart;
        try { chart = AstrologyCompute.computeChart(profile, null); }
        catch (e) {
            if (summary) summary.innerHTML = `<p class="text-sm text-red-500">出生図の計算に失敗しました: ${this._esc(e.message || e)}</p>`;
            return;
        }
        if (svg && window.HoroscopeRenderer) {
            if (!this.renderer) this.renderer = new HoroscopeRenderer(svg, { size: 320 });
            this.renderer.setCharts(chart, null, 'natal');
        }
        if (summary) summary.innerHTML = this._summaryHtml(chart);
    }

    _summaryHtml(chart) {
        const rows = ['Sun', 'Moon', 'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'Uranus', 'Neptune', 'Pluto'].map((k) => {
            const p = chart.planets[k];
            if (!p) return '';
            return `<div class="bg-slate-50 rounded-xl p-2 border border-slate-100">
                <div class="text-xs font-bold text-slate-700">${p.symbol} ${this._esc(p.ja)}</div>
                <div class="text-[10px] text-slate-500">${this._esc(p.signName)} ${p.degInSign.toFixed(1)}° / 第${p.house}ハウス</div>
                <div class="text-[10px] text-slate-400">${this._esc(AstrologyCompute.houseMeaning(p.house))}</div>
            </div>`;
        }).join('');
        const asc = AstrologyCompute.signFromLongitude(chart.ASC);
        const mc = AstrologyCompute.signFromLongitude(chart.MC);
        return `<h3 class="font-bold text-sm mb-2 text-slate-800">出生図の基本要素</h3>
            <div class="grid grid-cols-2 gap-2 mb-3">
                <div class="bg-astro-light rounded-xl p-3"><div class="text-xs font-bold text-astro">ASC</div><div class="text-sm font-bold">${this._esc(asc.signName)}</div><div class="text-[10px] text-slate-500">印象・出方</div></div>
                <div class="bg-astro-light rounded-xl p-3"><div class="text-xs font-bold text-astro">MC</div><div class="text-sm font-bold">${this._esc(mc.signName)}</div><div class="text-[10px] text-slate-500">仕事・社会的方向</div></div>
            </div>
            <div class="grid grid-cols-2 gap-2">${rows}</div>`;
    }

    _esc(s) {
        return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }
}

window.NatalComponent = NatalComponent;
