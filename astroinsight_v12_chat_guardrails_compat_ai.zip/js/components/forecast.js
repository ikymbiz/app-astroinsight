/* ============================================================
 * AstroInsight - Forecast Component（v8 rule-based + slider）
 *   - 自動表示: プロフィールがあれば占うボタンなしで表示
 *   - スライダー/前後ボタン/グラフを同期
 *   - 全体の大きな流れ + 各時点の差分説明を表示
 *   - 詳細AIはユーザー操作時のみ
 * ============================================================ */

class ForecastComponent {
    constructor(app) {
        this.app = app;
        this.db = app.db;
        this.forecastType = 'daily';
        this.selectedIndex = 0;
        this._lastData = null;
        this._userContext = { focus: 'balanced', mood: 'normal', reasonLevel: 'standard' };
    }

    async load(opts = {}) {
        const ac = this.app.config?.getAppConfig?.() || {};
        if (opts.applyDefault && ac.forecast?.defaultGranularity) this.forecastType = ac.forecast.defaultGranularity;
        await this._loadUserContext();
        this._syncGranularityButtons();
        this._syncContextInputs();
        const c = await this.db.cacheGet(this._cacheKey());
        if (c?.data) this._render(c.data);
        else {
            const profile = await this.db.get('profile') || {};
            if (profile.date) await this.generate({ silent: true });
            else this._renderEmpty();
        }
    }

    async _loadUserContext() {
        if (!window.ForecastEngine) return;
        this._userContext = await ForecastEngine.getUserContext(this.db);
    }

    _appConfig() { return this.app.config?.getAppConfig?.() || {}; }
    _cacheKey() { return ForecastEngine.cacheKey(this.forecastType, this._appConfig()); }

    async refresh() {
        await this.db.cacheDelete(this._cacheKey());
        await this.generate({ silent: false });
    }

    async saveUserContext() {
        const focus = document.getElementById('forecast-focus')?.value || 'balanced';
        const mood = document.getElementById('forecast-mood')?.value || 'normal';
        this._userContext = await ForecastEngine.saveUserContext(this.db, { focus, mood });
        await this.db.cacheDelete(this._cacheKey());
        await this.generate({ silent: true });
    }

    _syncContextInputs() {
        const f = document.getElementById('forecast-focus');
        const m = document.getElementById('forecast-mood');
        if (f) f.value = this._userContext.focus || 'balanced';
        if (m) m.value = this._userContext.mood || 'normal';
    }

    async generate(opts = {}) {
        const profile = await this.db.get('profile') || {};
        if (!profile.date) return this._renderEmpty('プロフィールを設定すると、予報を自動表示します。');
        if (!window.ForecastEngine || !window.AstrologyCompute) return this.app.showError('予報エンジンの読み込みに失敗しました。');
        const type = this.forecastType;
        const taskId = `forecast-local-${type}`;
        try {
            if (!opts.silent) this.app.snackbar.start(taskId, `予報（${this._granLabel(type)}）を計算中…`);
            await this._loadUserContext();
            let data = ForecastEngine.generate({ profile, type, appConfig: this._appConfig(), userContext: this._userContext, now: new Date() });
            data = this._enrichFlow(data);
            await this.db.cacheSet(this._cacheKey(), { data, ts: Date.now(), type, mode: 'rule-based' });
            if (this.forecastType === type) {
                this.selectedIndex = Math.min(this.selectedIndex || 0, data.length - 1);
                this._render(data);
            }
            if (!opts.silent) this.app.snackbar.succeed(taskId, '✓ 予報を更新しました');
        } catch (e) {
            console.error('[forecast] local generation failed', e);
            this.app.snackbar.fail(taskId, '予報計算に失敗しました: ' + (e?.message || e), () => this.generate({ silent: false }));
        }
    }

    async prefetchMonthlyInBackground() {
        if (this._prefetched) return;
        this._prefetched = true;
        const old = this.forecastType;
        this.forecastType = 'monthly';
        await this.db.cacheGet(this._cacheKey());
        this.forecastType = old;
    }

    _granLabel(g) { return ({ monthly: '月次', weekly: '週次', daily: '日次', hourly: '時間' })[g] || g; }

    _syncGranularityButtons() {
        ['monthly', 'weekly', 'daily', 'hourly'].forEach((t) => {
            const btn = document.getElementById(`fc-btn-${t}`);
            if (!btn) return;
            if (t === this.forecastType) {
                btn.classList.add('active', 'bg-astro', 'text-white');
                btn.classList.remove('bg-white', 'text-slate-600');
            } else {
                btn.classList.remove('active', 'bg-astro', 'text-white');
                btn.classList.add('bg-white', 'text-slate-600');
            }
        });
    }

    _renderEmpty(message) {
        const cont = document.getElementById('forecast-selected');
        if (cont) cont.innerHTML = `<div class="text-center text-slate-400 py-6"><p class="text-sm">${this._esc(message || 'プロフィールを設定すると、AIを使わず予報タイムラインを自動表示します。')}</p></div>`;
        const panel = document.getElementById('forecast-slider-panel');
        if (panel) panel.classList.add('hidden');
        if (this.app.chartInstance) { this.app.chartInstance.destroy(); this.app.chartInstance = null; }
    }

    _render(data) {
        if (!data || !data.length) return;
        this._lastData = data;
        if (this.selectedIndex >= data.length) this.selectedIndex = data.length - 1;
        if (this.selectedIndex < 0) this.selectedIndex = 0;
        this._renderChart(data);
        this._renderSlider(data);
        const item = data[this.selectedIndex];
        const cont = document.getElementById('forecast-selected');
        if (cont) cont.innerHTML = this._renderOverallFlowHtml(data) + this._renderRecommendationsHtml(data) + this._renderItemHtml(item);
        this._bindItemActions(item);
    }

    _renderChart(data) {
        const cv = document.getElementById('forecastChart');
        if (!cv || typeof Chart === 'undefined') return;
        const ctx = cv.getContext('2d');
        const labels = data.map((d) => d.period || '');
        const impacts = data.map((d) => parseInt(d.impact) || 0);
        const pointBg = data.map((_, i) => (i === this.selectedIndex ? '#ef4444' : (i === 0 ? '#fbbf24' : '#fff')));
        const pointRad = data.map((_, i) => (i === this.selectedIndex ? 9 : (i === 0 ? 7 : 5)));
        if (this.app.chartInstance) this.app.chartInstance.destroy();
        this.app.chartInstance = new Chart(ctx, {
            type: 'line',
            data: { labels, datasets: [{ label: '体感しやすさ', data: impacts, borderColor: '#4f46e5', backgroundColor: 'rgba(79,70,229,0.18)', tension: 0.35, fill: true, pointHitRadius: 22, pointHoverRadius: 9, pointBackgroundColor: pointBg, pointBorderColor: '#4f46e5', pointBorderWidth: 2, pointRadius: pointRad }] },
            options: {
                responsive: true, maintainAspectRatio: false,
                scales: { y: { min: 0, max: 100 }, x: { ticks: { maxTicksLimit: 6 } } },
                plugins: { legend: { display: false }, tooltip: { intersect: false, mode: 'nearest' } },
                interaction: { intersect: false, mode: 'nearest' }, animation: { duration: 180 },
                onClick: (evt, els) => {
                    if (!els || !els.length) return;
                    this.selectedIndex = els[0].index;
                    this._render(this._lastData);
                }
            }
        });
    }

    _renderSlider(data) {
        const panel = document.getElementById('forecast-slider-panel');
        const slider = document.getElementById('forecast-slider');
        const label = document.getElementById('forecast-current-label');
        const prev = document.getElementById('forecast-prev');
        const next = document.getElementById('forecast-next');
        if (!panel || !slider) return;
        panel.classList.remove('hidden');
        slider.min = 0;
        slider.max = Math.max(0, data.length - 1);
        slider.value = this.selectedIndex;
        const item = data[this.selectedIndex] || {};
        if (label) label.textContent = `${item.period || ''} / ${item.theme || ''} / ${item.impact || 0}`;
        slider.oninput = () => { this.selectedIndex = parseInt(slider.value, 10) || 0; this._render(this._lastData); };
        if (prev) prev.onclick = () => { this.selectedIndex = Math.max(0, this.selectedIndex - 1); this._render(this._lastData); };
        if (next) next.onclick = () => { this.selectedIndex = Math.min(data.length - 1, this.selectedIndex + 1); this._render(this._lastData); };
    }

    _enrichFlow(items) {
        if (!Array.isArray(items) || !items.length) return items;
        const labels = { action: '行動', focus: '集中', relationship: '対人', communication: '連絡・整理', emotion: '感情', rest: '休息', change: '変化' };
        const topKey = (it) => Object.entries(it.scores || {}).sort((a,b)=>b[1]-a[1])[0]?.[0] || 'action';
        const first = items[0], mid = items[Math.floor(items.length / 2)], last = items[items.length - 1];
        const peak = items.slice().sort((a,b)=>(b.impact||0)-(a.impact||0))[0];
        const caution = items.slice().sort((a,b)=>(b.scores?.emotion||0)-(a.scores?.emotion||0))[0];
        const flow = {
            title: `${this._granLabel(this.forecastType)}の大きな流れ`,
            summary: `${first.period}は「${first.theme}」から始まり、中盤は「${mid.theme}」、終盤は「${last.theme}」へ移ります。ピークは${peak.period}前後で、${labels[topKey(peak)] || '行動'}の流れが強まります。注意が必要なのは${caution.period}前後で、感情や反応が強く出やすい配置です。`,
            phases: [
                `入口：${first.period}は${labels[topKey(first)] || '行動'}寄り。`,
                `中盤：${mid.period}は${labels[topKey(mid)] || '行動'}寄り。`,
                `終盤：${last.period}は${labels[topKey(last)] || '行動'}寄り。`
            ]
        };
        return items.map((it, i) => {
            const prev = items[i - 1];
            const next = items[i + 1];
            const key = topKey(it), pk = prev ? topKey(prev) : null;
            let diff;
            if (!prev) diff = `この期間の入口です。まず「${it.theme}」が立ち上がります。`;
            else if (key !== pk) diff = `前の時点より「${labels[key] || it.theme}」へ流れが切り替わります。${it.period}は${it.theme}として使う方が合います。`;
            else {
                const delta = (it.impact || 0) - (prev.impact || 0);
                diff = Math.abs(delta) < 4
                    ? `前の時点と大きな差はありません。同じテーマが続くため、無理に切り替えるより継続が向きます。`
                    : delta > 0
                        ? `前の時点より体感が強まります。同じテーマでも、より外へ出しやすい流れです。`
                        : `前の時点より落ち着きます。同じテーマを整える・見直す方向に使いやすい流れです。`;
            }
            const nextText = next ? `次は「${next.theme}」へつながります。` : 'ここでこの期間の流れが締まります。';
            return { ...it, overallFlow: flow, diffReason: diff, nextFlow: nextText };
        });
    }

    _renderOverallFlowHtml(data) {
        const f = data[0]?.overallFlow;
        if (!f) return '';
        return `<section class="bg-white rounded-2xl border border-slate-100 p-4 mb-3 border-l-4 border-l-indigo-400">
            <h3 class="font-bold text-sm text-slate-800 mb-2"><i class="fa-solid fa-wave-square text-astro mr-1"></i>${this._esc(f.title)}</h3>
            <p class="text-xs text-slate-700 leading-relaxed mb-2">${this._esc(f.summary)}</p>
            <div class="grid grid-cols-1 gap-1">${f.phases.map((x)=>`<p class="text-[10px] bg-slate-50 rounded-lg p-2 text-slate-600">${this._esc(x)}</p>`).join('')}</div>
        </section>`;
    }

    _renderRecommendationsHtml(data) {
        if (!window.ForecastEngine) return '';
        const r = ForecastEngine.topRecommendations(data);
        const chip = (title, items, icon) => `<div class="bg-white rounded-xl border border-slate-100 p-3">
            <h4 class="text-[11px] font-bold text-slate-700 mb-1"><i class="${icon} mr-1 text-astro"></i>${this._esc(title)}</h4>
            <div class="flex flex-wrap gap-1">${items.map((it) => `<button data-pick-index="${it.index}" class="text-[10px] bg-astro-light text-astro px-2 py-1 rounded-full font-bold">${this._esc(it.period)}</button>`).join('')}</div>
        </div>`;
        setTimeout(() => document.querySelectorAll('[data-pick-index]').forEach((btn) => { btn.onclick = () => { this.selectedIndex = parseInt(btn.dataset.pickIndex, 10) || 0; this._render(this._lastData); }; }), 0);
        return `<div class="grid grid-cols-2 gap-2 mb-3">
            ${chip('動くなら', r.action, 'fa-solid fa-person-running')}
            ${chip('集中するなら', r.focus, 'fa-solid fa-bullseye')}
            ${chip('対人・連絡', r.relationship, 'fa-solid fa-comments')}
            ${chip('休むなら', r.rest, 'fa-solid fa-moon')}
        </div>`;
    }

    _renderItemHtml(it) {
        if (!it) return '';
        const impact = Math.max(0, Math.min(100, parseInt(it.impact || 0)));
        const scores = it.scores || {};
        const scoreRows = [['action','行動しやすさ'],['focus','集中しやすさ'],['relationship','対人のしやすさ'],['communication','連絡・整理'],['emotion','感情の揺れやすさ'],['rest','休息の必要度'],['change','変化の強さ']].map(([k,l])=>this._scoreBar(l, scores[k]||0)).join('');
        const factors = it.reasons?.factors || it.astroReason?.factors || [];
        const breakdown = Array.isArray(it.scoreBreakdown) ? it.scoreBreakdown : [];
        const list = (arr) => Array.isArray(arr) && arr.length ? `<ul class="list-disc pl-5 text-xs text-slate-700 leading-relaxed">${arr.map((s)=>`<li>${this._esc(s)}</li>`).join('')}</ul>` : '';
        return `<article class="bg-white rounded-2xl shadow-sm border border-slate-100 p-4 border-l-4 border-l-astro">
            <div class="flex justify-between gap-3 mb-2"><div><div class="text-[10px] text-slate-400">${this._esc(this._granLabel(this.forecastType))}</div><h3 class="font-bold text-slate-800 text-base">${this._esc(it.period || '')}</h3></div><span class="text-xs font-bold px-2 py-1 rounded-full bg-astro-light text-astro border border-indigo-200 shrink-0">体感しやすさ: ${impact}</span></div>
            <p class="text-sm text-slate-700 mb-2"><b>ひとことで言うと：</b>${this._esc(it.theme || '')}</p>
            <p class="text-xs text-slate-600 leading-relaxed mb-3">${this._esc(it.description || '')}</p>
            <section class="bg-indigo-50 rounded-xl p-3 mb-2 border border-indigo-100"><h4 class="text-xs font-bold text-indigo-700 mb-1">前後との違い</h4><p class="text-xs text-slate-700 leading-relaxed">${this._esc(it.diffReason || '')} ${this._esc(it.nextFlow || '')}</p></section>
            <section class="bg-slate-50 rounded-xl p-3 mb-2"><h4 class="text-xs font-bold text-astro mb-1">生活上の理由</h4><p class="text-xs text-slate-700 leading-relaxed">${this._esc(it.reasons?.life || '')}</p></section>
            <section class="bg-slate-50 rounded-xl p-3 mb-2"><h4 class="text-xs font-bold text-astro mb-1">あなたの場合</h4><p class="text-xs text-slate-700 leading-relaxed">${this._esc(it.reasons?.personal || '')}</p></section>
            <details class="bg-white rounded-xl p-3 mb-2 border border-slate-100" open><summary class="text-xs font-bold text-slate-700 cursor-pointer">スコア内訳</summary><div class="mt-2 space-y-1">${scoreRows}</div>${breakdown.length ? `<ul class="mt-2 text-[10px] text-slate-500 space-y-0.5">${breakdown.map((b)=>`<li>${b.value >= 0 ? '+' : ''}${this._esc(b.value)} ${this._esc(b.label)}</li>`).join('')}</ul>` : ''}</details>
            <div class="grid grid-cols-2 gap-2"><section class="bg-emerald-50 rounded-xl p-3 border border-emerald-100"><h4 class="text-xs font-bold text-emerald-700 mb-1">具体的にするとよい行動</h4>${list(it.recommendations?.do)}</section><section class="bg-amber-50 rounded-xl p-3 border border-amber-100"><h4 class="text-xs font-bold text-amber-700 mb-1">気をつけること</h4>${list(it.recommendations?.avoid)}</section></div>
            <details class="bg-white rounded-xl p-3 mt-2 border border-slate-100"><summary class="text-xs font-bold text-slate-700 cursor-pointer">占星術的根拠を見る</summary><p class="text-xs text-slate-700 leading-relaxed mt-2">${this._esc(it.reasons?.astroSummary || it.astroReason?.summary || '')}</p>${factors.length ? `<ul class="list-disc pl-5 text-xs text-slate-700 leading-relaxed mt-1">${factors.slice(0,6).map((f)=>`<li><b>${this._esc(f.label)}</b>：${this._esc(f.meaning)}</li>`).join('')}</ul>` : ''}</details>
            <div class="grid grid-cols-2 gap-2 mt-3"><button data-detail class="bg-astro hover:bg-astro-dark text-white font-bold py-2 rounded-lg text-xs"><i class="fa-solid fa-arrow-right-long mr-1"></i> AIで詳しく読む</button><button data-ask class="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-2 rounded-lg text-xs"><i class="fa-solid fa-comment-dots mr-1"></i> AIに質問</button></div>
        </article>`;
    }

    _scoreBar(label, value) {
        const v = Math.max(0, Math.min(100, parseInt(value || 0)));
        return `<div><div class="flex justify-between text-[10px] text-slate-500 mb-0.5"><span>${this._esc(label)}</span><b>${v}</b></div><div class="h-1.5 bg-slate-100 rounded-full overflow-hidden"><div class="h-full bg-astro" style="width:${v}%"></div></div></div>`;
    }

    _bindItemActions(item) {
        const cont = document.getElementById('forecast-selected');
        if (!cont) return;
        cont.querySelector('[data-detail]')?.addEventListener('click', () => this.app.detail.openForForecast({ ...item, forecastType: this.forecastType, autoGenerate: false }));
        cont.querySelector('[data-ask]')?.addEventListener('click', () => { this.app.chat.setContext(`予報「${item.period} - ${item.theme}」について`); this.app.ui.switchTab('chat'); });
    }

    _esc(s) { return String(s == null ? '' : s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
}

window.ForecastComponent = ForecastComponent;
