/* ============================================================
 * AstroInsight - Detail Screen Component（v6）
 * 要件§11 §12 §13 §18 共通の詳細画面：
 *   - ホロスコープ図SVG（ネイタル単独 ↔ 二重円切替、要件§8）
 *   - 天体タップでツールチップ表示
 *   - AI生成テキスト（トランジット影響・アドバイス／相性総合読み解き）
 *   - 「AIに質問」ボタン → チャットへ文脈引き継ぎ遷移
 *   - 🔄更新ボタンで強制再生成
 * v6 README 追加要件：
 *   - ハウス分布（HOUSE_MEANINGS）
 *   - 重要根拠（plutoLayer + astroReason）
 *   - 天体位置補助情報（details要素で折りたたみ）
 *
 * 開き方:
 *   - openForToday({theme,summary,advice,impact,segment})
 *   - openForForecast({period,theme,description,impact,forecastType,...})
 *   - openForCompat(friend)
 * ============================================================ */

class DetailComponent {
    constructor(app) {
        this.app = app;
        this.db = app.db;
        this.currentMode = null; // 'today' | 'forecast' | 'compat'
        this.currentPayload = null;
        this.currentFriend = null;
        this.renderer = null;
        this._tooltipEl = null;
    }

    _ensureRenderer() {
        if (this.renderer) return;
        const svg = document.getElementById('detail-horoscope-svg');
        if (!svg) return;
        this.renderer = new HoroscopeRenderer(svg, {
            size: 320,
            onPlanetTap: (key, ring) => this._showTooltip(key, ring)
        });
        // ツールチップ外タップで閉じる（要件§8）
        document.addEventListener('click', (e) => {
            if (this._tooltipEl && !this._tooltipEl.contains(e.target) && !e.target.closest('#detail-horoscope-svg')) {
                this._hideTooltip();
            }
        });
    }

    onClose() {
        this._hideTooltip();
        this.currentMode = null;
        this.currentPayload = null;
        this.currentFriend = null;
    }

    // ---- 「今日」から ----
    async openForToday(payload) {
        this.currentMode = 'today';
        this.currentPayload = payload;
        this.currentFriend = null;
        const t = document.getElementById('detail-title');
        if (t) t.textContent = `${payload.segment === 'day' ? '今日' : payload.segment === 'week' ? '今週' : '今月'}の詳細`;
        this._ensureRenderer();
        const profile = await this.db.get('profile') || {};
        const natal = AstrologyCompute.computeChart(profile, null);
        const transit = AstrologyCompute.computeChart(profile, new Date());
        this.renderer.setCharts(natal, transit, 'dual');
        this._renderHouseDistribution(transit);
        this._renderPositionsTable(natal, transit);
        const txtEl = document.getElementById('detail-text');
        if (txtEl) txtEl.innerHTML = '<p class="text-slate-400 text-sm">解説を生成中…</p>';
        this.app.ui.openDetail();
        await this._generateForToday(payload);
    }

    async _generateForToday(payload) {
        const me = await this.app.profile.getProfileString();
        if (!me) return;
        const sysPrompt = await this.app.config.getPrompt('prompt_detail');
        const period = payload.segment === 'day' ? '今日' : payload.segment === 'week' ? '今週' : '今月';
        const prompt = `${sysPrompt}\n\n【ネイタル】${me}\n【期間】${period}\n【サマリーテーマ】${payload.theme || ''}\n【概要】${payload.summary || ''}\nこの人物の出生図に対する${period}の星の影響を、各天体のアスペクトとともに具体的に解説し、行動アドバイスを与えてください。`;
        const taskId = `detail-today-${Date.now()}`;
        await this.app.startGeneration({
            taskId,
            taskLabel: `${period}の詳細を解説中…`,
            prompt,
            isJson: false,
            costsTrial: false,
            featureId: 'today.ai_detail',
            requiresPayment: true,
            onProgress: (text) => {
                const e = document.getElementById('detail-text');
                if (e) e.innerHTML = this.app.renderMarkdown(text + ' ▍');
            },
            onDone: (text) => {
                const e = document.getElementById('detail-text');
                if (e) e.innerHTML = this.app.renderMarkdown(text);
                this.app.snackbar.succeed(taskId, '✓ 解説を生成しました');
            },
            onError: (msg) => this.app.snackbar.fail(taskId, msg, () => this._generateForToday(payload))
        });
    }

    // ---- 「予報」から ----
    async openForForecast(payload) {
        this.currentMode = 'forecast';
        this.currentPayload = payload;
        this.currentFriend = null;
        const t = document.getElementById('detail-title');
        if (t) t.textContent = `予報: ${payload.period}`;
        this._ensureRenderer();
        const profile = await this.db.get('profile') || {};
        const natal = AstrologyCompute.computeChart(profile, null);
        const when = payload.startIso ? new Date(payload.startIso) : (this._guessDateFromPeriod(payload.period) || new Date());
        const transit = AstrologyCompute.computeChart(profile, when);
        this.renderer.setCharts(natal, transit, 'dual');
        this._renderHouseDistribution(transit);
        this._renderPositionsTable(natal, transit);
        const txtEl = document.getElementById('detail-text');
        if (txtEl) txtEl.innerHTML = this._renderForecastBaseHtml(payload);
        this.app.ui.openDetail();
        if (payload.autoGenerate) await this._generateForForecast(payload);
    }

    _renderForecastBaseHtml(payload) {
        const esc = (v) => this._esc(v);
        const scores = payload.scores || {};
        const rec = payload.recommendations || {};
        const scoreRow = (label, key) => {
            const v = Math.max(0, Math.min(100, parseInt(scores[key] || 0)));
            return `<div class="mb-1"><div class="flex justify-between text-[10px] text-slate-500"><span>${esc(label)}</span><b>${v}</b></div><div class="h-1.5 bg-slate-100 rounded-full overflow-hidden"><div class="h-full bg-astro" style="width:${v}%"></div></div></div>`;
        };
        const list = (arr) => Array.isArray(arr) && arr.length ? `<ul class="list-disc pl-5 text-xs text-slate-700 leading-relaxed">${arr.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>` : '<p class="text-xs text-slate-400">なし</p>';
        return `
            <section class="bg-white rounded-2xl border border-slate-100 p-4 mb-3">
                <h3 class="font-bold text-sm mb-1">${esc(payload.theme || '予報')}</h3>
                <p class="text-xs text-slate-500 mb-2">${esc(payload.period || '')} / 体感しやすさ ${esc(payload.impact || '')}</p>
                <p class="text-sm text-slate-700 leading-relaxed">${esc(payload.description || '')}</p>
            </section>
            <section class="bg-white rounded-2xl border border-slate-100 p-4 mb-3">
                <h3 class="font-bold text-sm mb-2">生活上の理由</h3>
                <p class="text-xs text-slate-700 leading-relaxed mb-2">${esc(payload.reasons?.life || '')}</p>
                <h4 class="text-xs font-bold text-astro mb-1">あなたの場合</h4>
                <p class="text-xs text-slate-700 leading-relaxed">${esc(payload.reasons?.personal || '')}</p>
            </section>
            <section class="bg-white rounded-2xl border border-slate-100 p-4 mb-3">
                <h3 class="font-bold text-sm mb-2">スコア</h3>
                ${scoreRow('行動しやすさ', 'action')}
                ${scoreRow('集中しやすさ', 'focus')}
                ${scoreRow('対人のしやすさ', 'relationship')}
                ${scoreRow('連絡・整理', 'communication')}
                ${scoreRow('感情の揺れやすさ', 'emotion')}
                ${scoreRow('休息の必要度', 'rest')}
                ${scoreRow('変化の強さ', 'change')}
            </section>
            <div class="grid grid-cols-2 gap-2 mb-3">
                <section class="bg-emerald-50 rounded-xl p-3 border border-emerald-100"><h4 class="text-xs font-bold text-emerald-700 mb-1">おすすめ</h4>${list(rec.do)}</section>
                <section class="bg-amber-50 rounded-xl p-3 border border-amber-100"><h4 class="text-xs font-bold text-amber-700 mb-1">注意</h4>${list(rec.avoid)}</section>
            </div>
            ${this._renderEvidenceHtml(payload)}
            <button id="detail-ai-generate" class="w-full bg-astro hover:bg-astro-dark text-white font-bold py-3 rounded-xl active:scale-95 transition mb-2">
                <i class="fa-solid fa-wand-magic-sparkles mr-2"></i>AIでさらに詳しく読む
            </button>
        `;
    }

    /** 「この読み解きの根拠」セクション（README追加要件「重要根拠」） */
    _renderEvidenceHtml(payload) {
        const ar = payload.astroReason || payload.reasons;
        const pluto = payload.plutoLayer;
        const escFn = (s) => this._esc(s);
        let html = '<section class="bg-white rounded-2xl border border-slate-100 p-4 mb-3"><h3 class="font-bold text-sm mb-2">占星術的根拠</h3>';
        if (pluto && pluto.active) {
            html += `<div class="bg-gradient-to-br from-purple-100 to-pink-50 border border-purple-200 rounded-xl p-3 mb-2">
                <h4 class="text-xs font-bold text-purple-700 mb-1">♇ 冥王星の背景テーマ</h4>
                ${pluto.astroBasis ? `<p class="text-xs text-slate-700 mb-1">${escFn(pluto.astroBasis)}</p>` : ''}
                ${pluto.whatIsBeingTransformed ? `<p class="text-xs text-slate-700">${escFn(pluto.whatIsBeingTransformed)}</p>` : ''}
            </div>`;
        }
        if (ar) {
            if (ar.summary || ar.astroSummary) html += `<p class="text-xs text-slate-700 mb-1">${escFn(ar.summary || ar.astroSummary)}</p>`;
            const factors = ar.factors || [];
            if (factors.length) html += `<ul class="list-disc pl-5 text-xs text-slate-700">${factors.slice(0, 6).map((f) => `<li><b>${escFn(f.label)}</b>：${escFn(f.meaning)}</li>`).join('')}</ul>`;
        }
        html += '</section>';
        return html;
    }

    _guessDateFromPeriod(s) {
        if (!s) return null;
        let m = s.match(/^(\d{4})-(\d{2})/);
        if (m) return new Date(parseInt(m[1]), parseInt(m[2]) - 1, 15);
        m = s.match(/^(\d{1,2})\/(\d{1,2})/);
        if (m) {
            const now = new Date();
            return new Date(now.getFullYear(), parseInt(m[1]) - 1, parseInt(m[2]));
        }
        return null;
    }

    async _generateForForecast(payload) {
        const me = await this.app.profile.getProfileString();
        if (!me) return;
        const sysPrompt = await this.app.config.getPrompt('prompt_forecast_detail');
        const scoreText = payload.scores ? JSON.stringify(payload.scores) : '';
        const factors = payload.astroReason?.factors || payload.reasons?.factors || [];
        const prompt = `${sysPrompt}

【ネイタル】${me}
【予報期間】${payload.period}
【テーマ】${payload.theme}
【生活上の理由】${payload.reasons?.life || payload.description || ''}
【あなたの場合】${payload.reasons?.personal || ''}
【スコア】${scoreText}
【占星術根拠】${(payload.astroReason?.summary || payload.reasons?.astroSummary || '')}
【根拠要因】${factors.map((f) => f.label + ':' + f.meaning).join(' / ')}
上記をもとに、占星術用語だけに寄せず「なぜユーザーの生活に関係するのか」を中心に、具体的な行動アドバイスを丁寧に記述してください。`;
        const taskId = `detail-forecast-${Date.now()}`;
        const baseHtml = this._renderForecastBaseHtml(payload);
        await this.app.startGeneration({
            taskId,
            taskLabel: '予報の詳細を解説中…',
            prompt,
            isJson: false,
            costsTrial: false,
            featureId: 'forecast.ai_detail',
            requiresPayment: true,
            onProgress: (text) => {
                const e = document.getElementById('detail-text');
                if (e) e.innerHTML = baseHtml + '<div class="bg-white rounded-2xl border border-slate-100 p-4 markdown-body">' + this.app.renderMarkdown(text + ' ▍') + '</div>';
            },
            onDone: (text) => {
                const e = document.getElementById('detail-text');
                if (e) e.innerHTML = baseHtml + '<div class="bg-white rounded-2xl border border-slate-100 p-4 markdown-body">' + this.app.renderMarkdown(text) + '</div>';
                this.app.snackbar.succeed(taskId, '✓ 解説を生成しました');
            },
            onError: (msg) => this.app.snackbar.fail(taskId, msg, () => this._generateForForecast(payload))
        });
    }

    // ---- 「相性」から ----
    async openForCompat(friend) {
        this.currentMode = 'compat';
        this.currentFriend = friend;
        this.currentPayload = null;
        const t = document.getElementById('detail-title');
        if (t) t.textContent = `${friend.name} さんとの相性`;
        this._ensureRenderer();
        const profile = await this.db.get('profile') || {};
        const me = AstrologyCompute.computeChart(profile, null);
        const them = AstrologyCompute.computeChart({ name: friend.name, date: friend.date, time: friend.time, place: friend.place }, null);
        this.renderer.setCharts(me, them, 'dual');
        this._renderHouseDistribution(them); // 相手のハウス分布
        this._renderPositionsTable(me, them, '自分', '相手');
        const txt = document.getElementById('detail-text');
        if (!friend.compat) {
            try { friend.compat = await this.app.compat.buildLocalCompatibility(friend); await this.db.friendPut(friend.id, friend); }
            catch (e) { if (txt) txt.innerHTML = '<p class="text-red-500 text-sm">相性の基本計算に失敗しました。プロフィールを確認してください。</p>'; }
        }
        if (friend.compat && txt) txt.innerHTML = this._renderCompatHtml(friend.compat);
        this.app.ui.openDetail();
    }

    _renderCompatHtml(c) {
        const scores = c.scores || {}, comments = c.comments || {};
        const esc = (v) => this._esc(v);
        const row = (label, key) => {
            const v = Math.max(0, Math.min(100, parseInt(scores[key] || 0)));
            return '<div class="mb-3">' +
                '<div class="flex items-center gap-3 mb-1">' +
                '<div class="w-28 text-xs font-bold text-slate-700">' + esc(label) + '</div>' +
                '<div class="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden"><div class="h-full bg-astro" style="width:' + v + '%"></div></div>' +
                '<div class="w-10 text-right text-sm font-bold text-astro">' + v + '</div>' +
                '</div><p class="text-xs text-slate-600 ml-28">' + esc(comments[key] || '') + '</p></div>';
        };
        const total = Math.max(0, Math.min(100, parseInt(scores.total || 0)));
        const evidence = Array.isArray(c.evidence) ? c.evidence : [];
        const advice = Array.isArray(c.advice) ? c.advice : [];
        const status = c.dataStatus || {};
        const adviceHtml = advice.length ? '<ul class="list-disc pl-5 text-xs text-slate-700 leading-relaxed">' + advice.map((x) => '<li>' + esc(x) + '</li>').join('') + '</ul>' : '<p class="text-xs text-slate-400">なし</p>';
        const evidenceHtml = evidence.length ? '<ul class="list-disc pl-5 text-xs text-slate-700 leading-relaxed mt-2">' + evidence.map((e) => '<li>' + (e.value >= 0 ? '+' : '') + esc(e.value) + ': ' + esc(e.label) + '</li>').join('') + '</ul>' : '<p class="text-xs text-slate-400 mt-2">根拠データなし</p>';
        const plutoBlock = (c.plutoLayer && c.plutoLayer.active) ? '<section class="bg-gradient-to-br from-purple-100 to-pink-50 border border-purple-200 rounded-xl p-3 mt-3"><h4 class="text-xs font-bold text-purple-700 mb-1">♇ 冥王星の関与</h4><p class="text-xs text-slate-700">' + esc(c.plutoLayer.note || c.plutoLayer.theme || '') + '</p></section>' : '';
        const aiDetail = c.aiDetail ? this.app.renderMarkdown(c.aiDetail) : '<p class="text-xs text-slate-400">相性AI解説は任意実行です。将来的に課金対象にできます。</p>';
        return '<div class="bg-white rounded-2xl border border-slate-100 p-4 mb-3">' +
            '<div class="text-center mb-3"><div class="text-xs text-slate-500">総合相性</div><div class="text-4xl font-bold text-astro">' + total + '</div><div class="text-[10px] text-slate-400">診断精度: ' + esc(c.precision || '標準') + '</div></div>' +
            '<div class="bg-slate-50 rounded-xl p-3 mb-3"><h3 class="font-bold text-sm mb-1">ふたり全体の関係性</h3><p class="text-xs text-slate-700 leading-relaxed">' + esc(c.overall || c.summary || '') + '</p><p class="text-[10px] text-slate-500 mt-1">' + esc(status.note || '') + '</p></div>' +
            row('💗 恋愛', 'romance') + row('🤝 安心感', 'friendship') + row('💼 仕事', 'work') + row('💬 会話', 'communication') + row('🧱 安定性', 'stability') + row('⚡ 緊張', 'tension') + plutoBlock + '</div>' +
            '<div class="bg-white rounded-2xl border border-slate-100 p-4 mb-3"><h3 class="font-bold text-sm mb-2">惹かれやすいポイント</h3><p class="text-xs text-slate-700 leading-relaxed">' + esc(c.attraction || comments.romance || '') + '</p><h3 class="font-bold text-sm mt-3 mb-2">すれ違いやすいポイント</h3><p class="text-xs text-slate-700 leading-relaxed">' + esc(c.friction || comments.tension || '') + '</p><h3 class="font-bold text-sm mt-3 mb-2">うまく付き合うための具体行動</h3>' + adviceHtml + '</div>' +
            '<details class="bg-white rounded-2xl border border-slate-100 p-4 mb-3"><summary class="text-xs font-bold text-slate-700 cursor-pointer">占星術的根拠を見る</summary>' + evidenceHtml + '</details>' +
            '<button id="compat-ai-detail-btn" class="w-full bg-astro hover:bg-astro-dark text-white font-bold py-3 rounded-xl active:scale-95 transition mb-3"><i class="fa-solid fa-wand-magic-sparkles mr-2"></i>AIで相性を解説する</button>' +
            '<div id="compat-ai-detail" class="bg-white rounded-2xl border border-slate-100 p-4 markdown-body">' + aiDetail + '</div>';
    }

    /** ハウス分布（README追加要件） */
    _renderHouseDistribution(chart) {
        const cont = document.getElementById('detail-house-dist');
        if (!cont || !chart) return;
        const groups = {};
        for (const k of Object.keys(chart.planets)) {
            const p = chart.planets[k];
            const h = p.house || 1;
            (groups[h] ||= []).push(p);
        }
        const meanings = AstrologyCompute.houseMeanings();
        const items = Object.keys(groups).sort((a, b) => parseInt(a) - parseInt(b)).map((h) => {
            const planets = groups[h].map((p) => `${p.symbol} ${p.ja}`).join('、');
            return `<p class="text-xs text-slate-700"><b>第${h}ハウス</b>：${planets} <span class="text-slate-500">/ ${this._esc(meanings[h] || '')}</span></p>`;
        }).join('');
        cont.innerHTML = `<h3 class="font-bold text-sm mb-2">ハウス分布</h3>${items || '<p class="text-xs text-slate-400">データなし</p>'}`;
    }

    /** 天体位置補助情報（details で折りたたみ） */
    _renderPositionsTable(chartA, chartB, labelA = 'ネイタル', labelB = 'トランジット') {
        const cont = document.getElementById('detail-positions');
        if (!cont) return;
        const tbl = (chart, lbl) => {
            const rows = Object.keys(chart.planets).map((k) => {
                const p = chart.planets[k];
                const sym = AstrologyCompute.signSymbols()[p.signIndex] || '';
                return `<p class="text-[10px] text-slate-700">${p.symbol} ${p.ja}：${sym} ${p.signName} ${p.degInSign.toFixed(1)}° / 第${p.house}ハウス</p>`;
            }).join('');
            return `<div><h4 class="text-xs font-bold mb-1">${this._esc(lbl)}</h4>${rows}</div>`;
        };
        cont.innerHTML = `
            <details class="bg-white rounded-2xl border border-slate-100 p-3">
                <summary class="text-xs font-bold cursor-pointer text-slate-700">天体位置の詳細を見る</summary>
                <div class="grid grid-cols-2 gap-3 mt-2">
                    ${tbl(chartA, labelA)}
                    ${chartB ? tbl(chartB, labelB) : ''}
                </div>
            </details>`;
    }

    /** 🔄更新ボタン */
    refresh() {
        if (this.currentMode === 'today') this._generateForToday(this.currentPayload);
        else if (this.currentMode === 'forecast') this._generateForForecast(this.currentPayload);
        else if (this.currentMode === 'compat' && this.currentFriend) {
            this.app.compat.generateCompatibility(this.currentFriend);
        }
    }

    /** ホロスコープのモード切替（要件§8 ネイタル単独 ↔ 二重円） */
    toggleMode() {
        if (!this.renderer) return;
        const next = this.renderer.mode === 'dual' ? 'natal' : 'dual';
        this.renderer.setMode(next);
        const btn = document.getElementById('detail-mode-toggle');
        if (btn) btn.textContent = next === 'dual' ? '🪐 二重円' : '◯ ネイタルのみ';
    }

    /** 「AIに質問」 → チャットへ文脈引き継ぎ（要件§14） */
    async askInChat() {
        let context = '';
        if (this.currentMode === 'today' && this.currentPayload) {
            context = `今日(${this.currentPayload.segment})の運勢「${this.currentPayload.theme}」について`;
        } else if (this.currentMode === 'forecast' && this.currentPayload) {
            context = `予報「${this.currentPayload.period} - ${this.currentPayload.theme}」について`;
        } else if (this.currentMode === 'compat' && this.currentFriend) {
            context = `${this.currentFriend.name} さんとの相性について`;
        }
        this.app.chat.setContext(context);
        this.app.ui.closeDetail();
        this.app.ui.switchTab('chat');
    }

    // ---- 天体ツールチップ（要件§8） ----
    _showTooltip(planetKey, ring) {
        const info = this.renderer.getTooltipInfo(planetKey, ring);
        if (!info) return;
        if (this._tooltipEl) this._tooltipEl.remove();
        const el = document.createElement('div');
        el.className = 'fixed left-1/2 -translate-x-1/2 bottom-24 z-50 bg-white border border-slate-200 rounded-2xl shadow-2xl p-4 max-w-sm w-[90%] text-left';
        const aspectsHtml = info.aspects.length
            ? info.aspects.slice(0, 5).map((a) => `<li class="text-xs text-slate-600">${a.p1} <span style="color:${a.color}">${a.aspect}(${a.angle}°)</span> ${a.p2} (オーブ${a.orb}°)</li>`).join('')
            : '<li class="text-xs text-slate-400">主要アスペクトなし</li>';
        el.innerHTML = `
            <div class="flex justify-between items-start mb-2">
                <div>
                    <div class="text-2xl font-bold">${info.symbol} ${this._esc(info.name_ja)} <span class="text-xs text-slate-400">(${info.name_en})</span></div>
                    <div class="text-xs text-slate-500 mt-0.5">${info.signSymbol} ${this._esc(info.sign)} ${info.degInSign}° / ${info.house}ハウス${info.ring === 'B' ? '（外側）' : '（ネイタル）'}</div>
                </div>
                <button class="text-slate-400 text-xl leading-none">&times;</button>
            </div>
            <p class="text-xs text-slate-700 mb-2"><b>意味:</b> ${this._esc(info.meaning)}</p>
            <p class="text-xs text-slate-700 mb-2"><b>このハウスの意味:</b> ${this._esc(AstrologyCompute.houseMeaning(info.house))}</p>
            <div class="text-xs">
                <b>主要アスペクト:</b>
                <ul class="mt-1 space-y-0.5">${aspectsHtml}</ul>
            </div>
        `;
        el.querySelector('button').addEventListener('click', () => this._hideTooltip());
        document.body.appendChild(el);
        this._tooltipEl = el;
    }

    _hideTooltip() {
        if (this._tooltipEl) { this._tooltipEl.remove(); this._tooltipEl = null; }
    }

    _esc(s) {
        return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }
}

window.DetailComponent = DetailComponent;
