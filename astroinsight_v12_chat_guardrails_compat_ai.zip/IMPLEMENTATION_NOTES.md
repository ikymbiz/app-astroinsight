# 実装メモ v11

## 対応概要

- 失敗時トーストが残り続けないよう、Snackbarを自動消去・閉じるボタン・重複抑制・最大表示数制限つきに変更。
- タブ切替、詳細画面、設定画面を開くタイミングで古いトーストを消去。
- 予報画面にスライダーバー、前へ/次へ、選択中ラベルを追加。
- 予報グラフのタップ判定を広げ、スライダー・グラフ・おすすめ時間チップを同期。
- 予報に「全体の大きな流れ」と「各時間/各日ごとの差分説明」を追加。
- 今日・予報はプロフィールがあれば占う/予測開始ボタンなしで自動表示。ボタンは更新用途として残す。
- 相性はAI巨大JSON依存を廃止。基本相性はローカル計算で即表示し、解析失敗で止まらない構成に変更。
- 友達登録に関係性・メモを追加。出生時間/出生地が不明でも保存可能。
- 友達登録後に一覧表示・再読み込み後再利用・相性詳細表示に使えるよう保存フローを修正。
- 相性詳細は、全体の関係性、惹かれやすいポイント、すれ違いやすいポイント、個別スコア、具体行動、占星術根拠の順に表示。
- 相性AI詳細はボタン実行のみ。失敗しても基本相性は残る。
- Groq と Fireworks AI をプロバイダー/モデル/Worker/APIホストに追加。
- AI処理に featureId / requiresPayment / 推定token / 成功失敗ログを追加し、管理画面に利用ログを表示。
- 「怖がらせない」「不安を煽らない」系の制約を削除。根拠がある注意点はありのまま書く方針に変更。ただし絶対予言として断定しない。

## 主要変更ファイル

- `index.html`
- `js/core/snackbar.js`
- `js/components/forecast.js`
- `js/components/compat.js`
- `js/components/detail.js`
- `js/components/today.js`
- `js/components/natal.js`
- `js/components/chat.js`
- `js/components/settings.js`
- `js/components/ui-controller.js`
- `js/app.js`
- `js/workers/ai-worker.js`
- `js/config/models.json`
- `js/config/prompts.json`
- `js/config/app-config.json`
- `sw.js`

## 検証

- 主要JSファイルの `node --check` を実施。
- `models.json` / `prompts.json` / `app-config.json` のJSON parseを確認。
- `ForecastEngine.generate()` で月次18件、週次8件、日次7件、時間24件を確認。
- `CompatComponent.buildLocalCompatibility()` のローカル相性生成をNode VM上で確認。

## 未実施

- ブラウザ実機でのタップ操作、Service Worker更新、実API呼び出しの確認はこの環境では未実施。
- 課金決済そのものは未実装。今回は将来課金のための機能ID・フラグ・利用ログまで。

## v12 追加修正: チャットガードレール / 相性AI解説

- チャットに入力前ガードレールを追加。
  - 自傷・他害・違法行為・操作/支配系の依頼はAIへ送らず、短い安全導線に切り替え。
  - 医療・法律・金融などの専門判断は、占星術的な気分整理と行動注意に限定。
  - 最新情報系の質問は扱わず、占星術相談へ誘導。
  - 長文入力は700字上限で停止。
- チャット回答の話し過ぎ防止を追加。
  - prompt_chatを短文前提に変更。
  - chat専用ガードレールをプロンプトへ注入。
  - 履歴・ネイタル要約・プロフィールを短く圧縮して送信。
  - チャット生成だけ maxTokens=520 / temperature=0.55 を指定。
  - 最終回答を maxAnswerChars=420 でトリム。
- 相性AI解説を専用機能として追加/強化。
  - `prompt_compat_detail` を追加し、JSON用の `prompt_compat` と分離。
  - `compat.ai_explanation` を課金候補AI機能IDとして追加。
  - 相性AI解説はローカル基本相性を入力にしてMarkdownで生成。
  - 出力は「ふたり全体 / 惹かれる点 / ぶつかる点 / 具体的な接し方 / 根拠」の構成。
- `startGeneration` が機能ごとの `maxTokens` / `temperature` / `topP` / `streaming` を受け取れるように変更。
- Service Workerのキャッシュ名を更新。
