/* ============================================================
 * AstroInsight Service Worker（v9）
 * App shell + CDN静的ライブラリをキャッシュ。APIはキャッシュしない。
 * ============================================================ */
const CACHE_NAME = 'astroinsight-v12-chat-guardrails-compat-ai-2026-04-28';
const APP_SHELL = [
    './', './index.html', './404.html', './manifest.webmanifest',
    './css/styles.css',
    './js/app.js',
    './js/core/db.js', './js/core/auth.js', './js/core/config-loader.js',
    './js/core/feature-flags.js', './js/core/proxy.js', './js/core/snackbar.js',
    './js/core/ai-worker-manager.js', './js/core/astrology.js', './js/core/forecast-engine.js', './js/core/horoscope-renderer.js',
    './js/components/ads.js', './js/components/chat.js', './js/components/compat.js',
    './js/components/detail.js', './js/components/forecast.js', './js/components/natal.js',
    './js/components/onboarding.js', './js/components/profile.js', './js/components/settings.js',
    './js/components/today.js', './js/components/ui-controller.js',
    './js/workers/ai-worker.js',
    './js/config/app-config.json', './js/config/models.json', './js/config/prompts.json'
];
const STATIC_HOSTS = [
    'cdn.jsdelivr.net', 'cdnjs.cloudflare.com', 'cdn.tailwindcss.com',
    'fonts.googleapis.com', 'fonts.gstatic.com'
];
const API_HOST_PATTERNS = [
    'generativelanguage.googleapis.com', 'googleapis.com', 'accounts.google.com',
    'openai.com', 'anthropic.com', 'api.x.ai', 'api.groq.com', 'api.fireworks.ai', 'workers.dev'
];

self.addEventListener('install', (event) => {
    event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL).catch(() => null)));
    self.skipWaiting();
});

self.addEventListener('activate', (event) => {
    event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))));
    self.clients.claim();
});

function isApiRequest(url) {
    return API_HOST_PATTERNS.some((h) => url.host.includes(h));
}
function isStaticCdn(url) {
    return STATIC_HOSTS.some((h) => url.host.includes(h));
}

self.addEventListener('fetch', (event) => {
    if (event.request.method !== 'GET') return;
    const url = new URL(event.request.url);
    if (isApiRequest(url)) return;

    if (isStaticCdn(url)) {
        event.respondWith(
            caches.match(event.request).then((cached) => cached || fetch(event.request).then((res) => {
                const copy = res.clone();
                caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy)).catch(() => null);
                return res;
            }).catch(() => cached))
        );
        return;
    }

    event.respondWith(
        caches.match(event.request).then((cached) => cached || fetch(event.request).then((res) => {
            const copy = res.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy)).catch(() => null);
            return res;
        }).catch(() => caches.match('./index.html')))
    );
});
