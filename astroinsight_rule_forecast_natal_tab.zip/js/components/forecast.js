/* ============================================================
 * AstroInsight - Forecast Component（v7 rule-based）
 *   - 期間: 月次=18ヶ月 / 週次=8週間 / 日次=7日 / 時間=24時間
 *   - 初期表示は生成AIなし。AstrologyCompute + ForecastEngine で高速生成。
 *   - スコアは星の動きだけでなく、ネイタル個性・重視テーマ・今日の気分を反映。
 *   - 詳細AIは選択時点のみ。巨大JSON一括生成を廃止。
 * ============================================================ */

class ForecastComponent {
    constructor(app) {
        this.app = app;
        this.db = app.db;
        this.forecastType = 'daily';
        this.selectedIndex = 0;
        this._lastData = null;
        this._userContext = { focus: 'balanced', mood: 'normal', reasonLevel: 'standard' };
    }

    async load(opts = {}) {
        const ac = this.app.config?.getAppConfig?.() || {};
        if (opts.applyDefault && ac.forecast?.defaultGranularity) this.forecastType = ac.forecast.defaultGranularity;
        await this._loadUserContext();
        this._syncGranularityButtons();
        this._syncContextInputs();
        const c = await this.db.cacheGet(this._cacheKey());
        if (c?.data) this._render(c.data);
        else this._renderEmpty();
    }

    async _loadUserContext() {
        if (!window.ForecastEngine) return;
        this._userContext = await ForecastEngine.getUserContext(this.db);
    }

    _appConfig() { return this.app.config?.getAppConfig?.() || {}; }
    _cacheKey() { return ForecastEngine.cacheKey(this.forecastType, this._appConfig()); }

    async refresh() {
        await this.db.cacheDelete(this._cacheKey());
        this.generate();
    }

    async saveUserContext() {
        const focus = document.getElementById('forecast-focus')?.value || 'balanced';
        const mood = document.getElementById('forecast-mood')?.value || 'normal';
        this._userContext = await ForecastEngine.saveUserContext(this.db, { focus, mood });
        await this.db.cacheDelete(this._cacheKey());
        this.generate();
    }

    _syncContextInputs() {
        const f = document.getElementById('forecast-focus');
        const m = document.getElementById('forecast-mood');
        if (f) f.value = this._userContext.focus || 'balanced';
        if (m) m.value = this._userContext.mood || 'normal';
    }

    async generate() {
        const profile = await this.db.get('profile') || {};
        if (!profile.date) return alert('プロフィールを設定してください。');
        if (!window.ForecastEngine || !window.AstrologyCompute) return alert('予報エンジンの読み込みに失敗しました。');
        const type = this.forecastType;
        const taskId = `forecast-local-${type}`;
        try {
            this.app.snackbar.start(taskId, `予報（${this._granLabel(type)}）を計算中…`);
            await this._loadUserContext();
            const data = ForecastEngine.generate({
                profile,
                type,
                appConfig: this._appConfig(),
                userContext: this._userContext,
                now: new Date()
            });
            const cacheKey = this._cacheKey();
            await this.db.cacheSet(cacheKey, { data, ts: Date.now(), type, mode: 'rule-based' });
            if (this.forecastType === type) {
                this.selectedIndex = 0;
                this._render(data);
            }
            this.app.snackbar.succeed(taskId, '✓ 予報を更新しました');
        } catch (e) {
            console.error('[forecast] local generation failed', e);
            this.app.snackbar.fail(taskId, '予報計算に失敗しました: ' + (e?.message || e), () => this.generate());
        }
    }

    async prefetchMonthlyInBackground() {
        // APIを消費しないローカル計算なので、既存キャッシュ確認のみ。
        if (this._prefetched) return;
        this._prefetched = true;
        const old = this.forecastType;
        this.forecastType = 'monthly';
        await this.db.cacheGet(this._cacheKey());
        this.forecastType = old;
    }

    _granLabel(g) { return ({ monthly: '月次', weekly: '週次', daily: '日次', hourly: '時間' })[g] || g; }

    _syncGranularityButtons() {
        ['monthly', 'weekly', 'daily', 'hourly'].forEach((t) => {
            const btn = document.getElementById(`fc-btn-${t}`);
            if (!btn) return;
            if (t === this.forecastType) {
                btn.classList.add('active', 'bg-astro', 'text-white');
                btn.classList.remove('bg-white', 'text-slate-600');
            } else {
                btn.classList.remove('active', 'bg-astro', 'text-white');
                btn.classList.add('bg-white', 'text-slate-600');
            }
        });
    }

    _renderEmpty() {
        const cont = document.getElementById('forecast-selected');
        if (cont) cont.innerHTML = `<div class="text-center text-slate-400 py-6"><p class="text-sm">「予測開始」を押すと、AIを使わず高速に予報タイムラインを作成します。</p></div>`;
        if (this.app.chartInstance) {
            this.app.chartInstance.destroy();
            this.app.chartInstance = null;
        }
    }

    _render(data) {
        if (!data || !data.length) return;
        this._lastData = data;
        if (this.selectedIndex >= data.length) this.selectedIndex = data.length - 1;
        this._renderChart(data);
        const item = data[this.selectedIndex];
        const cont = document.getElementById('forecast-selected');
        if (cont) cont.innerHTML = this._renderRecommendationsHtml(data) + this._renderItemHtml(item);
        this._bindItemActions(item);
    }

    _renderChart(data) {
        const cv = document.getElementById('forecastChart');
        if (!cv || typeof Chart === 'undefined') return;
        const ctx = cv.getContext('2d');
        const labels = data.map((d) => d.period || '');
        const impacts = data.map((d) => parseInt(d.impact) || 0);
        const nowIdx = 0;
        const pointBg = data.map((_, i) => (i === this.selectedIndex ? '#ef4444' : (i === nowIdx ? '#fbbf24' : '#fff')));
        const pointRad = data.map((_, i) => (i === this.selectedIndex ? 8 : (i === nowIdx ? 6 : 4)));
        if (this.app.chartInstance) this.app.chartInstance.destroy();
        this.app.chartInstance = new Chart(ctx, {
            type: 'line',
            data: {
                labels,
                datasets: [{
                    label: '体感しやすさ',
                    data: impacts,
                    borderColor: '#4f46e5',
                    backgroundColor: 'rgba(79,70,229,0.18)',
                    tension: 0.4,
                    fill: true,
                    pointBackgroundColor: pointBg,
                    pointBorderColor: '#4f46e5',
                    pointBorderWidth: 2,
                    pointRadius: pointRad
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: { y: { min: 0, max: 100 }, x: { ticks: { maxTicksLimit: 6 } } },
                plugins: { legend: { display: false } },
                animation: { duration: 300 },
                onClick: (evt, els) => {
                    if (!els || !els.length) return;
                    this.selectedIndex = els[0].index;
                    this._render(this._lastData);
                }
            }
        });
    }

    _renderRecommendationsHtml(data) {
        if (!window.ForecastEngine) return '';
        const r = ForecastEngine.topRecommendations(data);
        const chip = (title, items, icon) => `<div class="bg-white rounded-xl border border-slate-100 p-3">
            <h4 class="text-[11px] font-bold text-slate-700 mb-1"><i class="${icon} mr-1 text-astro"></i>${this._esc(title)}</h4>
            <div class="flex flex-wrap gap-1">${items.map((it) => `<button data-pick-index="${it.index}" class="text-[10px] bg-astro-light text-astro px-2 py-1 rounded-full font-bold">${this._esc(it.period)}</button>`).join('')}</div>
        </div>`;
        setTimeout(() => {
            document.querySelectorAll('[data-pick-index]').forEach((btn) => {
                btn.onclick = () => { this.selectedIndex = parseInt(btn.dataset.pickIndex, 10) || 0; this._render(this._lastData); };
            });
        }, 0);
        return `<div class="grid grid-cols-2 gap-2 mb-3">
            ${chip('動くなら', r.action, 'fa-solid fa-person-running')}
            ${chip('集中するなら', r.focus, 'fa-solid fa-bullseye')}
            ${chip('対人・連絡', r.relationship, 'fa-solid fa-comments')}
            ${chip('休むなら', r.rest, 'fa-solid fa-moon')}
        </div>`;
    }

    _renderItemHtml(it) {
        if (!it) return '';
        const impact = Math.max(0, Math.min(100, parseInt(it.impact || 0)));
        const scores = it.scores || {};
        const scoreRows = [
            ['action', '行動しやすさ'], ['focus', '集中しやすさ'], ['relationship', '対人のしやすさ'],
            ['communication', '連絡・整理'], ['emotion', '感情の揺れやすさ'], ['rest', '休息の必要度'], ['change', '変化の強さ']
        ].map(([k, label]) => this._scoreBar(label, scores[k] || 0)).join('');
        const factors = it.reasons?.factors || it.astroReason?.factors || [];
        const breakdown = Array.isArray(it.scoreBreakdown) ? it.scoreBreakdown : [];
        const list = (arr) => Array.isArray(arr) && arr.length ? `<ul class="list-disc pl-5 text-xs text-slate-700 leading-relaxed">${arr.map((s) => `<li>${this._esc(s)}</li>`).join('')}</ul>` : '';
        return `<article class="bg-white rounded-2xl shadow-sm border border-slate-100 p-4 border-l-4 border-l-astro">
            <div class="flex justify-between gap-3 mb-2">
                <div>
                    <div class="text-[10px] text-slate-400">${this._esc(this._granLabel(this.forecastType))}</div>
                    <h3 class="font-bold text-slate-800 text-base">${this._esc(it.period || '')}</h3>
                </div>
                <span class="text-xs font-bold px-2 py-1 rounded-full bg-astro-light text-astro border border-indigo-200 shrink-0">体感しやすさ: ${impact}</span>
            </div>
            <p class="text-sm text-slate-700 mb-2"><b>テーマ：</b>${this._esc(it.theme || '')}</p>
            <p class="text-xs text-slate-600 leading-relaxed mb-3">${this._esc(it.description || '')}</p>

            <section class="bg-slate-50 rounded-xl p-3 mb-2">
                <h4 class="text-xs font-bold text-astro mb-1">生活上の理由</h4>
                <p class="text-xs text-slate-700 leading-relaxed">${this._esc(it.reasons?.life || '')}</p>
            </section>
            <section class="bg-slate-50 rounded-xl p-3 mb-2">
                <h4 class="text-xs font-bold text-astro mb-1">あなたの場合</h4>
                <p class="text-xs text-slate-700 leading-relaxed">${this._esc(it.reasons?.personal || '')}</p>
            </section>

            <details class="bg-white rounded-xl p-3 mb-2 border border-slate-100" open>
                <summary class="text-xs font-bold text-slate-700 cursor-pointer">スコア内訳</summary>
                <div class="mt-2 space-y-1">${scoreRows}</div>
                ${breakdown.length ? `<ul class="mt-2 text-[10px] text-slate-500 space-y-0.5">${breakdown.map((b) => `<li>${b.value >= 0 ? '+' : ''}${this._esc(b.value)} ${this._esc(b.label)}</li>`).join('')}</ul>` : ''}
            </details>

            <div class="grid grid-cols-2 gap-2">
                <section class="bg-emerald-50 rounded-xl p-3 border border-emerald-100">
                    <h4 class="text-xs font-bold text-emerald-700 mb-1">おすすめ</h4>
                    ${list(it.recommendations?.do)}
                </section>
                <section class="bg-amber-50 rounded-xl p-3 border border-amber-100">
                    <h4 class="text-xs font-bold text-amber-700 mb-1">注意</h4>
                    ${list(it.recommendations?.avoid)}
                </section>
            </div>

            <details class="bg-white rounded-xl p-3 mt-2 border border-slate-100">
                <summary class="text-xs font-bold text-slate-700 cursor-pointer">占星術的根拠を見る</summary>
                <p class="text-xs text-slate-700 leading-relaxed mt-2">${this._esc(it.reasons?.astroSummary || it.astroReason?.summary || '')}</p>
                ${factors.length ? `<ul class="list-disc pl-5 text-xs text-slate-700 leading-relaxed mt-1">${factors.slice(0, 6).map((f) => `<li><b>${this._esc(f.label)}</b>：${this._esc(f.meaning)}</li>`).join('')}</ul>` : ''}
            </details>

            <div class="grid grid-cols-2 gap-2 mt-3">
                <button data-detail class="bg-astro hover:bg-astro-dark text-white font-bold py-2 rounded-lg text-xs">
                    <i class="fa-solid fa-arrow-right-long mr-1"></i> AIで詳しく読む
                </button>
                <button data-ask class="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-2 rounded-lg text-xs">
                    <i class="fa-solid fa-comment-dots mr-1"></i> AIに質問
                </button>
            </div>
        </article>`;
    }

    _scoreBar(label, value) {
        const v = Math.max(0, Math.min(100, parseInt(value || 0)));
        return `<div><div class="flex justify-between text-[10px] text-slate-500 mb-0.5"><span>${this._esc(label)}</span><b>${v}</b></div><div class="h-1.5 bg-slate-100 rounded-full overflow-hidden"><div class="h-full bg-astro" style="width:${v}%"></div></div></div>`;
    }

    _bindItemActions(item) {
        const cont = document.getElementById('forecast-selected');
        if (!cont) return;
        const detail = cont.querySelector('[data-detail]');
        const ask = cont.querySelector('[data-ask]');
        if (detail) detail.addEventListener('click', () => this.app.detail.openForForecast({ ...item, forecastType: this.forecastType, autoGenerate: true }));
        if (ask) ask.addEventListener('click', () => {
            this.app.chat.setContext(`予報「${item.period} - ${item.theme}」について`);
            this.app.ui.switchTab('chat');
        });
    }

    _esc(s) {
        return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }
}

window.ForecastComponent = ForecastComponent;
