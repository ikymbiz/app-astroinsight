/* ============================================================
 * AstroInsight - Forecast Rule Engine（v1）
 * 生成AIを常時利用せず、占星術計算・スコア・生活理由・短文を
 * ローカルで作るための設定駆動エンジン。
 * ============================================================ */

class ForecastEngine {
    static defaultProfiles() {
        return {
            monthly: { label: '月次', count: 18, step: 'month', origin: 'current_month', cacheUnit: 'month', aiMode: 'selected_detail' },
            weekly:  { label: '週次', count: 8,  step: 'week',  origin: 'current_week',  cacheUnit: 'week',  aiMode: 'selected_detail' },
            daily:   { label: '日次', count: 7,  step: 'day',   origin: 'today',         cacheUnit: 'day',   aiMode: 'selected_detail' },
            hourly:  { label: '時間', count: 24, step: 'hour',  origin: 'next_hour',     cacheUnit: 'hour',  aiMode: 'selected_detail' }
        };
    }

    static getProfiles(appConfig = {}) {
        const defaults = this.defaultProfiles();
        const custom = appConfig.forecast?.profiles || {};
        const out = {};
        for (const key of Object.keys(defaults)) out[key] = { ...defaults[key], ...(custom[key] || {}) };
        return out;
    }

    static profileFor(type, appConfig = {}) {
        return this.getProfiles(appConfig)[type] || this.getProfiles(appConfig).daily;
    }

    static cacheKey(type, appConfig = {}, now = new Date()) {
        const p = this.profileFor(type, appConfig);
        const start = this.startDateForProfile(p, now);
        const stamp = this.formatCacheStamp(start, p.cacheUnit || p.step || 'day');
        return `forecast_${type}_${stamp}`;
    }

    static startDateForProfile(profile, now = new Date()) {
        const d = new Date(now);
        if (profile.origin === 'current_month') return new Date(d.getFullYear(), d.getMonth(), 1, 0, 0, 0, 0);
        if (profile.origin === 'current_week') {
            const x = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0, 0, 0, 0);
            const day = x.getDay() || 7;
            x.setDate(x.getDate() - (day - 1));
            return x;
        }
        if (profile.origin === 'next_hour') {
            const x = new Date(d);
            x.setMinutes(0, 0, 0);
            if (d.getMinutes() || d.getSeconds() || d.getMilliseconds()) x.setHours(x.getHours() + 1);
            return x;
        }
        return new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0, 0, 0, 0);
    }

    static formatCacheStamp(date, unit) {
        const y = date.getFullYear();
        const m = String(date.getMonth() + 1).padStart(2, '0');
        const d = String(date.getDate()).padStart(2, '0');
        const h = String(date.getHours()).padStart(2, '0');
        if (unit === 'month') return `${y}-${m}`;
        if (unit === 'week') return `${y}-${m}-${d}`;
        if (unit === 'hour') return `${y}-${m}-${d}-${h}`;
        return `${y}-${m}-${d}`;
    }

    static buildTimeline(type, appConfig = {}, now = new Date()) {
        const profile = this.profileFor(type, appConfig);
        const start = this.startDateForProfile(profile, now);
        const count = Math.max(1, parseInt(profile.count || 1, 10));
        const out = [];
        for (let i = 0; i < count; i++) {
            const d = new Date(start);
            if (profile.step === 'month') d.setMonth(start.getMonth() + i);
            else if (profile.step === 'week') d.setDate(start.getDate() + i * 7);
            else if (profile.step === 'hour') d.setHours(start.getHours() + i);
            else d.setDate(start.getDate() + i);
            out.push({ date: d, period: this.formatPeriod(d, type, i) });
        }
        return out;
    }

    static formatPeriod(date, type, index = 0) {
        const y = date.getFullYear();
        const m = date.getMonth() + 1;
        const d = date.getDate();
        const h = String(date.getHours()).padStart(2, '0');
        const wd = ['日', '月', '火', '水', '木', '金', '土'][date.getDay()];
        if (type === 'monthly') return `${y}-${String(m).padStart(2, '0')}`;
        if (type === 'weekly') return `${m}/${d}週`;
        if (type === 'hourly') return `${m}/${d} ${h}:00`;
        return `${m}/${d}(${wd})`;
    }

    static async getUserContext(db) {
        const v = await db.get('forecast_user_context');
        return {
            focus: v?.focus || 'balanced',
            mood: v?.mood || 'normal',
            reasonLevel: v?.reasonLevel || 'standard'
        };
    }

    static async saveUserContext(db, patch) {
        const cur = await this.getUserContext(db);
        const next = { ...cur, ...(patch || {}) };
        await db.set('forecast_user_context', next);
        return next;
    }

    static generate({ profile, type = 'daily', appConfig = {}, userContext = {}, now = new Date() }) {
        const timeline = this.buildTimeline(type, appConfig, now);
        const natal = AstrologyCompute.computeChart(profile, null);
        const natalPattern = this.deriveNatalPattern(natal);
        const items = timeline.map((slot, index) => {
            const transit = AstrologyCompute.computeChart(profile, slot.date);
            return this.buildItem({ profile, type, slot, index, natal, transit, natalPattern, userContext });
        });
        return items;
    }

    static buildItem(ctx) {
        const { type, slot, index, natal, transit, natalPattern, userContext } = ctx;
        const features = this.extractFeatures(natal, transit, type);
        const scoring = this.scoreFeatures(features, natalPattern, userContext, type);
        const theme = this.chooseTheme(scoring, features, type);
        const text = this.composeText(theme, scoring, features, natalPattern, userContext, type);
        const impact = Math.round(scoring.impact);
        const factors = this.factorObjects(features, theme);
        const plutoLayer = this.buildPlutoLayer(features, theme, type);
        const sections = this.buildSections(theme, scoring, text);
        return {
            period: slot.period,
            startIso: slot.date.toISOString(),
            index,
            granularity: type,
            impact,
            theme: theme.label,
            themeCode: theme.code,
            description: text.description,
            scores: scoring.scores,
            scoreBreakdown: scoring.breakdown,
            recommendations: text.recommendations,
            reasons: {
                life: text.lifeReason,
                personal: text.personalReason,
                astroSummary: text.astroSummary,
                factors
            },
            astroReason: {
                summary: text.astroSummary,
                factors
            },
            focus: {
                houses: features.activeHouses.map((h) => `第${h}ハウス`),
                planets: features.activePlanets,
                aspects: features.majorAspects.map((a) => a.label)
            },
            wave: {
                type: theme.label,
                status: index === 0 ? '入口' : '進行中',
                identity: text.lifeReason,
                timeline: this.timelineText(type, slot.date),
                astroBasis: text.astroSummary,
                howToOvercome: text.recommendations.avoid[0] || '急がず、今できる小さな行動に分けると安定します。',
                goodWaveUsage: text.recommendations.do[0] || '流れが強いテーマを一つだけ選んで使ってください。',
                changeSigns: '気分・集中・対人反応の切り替わりが、次の波のサインです。',
                smallSigns: text.smallSigns,
                avoid: text.recommendations.avoid,
                recommendedActions: text.recommendations.do
            },
            sections,
            plutoLayer
        };
    }

    static extractFeatures(natal, transit, type) {
        const natalPos = this.positionMap(natal.planets);
        const transitPos = this.positionMap(transit.planets);
        const moon = transit.planets.Moon;
        const sun = transit.planets.Sun;
        const ascSign = AstrologyCompute.signFromLongitude(transit.ASC);
        const mcSign = AstrologyCompute.signFromLongitude(transit.MC);
        const activeHouses = [moon?.house, sun?.house].filter(Boolean);
        const houseCounts = {};
        Object.values(transit.planets).forEach((p) => { houseCounts[p.house] = (houseCounts[p.house] || 0) + 1; });
        Object.keys(houseCounts).sort((a, b) => houseCounts[b] - houseCounts[a]).slice(0, 2).forEach((h) => {
            const n = parseInt(h, 10); if (!activeHouses.includes(n)) activeHouses.push(n);
        });

        const transitFocus = type === 'hourly'
            ? { Moon: transitPos.Moon }
            : type === 'daily'
                ? { Moon: transitPos.Moon, Sun: transitPos.Sun, Mercury: transitPos.Mercury, Venus: transitPos.Venus, Mars: transitPos.Mars }
                : { Sun: transitPos.Sun, Mercury: transitPos.Mercury, Venus: transitPos.Venus, Mars: transitPos.Mars, Jupiter: transitPos.Jupiter, Saturn: transitPos.Saturn, Uranus: transitPos.Uranus, Neptune: transitPos.Neptune, Pluto: transitPos.Pluto };
        const aspects = AstrologyCompute.detectAspects(transitFocus, natalPos, false)
            .concat(AstrologyCompute.detectAspects({ ASC: transit.ASC, MC: transit.MC }, natalPos, false))
            .map((a) => this.decorateAspect(a))
            .sort((a, b) => b.weight - a.weight)
            .slice(0, type === 'hourly' ? 8 : 10);

        const activePlanets = Array.from(new Set(aspects.flatMap((a) => [a.p1, a.p2]).filter((p) => !['ASC', 'MC'].includes(p)))).slice(0, 6);
        return {
            type,
            moonSign: moon?.signName || '',
            moonHouse: moon?.house || 1,
            sunHouse: sun?.house || 1,
            ascSign: ascSign.signName,
            mcSign: mcSign.signName,
            ascHouseMeaning: AstrologyCompute.houseMeaning(1),
            activeHouses,
            majorAspects: aspects,
            activePlanets,
            hasPluto: aspects.some((a) => a.p1 === 'Pluto' || a.p2 === 'Pluto'),
            hasTension: aspects.some((a) => ['square', 'opposition'].includes(a.aspectEn)),
            hasFlow: aspects.some((a) => ['trine', 'sextile'].includes(a.aspectEn)),
            transit,
            natal
        };
    }

    static positionMap(planets) {
        const out = {};
        for (const k of Object.keys(planets || {})) out[k] = planets[k].longitude;
        return out;
    }

    static decorateAspect(a) {
        const aspectWeight = { conjunction: 18, trine: 15, sextile: 10, square: 14, opposition: 14 }[a.aspectEn] || 8;
        const pointBoost = ['ASC', 'MC', 'Moon'].includes(a.p1) ? 5 : 0;
        const plutoBoost = (a.p1 === 'Pluto' || a.p2 === 'Pluto') ? 4 : 0;
        return {
            ...a,
            weight: aspectWeight + pointBoost + plutoBoost - Math.min(6, parseFloat(a.orb || 0)),
            label: `${this.planetLabel(a.p1)}と出生${this.planetLabel(a.p2)}の${a.aspect}`,
            isTension: ['square', 'opposition'].includes(a.aspectEn),
            isFlow: ['trine', 'sextile'].includes(a.aspectEn)
        };
    }

    static planetLabel(key) {
        const p = AstrologyCompute.planets().find((x) => x.key === key);
        return p ? p.ja : ({ ASC: 'ASC', MC: 'MC' }[key] || key);
    }

    static deriveNatalPattern(natal) {
        const weights = { Mercury: 0, Moon: 0, Venus: 0, Mars: 0, Saturn: 0, Sun: 0, Pluto: 0 };
        const add = (k, n) => { if (weights[k] != null) weights[k] += n; };
        for (const p of Object.values(natal.planets || {})) {
            if (p.key in weights) add(p.key, 2);
            if ([1, 4, 7, 10].includes(p.house)) add(p.key, 2);
            if ([3, 6].includes(p.house)) add('Mercury', 1.5);
            if ([4, 12].includes(p.house)) add('Moon', 1.5);
            if ([5, 7].includes(p.house)) add('Venus', 1.5);
            if ([1, 8].includes(p.house)) add('Mars', 1.2);
            if ([6, 10].includes(p.house)) add('Saturn', 1.3);
            if ([8, 12].includes(p.house)) add('Pluto', 1.2);
            if ([2, 5].includes(p.signIndex)) add('Mercury', 1.2); // 双子/乙女
            if (p.signIndex === 3) add('Moon', 1.2); // 蟹
            if ([1, 6].includes(p.signIndex)) add('Venus', 1.2); // 牡牛/天秤
            if ([0, 7].includes(p.signIndex)) add('Mars', 1.2); // 牡羊/蠍
            if ([9, 10].includes(p.signIndex)) add('Saturn', 1.0);
        }
        const sorted = Object.keys(weights).sort((a, b) => weights[b] - weights[a]);
        return { weights, primary: sorted[0] || 'Sun', secondary: sorted[1] || 'Moon' };
    }

    static scoreFeatures(features, natalPattern, userContext, type) {
        const scores = { action: 45, focus: 45, relationship: 45, emotion: 45, rest: 45, change: 45, communication: 45 };
        const breakdown = [];
        const add = (key, value, label) => {
            if (scores[key] == null) return;
            scores[key] += value;
            breakdown.push({ key, value: Math.round(value), label });
        };
        const houseMap = {
            1: [['action', 13, '自分から動き出しやすい領域']],
            2: [['focus', 10, '価値観やお金を整える領域']],
            3: [['communication', 18, '連絡・会話・整理の領域']],
            4: [['rest', 16, '安心・家・心の土台の領域']],
            5: [['relationship', 12, '楽しみ・表現・恋愛の領域'], ['action', 8, '自己表現が動きやすい領域']],
            6: [['focus', 18, '仕事習慣・健康・段取りの領域']],
            7: [['relationship', 18, '対人関係・調整の領域']],
            8: [['change', 17, '深い関係・共有・変容の領域']],
            9: [['action', 12, '学び・挑戦・視野拡大の領域']],
            10: [['focus', 16, '仕事・評価・社会的役割の領域'], ['action', 8, '外に出る力が高まる領域']],
            11: [['relationship', 13, '仲間・未来・コミュニティの領域']],
            12: [['rest', 18, '内省・回復・手放しの領域']]
        };
        for (const [k, v, label] of (houseMap[features.moonHouse] || [])) add(k, v, `月が第${features.moonHouse}ハウス: ${label}`);
        if (type === 'hourly') {
            add('action', 8, `ASCが${features.ascSign}: 表に出る雰囲気が変化`);
            add('focus', 6, `MCが${features.mcSign}: 外向きの判断軸が変化`);
        }
        for (const a of features.majorAspects.slice(0, 6)) {
            const target = a.p2;
            const sign = a.isTension ? -1 : 1;
            const base = Math.max(5, Math.min(15, a.weight));
            const label = a.label;
            if (target === 'Mercury' || a.p1 === 'Mercury') { add('communication', sign * base, label); add('focus', sign * base * 0.45, label); }
            if (target === 'Venus' || a.p1 === 'Venus') add('relationship', sign * base, label);
            if (target === 'Mars' || a.p1 === 'Mars') { add('action', sign * base, label); add('change', Math.abs(base) * 0.5, label); }
            if (target === 'Saturn' || a.p1 === 'Saturn') { add('focus', sign * base * 0.8, label); add('rest', a.isTension ? base * 0.7 : 0, label); }
            if (target === 'Moon' || a.p1 === 'Moon') add('emotion', a.isTension ? base : sign * base * 0.8, label);
            if (target === 'Pluto' || a.p1 === 'Pluto') add('change', Math.abs(base) + 7, label);
            if (a.p1 === 'ASC') add('action', sign * base * 0.85, label);
            if (a.p1 === 'MC') add('focus', sign * base * 0.85, label);
        }
        const primary = natalPattern.primary;
        if (primary === 'Mercury') add('communication', 7, 'あなたは言語化・整理の流れを体感しやすい傾向');
        if (primary === 'Moon') add('emotion', 7, 'あなたは気分や安心感の変化を体感しやすい傾向');
        if (primary === 'Venus') add('relationship', 7, 'あなたは対人・楽しみ・美意識の流れを体感しやすい傾向');
        if (primary === 'Mars') add('action', 7, 'あなたは行動や突破の流れを体感しやすい傾向');
        if (primary === 'Saturn') add('focus', 7, 'あなたは計画・責任・確認の流れを体感しやすい傾向');
        if (primary === 'Pluto') add('change', 7, 'あなたは深い変化や再構築の流れを体感しやすい傾向');

        this.applyUserContext(scores, breakdown, userContext);
        Object.keys(scores).forEach((k) => { scores[k] = Math.round(Math.max(0, Math.min(100, scores[k]))); });
        const positives = [scores.action, scores.focus, scores.relationship, scores.communication, scores.change].sort((a, b) => b - a).slice(0, 3);
        const impact = Math.max(0, Math.min(100, (positives.reduce((a, b) => a + b, 0) / positives.length) - Math.max(0, scores.rest - 72) * 0.25));
        return { scores, impact, breakdown: breakdown.sort((a, b) => Math.abs(b.value) - Math.abs(a.value)).slice(0, 8) };
    }

    static applyUserContext(scores, breakdown, userContext = {}) {
        const add = (key, value, label) => { scores[key] += value; breakdown.push({ key, value, label }); };
        const focus = userContext.focus || 'balanced';
        if (focus === 'work') { add('focus', 10, '重視テーマ: 仕事'); add('communication', 5, '重視テーマ: 仕事'); }
        if (focus === 'love') { add('relationship', 11, '重視テーマ: 恋愛・対人'); }
        if (focus === 'mental') { add('rest', 10, '重視テーマ: メンタルケア'); add('emotion', 6, '重視テーマ: メンタルケア'); }
        if (focus === 'action') { add('action', 11, '重視テーマ: 行動タイミング'); add('change', 5, '重視テーマ: 行動タイミング'); }
        if (focus === 'self') { add('change', 8, '重視テーマ: 自己理解'); add('rest', 4, '重視テーマ: 自己理解'); }
        const mood = userContext.mood || 'normal';
        if (mood === 'tired') { add('rest', 14, '今日の気分: 疲れ気味'); add('action', -8, '今日の気分: 疲れ気味'); }
        if (mood === 'anxious') { add('emotion', 12, '今日の気分: 不安'); add('rest', 8, '今日の気分: 不安'); }
        if (mood === 'focused') { add('focus', 10, '今日の気分: 集中したい'); }
        if (mood === 'social') { add('relationship', 9, '今日の気分: 人と話したい'); add('communication', 7, '今日の気分: 人と話したい'); }
        if (mood === 'energetic') { add('action', 10, '今日の気分: 元気'); }
    }

    static chooseTheme(scoring, features, type) {
        const scores = scoring.scores;
        const order = Object.keys(scores).sort((a, b) => scores[b] - scores[a]);
        let code = order[0] || 'action';
        if (features.hasPluto && scores.change >= 62) code = 'deep_transform';
        const map = {
            action: { code: 'action', label: '行動とスタート' },
            focus: { code: 'work_focus', label: '集中と段取り' },
            relationship: { code: 'relationship', label: '対人と調整' },
            emotion: { code: 'caution_emotion', label: '感情の整え方' },
            rest: { code: 'rest_healing', label: '休息と回復' },
            change: { code: 'breakthrough', label: '変化と突破' },
            communication: { code: 'communication', label: '連絡と整理' },
            deep_transform: { code: 'deep_transform', label: '深層の変容' }
        };
        return map[code] || map.action;
    }

    static composeText(theme, scoring, features, natalPattern, userContext, type) {
        const top = Object.entries(scoring.scores).sort((a, b) => b[1] - a[1]);
        const topKey = top[0]?.[0] || 'action';
        const topLabel = this.scoreLabel(topKey);
        const houseMeaning = AstrologyCompute.houseMeaning(features.moonHouse);
        const lifeReason = this.lifeReason(theme.code, topLabel, houseMeaning, type);
        const personalReason = this.personalReason(natalPattern.primary, userContext);
        const astroSummary = this.astroSummary(features, type);
        const description = `${lifeReason}${personalReason ? ` ${personalReason}` : ''}`;
        return {
            description,
            lifeReason,
            personalReason,
            astroSummary,
            smallSigns: this.smallSigns(theme.code),
            recommendations: this.recommendations(theme.code, scoring.scores, userContext)
        };
    }

    static scoreLabel(key) {
        return ({ action: '行動', focus: '集中', relationship: '対人', emotion: '感情', rest: '休息', change: '変化', communication: '連絡・整理' })[key] || key;
    }

    static lifeReason(code, topLabel, houseMeaning, type) {
        const span = type === 'hourly' ? 'この時間は' : type === 'daily' ? 'この日は' : type === 'weekly' ? 'この週は' : 'この月は';
        const map = {
            communication: `${span}、考えを短くまとめて人に伝える流れが強まります。${houseMeaning}が刺激され、連絡・確認・文章化が進みやすいタイミングです。`,
            work_focus: `${span}、やるべきことを整理し、現実的に進める力が高まりやすいです。${houseMeaning}が強調され、仕事・習慣・段取りに使いやすい流れです。`,
            relationship: `${span}、人とのやり取りから状況が動きやすいです。${houseMeaning}が刺激され、相談・調整・関係性の見直しに向いています。`,
            caution_emotion: `${span}、気分の波を丁寧に扱うことが大切です。${houseMeaning}が動くため、焦って決めるよりも一度整えてから動く方が安定します。`,
            rest_healing: `${span}、無理に前へ出るより回復と整理に向いています。${houseMeaning}が強まり、休む・手放す・内側を整えることが結果的に前進につながります。`,
            breakthrough: `${span}、小さな突破口を作りやすい流れです。${houseMeaning}が刺激され、停滞していたことに新しい動きを入れやすくなります。`,
            deep_transform: `${span}、表面的な出来事よりも内側の変化が大きくなりやすいです。${houseMeaning}を通じて、古い反応パターンを更新するきっかけが出やすいでしょう。`
        };
        return map[code] || `${span}、${topLabel}に関する流れを使いやすいタイミングです。`;
    }

    static personalReason(primary, userContext = {}) {
        const map = {
            Mercury: 'あなたは言葉にすることで判断や気持ちが整理されやすいため、短いメモ・返信・確認が流れを整える鍵になります。',
            Moon: 'あなたは安心感や気分の変化を体感しやすいため、無理に押し切らず、心が落ち着く形を選ぶほど流れに乗りやすくなります。',
            Venus: 'あなたは人との空気感や楽しさから調子が整いやすいため、柔らかい言葉づかいや心地よい選択が運を開きます。',
            Mars: 'あなたは動き出すことで状況が変わりやすいため、小さな一歩を先に置くと流れをつかみやすくなります。',
            Saturn: 'あなたは計画・責任・確認を通じて安定しやすいため、手順を決めてひとつずつ進めるほど成果につながります。',
            Pluto: 'あなたは深い変化を体感しやすい傾向があるため、違和感を無視せず、何を手放すかを見ると納得感が生まれます。',
            Sun: 'あなたは自分の意思が定まるほど力を出しやすいため、今日は何を大事にするかを一つ決めることが鍵になります。'
        };
        return map[primary] || '';
    }

    static astroSummary(features, type) {
        const base = type === 'hourly'
            ? `月は第${features.moonHouse}ハウス、ASCは${features.ascSign}、MCは${features.mcSign}。時間ごとの差は主に月・ASC・MC・ハウスの動きから読んでいます。`
            : `月は第${features.moonHouse}ハウス。主要なトランジットと出生図の接触から、体感しやすい生活テーマに変換しています。`;
        const top = features.majorAspects.slice(0, 3).map((a) => a.label).join('、');
        return top ? `${base} 主な根拠は${top}です。` : base;
    }

    static recommendations(code, scores, userContext = {}) {
        const doMap = {
            communication: ['返信・確認・短い相談を済ませる', '考えをメモにまとめる', '言いにくいことは短く穏やかに伝える'],
            work_focus: ['優先順位を3つに絞る', '未完了タスクを一つ片付ける', '予定や資料を確認する'],
            relationship: ['相手の話を先に聞く', '関係性の温度を整える', '感謝や確認の一言を送る'],
            caution_emotion: ['即決を避けて一度置く', '睡眠・食事・休憩を整える', '不安をメモに出して整理する'],
            rest_healing: ['休む時間を先に確保する', '不要な通知を減らす', '部屋や予定を軽く整える'],
            breakthrough: ['小さな一歩を今決める', '先延ばしを一つだけ動かす', '完璧より着手を優先する'],
            deep_transform: ['違和感の正体を書き出す', '執着しているものを見直す', '変えたい習慣を一つだけ決める']
        };
        const avoidMap = {
            communication: ['返信を急ぎすぎない', '言葉を強くしすぎない'],
            work_focus: ['完璧主義で止まらない', '全部を今日終わらせようとしない'],
            relationship: ['相手の反応を決めつけない', '気遣いを我慢に変えない'],
            caution_emotion: ['感情のまま大きな決断をしない', '自分を責める方向に使わない'],
            rest_healing: ['無理に予定を詰めない', '休むことを先送りしない'],
            breakthrough: ['勢いだけで約束しない', '焦って大きく変えすぎない'],
            deep_transform: ['白黒を急いで決めない', '古いパターンに戻る自分を責めない']
        };
        return { do: doMap[code] || doMap.breakthrough, avoid: avoidMap[code] || avoidMap.breakthrough };
    }

    static smallSigns(code) {
        const map = {
            communication: ['返信したくなる', 'メモが増える', '短い会話からヒントが来る'],
            work_focus: ['細部が気になる', '順番を整えたくなる', '後回しの用事が目に入る'],
            relationship: ['誰かの反応が気になる', '相談したくなる', '距離感を調整したくなる'],
            caution_emotion: ['理由なく焦る', '反応が強くなる', '一人で抱え込みやすい'],
            rest_healing: ['眠気が出る', '静かな場所に行きたくなる', '片付けたくなる'],
            breakthrough: ['急に動きたくなる', '突破口を思いつく', '保留が気になり始める'],
            deep_transform: ['同じテーマが繰り返し浮かぶ', '執着や違和感に気づく', '本音を隠しにくくなる']
        };
        return map[code] || [];
    }

    static factorObjects(features, theme) {
        const factors = [
            { type: 'house', label: `月が第${features.moonHouse}ハウス`, meaning: AstrologyCompute.houseMeaning(features.moonHouse) },
            { type: 'angle', label: `ASC ${features.ascSign}`, meaning: 'その時間の出方・雰囲気を示します。' },
            { type: 'angle', label: `MC ${features.mcSign}`, meaning: '仕事・外向きの判断軸を示します。' }
        ];
        for (const a of features.majorAspects.slice(0, 5)) {
            factors.push({ type: 'aspect', label: a.label, meaning: a.isTension ? '使い方に注意が必要な刺激です。' : '流れを使いやすい調和的な刺激です。' });
        }
        return factors;
    }

    static buildPlutoLayer(features, theme, type) {
        if (!features.hasPluto && theme.code !== 'deep_transform') return { active: false };
        return {
            active: true,
            theme: '深層の変容',
            intensity: type === 'hourly' ? '背景として弱〜中' : '中〜強',
            timeScale: type === 'hourly' ? '時間単位ではなく、日次・週次・月次の背景として作用' : '数日〜数ヶ月単位',
            currentPhase: '古い反応パターンに気づき、選び直す段階',
            astroBasis: '冥王星が出生図または重要感受点と関わるため、表面的な運不運よりも変容テーマとして扱います。',
            whatIsBeingTransformed: '執着、恐れ、無意識の反応、関係性の力学',
            shadow: '白黒思考、過度なコントロール、過去の反応への固着',
            rebirthPoint: '自分で選び直せる部分を一つ見つけること',
            signs: ['同じテーマが繰り返し浮かぶ', '本音を隠しにくい', '関係性の力学が見えやすい'],
            howToWorkWithIt: ['急いで結論を出さない', '違和感をメモする', '手放す対象を小さく決める'],
            whenItEases: '長期テーマのため、短時間で消すより波として扱うのが安全です。',
            nextTrigger: '月・ASC・MCが同じテーマを再刺激するタイミング'
        };
    }

    static buildSections(theme, scoring, text) {
        const body = (label, scoreKey) => ({
            title: label,
            astroReason: text.astroSummary,
            body: `${label}は${scoring.scores[scoreKey] ?? scoring.impact}程度。${text.recommendations.do[0] || text.lifeReason}`
        });
        return {
            mood: body('気分', 'emotion'),
            action: body('行動', 'action'),
            work: body('仕事', 'focus'),
            love: body('恋愛', 'relationship'),
            relationships: body('人間関係', 'relationship'),
            decision: body('決断', 'focus'),
            caution: { title: '注意点', astroReason: text.astroSummary, body: text.recommendations.avoid[0] || '急がず、一呼吸おいてから動きましょう。' },
            chance: { title: 'チャンス', astroReason: text.astroSummary, body: text.recommendations.do[0] || '小さな行動から流れをつかめます。' }
        };
    }

    static timelineText(type, date) {
        if (type === 'hourly') return { start: 'この時間帯の入口', peak: '時間帯の中盤', end: '次の時間帯へ移る頃', afterglow: '気分や反応に余韻', nextWave: '次のASC/MC/月の動き' };
        if (type === 'daily') return { start: '朝〜午前', peak: '日中〜夕方', end: '夜', afterglow: '翌日に少し残る', nextWave: '翌日の月の動き' };
        if (type === 'weekly') return { start: '週前半', peak: '週中盤', end: '週末', afterglow: '翌週の準備', nextWave: '次週のテーマ' };
        return { start: '月初', peak: '月中', end: '月末', afterglow: '翌月への持ち越し', nextWave: '次月のテーマ' };
    }

    static topRecommendations(items) {
        const topBy = (key) => items.slice().sort((a, b) => (b.scores?.[key] || 0) - (a.scores?.[key] || 0)).slice(0, 3);
        const highEmotion = items.slice().sort((a, b) => (b.scores?.emotion || 0) - (a.scores?.emotion || 0)).slice(0, 3);
        return {
            action: topBy('action'),
            focus: topBy('focus'),
            relationship: topBy('relationship'),
            rest: topBy('rest'),
            caution: highEmotion
        };
    }
}

window.ForecastEngine = ForecastEngine;
