# AstroInsight implementation notes

今回の変更では、これまでの要件に基づき以下を実装しました。

## タブ構成

下部ナビを次の順に変更しました。

- 今日
- 予報
- ネイタル
- 相性
- チャット

ネイタルは独立タブ化し、設定画面内の既存ネイタル表示も残しています。

## 予報期間

`js/config/app-config.json` の `forecast.profiles` に設定化しました。

- 月次: 18ヶ月
- 週次: 8週間
- 日次: 7日
- 時間: 24時間

時間予報は現在時刻の次の正時から24時間です。

## 生成AI利用削減

予報一覧・グラフ・スコア・短文・理由は、AIではなく `js/core/forecast-engine.js` でローカル生成します。
AIは次の用途に限定する設計にしました。

- ネイタル総合分析
- 予報の選択時点の詳細解釈
- 相性分析
- チャット相談

## 1時間ごとの占星術対応

1時間ごと予報では、月・ASC・MC・ハウス・ネイタルとの主要アスペクトを特徴量化し、時間ごとの差分を反映します。
冥王星などの長期天体は、時間単位の主役ではなく背景テーマとして扱います。

## 納得感の強化

予報カードは次の順で理由を表示します。

1. 生活上の理由
2. あなたの場合
3. スコア内訳
4. 占星術的根拠

スコアは星の動きだけでなく、ネイタル個性、重視テーマ、今日の気分を加味します。

## 管理画面

管理画面に以下を追加しました。

- 現在有効なモデル表示
- APIキー保存状態
- プロキシ使用可否
- 共通制約付与後の最終プロンプト表示
- 予報ルール設定の一覧表示

## 主要変更ファイル

- `index.html`
- `js/core/forecast-engine.js`
- `js/components/forecast.js`
- `js/components/today.js`
- `js/components/natal.js`
- `js/components/detail.js`
- `js/components/ui-controller.js`
- `js/components/settings.js`
- `js/config/app-config.json`
- `js/config/prompts.json`
- `js/core/ai-worker-manager.js`
- `js/app.js`
- `sw.js`
