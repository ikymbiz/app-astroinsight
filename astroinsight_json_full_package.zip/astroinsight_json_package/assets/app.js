(() => {
  'use strict';

  const STORE_PREFIX = 'astroinsight:';
  const FALLBACK_APP_CONFIG = {
    app: { name: 'AstroInsight', description: '星の波を読むAI占星術アプリ' },
    limits: { guestTrialLimit: 3 },
    ads: { enabled: false },
    admin: { pinEnabled: false },
    ai: { temperature: 0.85, topP: 0.9, maxTokens: 4500 },
    forecast: { defaultGranularity: 'daily', showList: false, selectedOnly: true, requireAstroReason: true, requireWaveReading: true, prioritizePluto: true }
  };
  const FALLBACK_MODELS = { defaultModelId: 'gemini-2.5-flash', providers: [], models: [] };
  const FALLBACK_PROMPTS = { prompts: {} };

  const PLANETS = [
    ['Sun','太陽','☉'], ['Moon','月','☽'], ['Mercury','水星','☿'], ['Venus','金星','♀'], ['Mars','火星','♂'],
    ['Jupiter','木星','♃'], ['Saturn','土星','♄'], ['Uranus','天王星','♅'], ['Neptune','海王星','♆'], ['Pluto','冥王星','♇'], ['ASC','ASC','ASC'], ['MC','MC','MC']
  ];
  const SIGNS = ['牡羊座','牡牛座','双子座','蟹座','獅子座','乙女座','天秤座','蠍座','射手座','山羊座','水瓶座','魚座'];
  const HOUSE_MEANINGS = {
    1:'自分自身・印象・始まり',2:'お金・価値観・才能',3:'会話・学び・連絡',4:'家・安心・土台',5:'恋愛・表現・楽しみ',6:'仕事習慣・健康・日課',
    7:'対人関係・パートナー',8:'深い関係・共有・変容',9:'学び・旅・視野拡大',10:'仕事・社会的役割・評価',11:'仲間・未来・コミュニティ',12:'内省・癒し・手放し'
  };

  const state = {
    tab: 'today',
    profile: null,
    appConfig: FALLBACK_APP_CONFIG,
    modelConfig: FALLBACK_MODELS,
    prompts: FALLBACK_PROMPTS,
    adminOpen: false,
    forecastGranularity: 'daily',
    selectedForecastIndex: 0,
    forecastData: null,
    forecastChart: null,
    todayMode: 'today',
    chatContext: null,
    chats: []
  };

  const $ = (id) => document.getElementById(id);
  const esc = (s='') => String(s).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  const store = {
    get(key, fallback=null) { try { const v = localStorage.getItem(STORE_PREFIX + key); return v ? JSON.parse(v) : fallback; } catch { return fallback; } },
    set(key, value) { localStorage.setItem(STORE_PREFIX + key, JSON.stringify(value)); },
    remove(key) { localStorage.removeItem(STORE_PREFIX + key); }
  };
  const toast = (msg) => { const t = $('toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(t._timer); t._timer = setTimeout(() => t.classList.remove('show'), 2800); };

  async function loadJson(path, fallback, overrideKey) {
    const saved = store.get(overrideKey);
    if (saved) return saved;
    try {
      const res = await fetch(path, { cache: 'no-store' });
      if (!res.ok) throw new Error(path);
      return await res.json();
    } catch {
      return fallback;
    }
  }

  async function boot() {
    state.appConfig = await loadJson('config/app-config.json', FALLBACK_APP_CONFIG, 'admin_app_config');
    state.modelConfig = await loadJson('config/models.json', FALLBACK_MODELS, 'admin_models_config');
    state.prompts = await loadJson('config/prompts.json', FALLBACK_PROMPTS, 'admin_prompts_config');
    state.profile = store.get('profile');
    state.forecastGranularity = state.appConfig.forecast?.defaultGranularity || 'daily';
    $('appTitle').textContent = state.appConfig.app?.name || 'AstroInsight';
    $('authStatus').textContent = state.profile ? `${state.profile.name} / ローカル保存` : 'プロフィール未設定';
    bindGlobalEvents();
    registerServiceWorker();
    if (location.hash === '#admin') openAdmin();
    if (!state.profile) openOnboarding();
    render();
  }

  function bindGlobalEvents() {
    document.querySelectorAll('.tab').forEach(btn => btn.addEventListener('click', () => {
      state.tab = btn.dataset.tab;
      document.querySelectorAll('.tab').forEach(b => b.classList.toggle('active', b === btn));
      render();
    }));
    $('refreshBtn').addEventListener('click', () => { state.forecastData = null; render(); toast('表示中データを再生成しました'); });
    $('settingsBtn').addEventListener('click', openSettings);
    let pressTimer = null;
    $('settingsBtn').addEventListener('pointerdown', () => { pressTimer = setTimeout(openAdmin, 700); });
    ['pointerup','pointerleave','pointercancel'].forEach(ev => $('settingsBtn').addEventListener(ev, () => clearTimeout(pressTimer)));
    window.addEventListener('hashchange', () => { if (location.hash === '#admin') openAdmin(); });
  }

  function registerServiceWorker() {
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('assets/sw.js').catch(() => {});
  }

  function render() {
    if (state.tab === 'today') renderToday();
    if (state.tab === 'forecast') renderForecast();
    if (state.tab === 'compat') renderCompat();
    if (state.tab === 'chat') renderChat();
  }

  function openOnboarding() {
    const s = $('onboarding');
    s.innerHTML = `
      <div class="between"><h2 class="title">はじめにプロフィール設定</h2></div>
      <div class="card">
        <p class="muted">星の波を読むために、最初にプロフィールを登録します。未ログインでもこの端末に保存されます。</p>
        <label class="label">名前 *</label><input id="obName" class="input" placeholder="例：Aiko" value="${esc(state.profile?.name || '')}">
        <label class="label">生年月日 *</label><input id="obBirth" type="date" class="input" value="${esc(state.profile?.birth || '')}">
        <label class="label">出生時間</label><input id="obTime" type="time" class="input" value="${esc(state.profile?.time || '')}">
        <label class="label">出生地</label><input id="obPlace" class="input" placeholder="例：東京" value="${esc(state.profile?.place || '')}">
        <button id="saveProfileBtn" class="btn primary block" style="margin-top:16px">保存して始める</button>
      </div>`;
    $('saveProfileBtn').onclick = () => {
      const p = { name: $('obName').value.trim(), birth: $('obBirth').value, time: $('obTime').value, place: $('obPlace').value.trim() };
      if (!p.name || !p.birth) return toast('名前と生年月日は必須です');
      state.profile = p; store.set('profile', p); $('authStatus').textContent = `${p.name} / ローカル保存`; closeSlide('onboarding'); render();
    };
    openSlide('onboarding');
  }
  function openSlide(id) { $(id).classList.add('open'); }
  function closeSlide(id) { $(id).classList.remove('open'); }

  function adBlock() { return `<div class="ad ${state.appConfig.ads?.enabled ? 'show' : ''}">広告枠</div>`; }

  function renderToday() {
    const data = buildTodayData(state.todayMode);
    $('main').innerHTML = `<section class="screen">
      <div class="seg"><button data-mode="today" class="${state.todayMode==='today'?'active':''}">今日</button><button data-mode="week" class="${state.todayMode==='week'?'active':''}">今週</button><button data-mode="month" class="${state.todayMode==='month'?'active':''}">今月</button></div>
      ${adBlock()}
      <article class="card forecast-card">
        <span class="score">影響度 ${data.score}/100</span><span class="wave-type">${esc(data.wave.type)}</span>
        <h3>${esc(data.label)}</h3>
        <p class="muted">${esc(data.theme)}</p>
        ${renderWave(data.wave)}
        ${renderAstroReason(data.astroReason)}
        ${renderSections(data.sections)}
        ${data.plutoLayer?.active ? renderPluto(data.plutoLayer) : ''}
        <button id="todayDetailBtn" class="btn primary block">詳しく見る</button>
      </article>
    </section>`;
    document.querySelectorAll('[data-mode]').forEach(b => b.onclick = () => { state.todayMode = b.dataset.mode; renderToday(); });
    $('todayDetailBtn').onclick = () => openDetail(data, state.todayMode);
  }

  function buildTodayData(mode) {
    const labels = { today:'今日の波', week:'今週の波', month:'今月の波' };
    const item = makeForecastItem(mode, new Date(), 0);
    return { ...item, label: labels[mode], theme: item.theme };
  }

  function renderForecast() {
    if (!state.forecastData || state.forecastData.granularity !== state.forecastGranularity) {
      state.forecastData = makeForecastData(state.forecastGranularity);
      state.selectedForecastIndex = Math.min(state.selectedForecastIndex, state.forecastData.items.length - 1);
    }
    const item = state.forecastData.items[state.selectedForecastIndex];
    $('main').innerHTML = `<section class="screen">
      <div class="seg four">
        ${['monthly','weekly','daily','hourly'].map(g => `<button data-gran="${g}" class="${state.forecastGranularity===g?'active':''}">${granLabel(g)}</button>`).join('')}
      </div>
      ${adBlock()}
      <div class="card"><div class="between"><div><b>波のチャート</b><div class="small muted">点をタップすると、その時点だけを詳しく表示します。一覧は表示しません。</div></div></div><div class="chart-wrap"><canvas id="forecastChart"></canvas></div></div>
      <article id="selectedForecast" class="card forecast-card">${renderForecastItem(item)}</article>
    </section>`;
    document.querySelectorAll('[data-gran]').forEach(b => b.onclick = () => { state.forecastGranularity = b.dataset.gran; state.selectedForecastIndex = 0; state.forecastData = null; renderForecast(); });
    renderForecastChart();
    bindForecastActions(item);
  }

  function granLabel(g) { return ({monthly:'月次', weekly:'週次', daily:'日次', hourly:'時間'})[g] || g; }

  function makeForecastData(granularity) {
    const counts = { monthly: 20, weekly: 22, daily: 75, hourly: 30 };
    const count = counts[granularity] || 30;
    const items = [];
    const now = new Date();
    for (let i = 0; i < count; i++) {
      const d = new Date(now);
      if (granularity === 'monthly') d.setMonth(now.getMonth() - 2 + i);
      if (granularity === 'weekly') d.setDate(now.getDate() - 56 + i * 7);
      if (granularity === 'daily') d.setDate(now.getDate() - 60 + i);
      if (granularity === 'hourly') d.setHours(now.getHours() - 48 + i * 4);
      items.push(makeForecastItem(granularity, d, i));
    }
    return { granularity, generatedAt: new Date().toISOString(), items };
  }

  function makeForecastItem(granularity, date, index) {
    const score = Math.max(18, Math.min(96, Math.round(62 + 22 * Math.sin(index / 2.4) + 9 * Math.cos(index / 5))));
    const heavy = score < 50;
    const plutoActive = index % 5 === 0 || heavy;
    const label = formatLabel(granularity, date);
    const theme = plutoActive ? '深い変容を越えて、主導権を取り戻す波' : (score > 75 ? '追い風を現実に変える波' : '整えながら流れをつかむ波');
    return {
      id: `${granularity}_${date.toISOString()}`,
      start: date.toISOString(),
      end: date.toISOString(),
      label,
      score,
      scoreReason: plutoActive ? '冥王星の深層テーマが表面化し、月や水星がそれを日常の出来事として感じさせるためです。' : '月・水星・金星の短期的な動きが生活リズムと対人関係に追い風を作るためです。',
      theme,
      wave: buildWave(granularity, label, heavy, plutoActive),
      astroReason: buildAstroReason(plutoActive),
      sections: buildSections(granularity, plutoActive, heavy),
      focus: { houses: plutoActive ? ['第8ハウス','第10ハウス','第12ハウス'] : ['第3ハウス','第5ハウス','第11ハウス'], planets: plutoActive ? ['冥王星','月','水星'] : ['月','金星','木星'], aspects: plutoActive ? ['冥王星と金星のスクエア','月と冥王星の接触','水星と土星の緊張'] : ['金星と木星の調和','月と水星の調和'] },
      plutoLayer: plutoActive ? buildPlutoLayer(granularity) : { active:false },
      positions: makePlanetPositions(date)
    };
  }

  function formatLabel(granularity, d) {
    const y = d.getFullYear(); const m = d.getMonth()+1; const day = d.getDate();
    if (granularity === 'monthly') return `${y}年${m}月`;
    if (granularity === 'weekly') { const end = new Date(d); end.setDate(d.getDate()+6); return `${m}/${day}〜${end.getMonth()+1}/${end.getDate()}`; }
    if (granularity === 'hourly') return `${m}/${day} ${String(d.getHours()).padStart(2,'0')}:00`;
    return `${y}年${m}月${day}日`;
  }

  function buildWave(granularity, label, heavy, plutoActive) {
    const time = timelineFor(granularity, label, heavy);
    return {
      type: plutoActive ? '冥王星が絡む深層変容の波' : (heavy ? '停滞から回復へ向かう波' : '追い風を形にする波'),
      status: heavy ? 'ピークを越える準備段階' : '伸び始めた流れを使う段階',
      identity: plutoActive
        ? 'この波は、表面的なラッキー/アンラッキーではなく、古い関係性・自己価値・仕事上の立ち位置を作り替える深い波です。今感じる重さは、終わらせるべきものと本当に残したいものを分けるために表面化しています。焦って結論を出すより、どこで自分の主導権を手放していたのかを見ることが大切です。'
        : 'この波は、日常の中に小さな追い風が入り、止まっていた連絡・予定・気持ちが少しずつ動き出す波です。勢いだけで大きく変えるより、今ある流れを丁寧につないでいくことで成果が出やすくなります。',
      timeline: time,
      astroBasis: plutoActive
        ? '冥王星が第8ハウス的な深い結びつきと手放しのテーマを強め、月がその感情を短期的に表面化させています。さらに水星が土星と緊張するため、考えが重くなりやすい一方、現実的な整理には向いています。'
        : '月が第3ハウスを通り、会話・連絡・短い移動が流れを作ります。金星と木星の調和は、人とのやわらかな関わりや楽しみを通じてチャンスが広がる配置です。',
      howToOvercome: '乗り越えるポイントは、今すぐ白黒をつけないことです。不安・事実・願望を紙に分けて書き、返事や判断は一晩置いてください。冥王星的な波では、相手を変えようとするより、自分が何を恐れているのかを見た方が早く抜け道が見つかります。',
      goodWaveUsage: '良い波が来ている場合は、終わる前に「話を出す」「候補を広げる」「信頼できる人に相談する」ところまで進めてください。結果を急ぐより、次につながる接点を増やすことが追い風の活かし方です。',
      changeSigns: '波が変わる予兆は、止まっていた連絡が戻ること、朝の重さが少し軽くなること、同じテーマを別々の人から聞くことです。冥王星が絡む場合は、急に人間関係を整理したくなる、執着していた相手への見方が変わる、という形でも現れます。',
      smallSigns: ['返信しようと思っていた相手から先に連絡が来る','一度諦めた予定に別ルートが出てくる','急に部屋やスマホ内を整理したくなる','同じキーワードを別々の人から聞く','眠気が強くなり、無理がきかなくなる','苦手だった人との会話が少し楽になる','迷っていたことに対して「これは違う」と感じる'],
      avoid: ['疲れている状態で大きな決断をする','勢いだけで相手に連絡する','相手を試すような言い方をする','曖昧な情報だけで判断する','全部一人で抱え込む'],
      recommendedActions: ['不安をメモに書いて、事実と想像を分ける','予定を1つ減らして余白を作る','信頼できる人に状況を話す','返信や判断を急がず、一晩置く','部屋・バッグ・スマホの中を整理する']
    };
  }

  function timelineFor(g, label, heavy) {
    if (g === 'monthly') return { start:'上旬', peak:'中旬', end:'下旬', afterglow:'翌月上旬まで余韻が残りやすいです。', nextWave:'翌月中旬から対人関係や仕事の動きが軽くなります。' };
    if (g === 'weekly') return { start:'週明け', peak:'週中', end:'週末', afterglow:'翌週前半は整理期間として残りやすいです。', nextWave:'翌週中盤から連絡や予定が動きやすくなります。' };
    if (g === 'hourly') return { start:'この時間帯の前半', peak:'中盤', end:'後半', afterglow:'次の時間帯まで少し余韻があります。', nextWave:'次の時間帯は気分が切り替わりやすいです。' };
    return { start:'朝', peak:'昼〜夕方', end:'夜', afterglow:'翌朝まで気持ちの整理として残りやすいです。', nextWave:'翌日から会話や予定を通じて流れが変わり始めます。' };
  }

  function buildAstroReason(plutoActive) {
    return {
      summary: plutoActive
        ? '冥王星が深い関係性・自己価値・主導権のテーマを刺激しています。月がその配置に触れることで、普段は奥にしまっている感情や違和感が表面化しやすい時です。水星と土星の緊張もあるため、考えすぎや悲観に傾きやすい一方、現実的な整理には強い配置です。これは短期の気分だけでなく、数ヶ月〜数年単位の深い変容の一部として読む必要があります。'
        : '月が会話や学びを表すハウスを刺激し、金星と木星の調和が対人関係や楽しみを広げます。小さな連絡、相談、発信が次の流れを作りやすい配置です。大きく賭けるより、軽く開いてみる行動がチャンスにつながります。',
      factors: plutoActive
        ? [
          { type:'planet', label:'冥王星が重要天体に接触', meaning:'執着・恐れ・主導権を見直し、深い再生を促す' },
          { type:'house', label:'第8ハウス/第12ハウスの強調', meaning:'深い感情、手放し、見えない疲れが表面化しやすい' },
          { type:'aspect', label:'水星と土星の緊張', meaning:'考えが重くなるが、条件整理や現実的な判断には向く' }
        ]
        : [
          { type:'house', label:'月が第3ハウス', meaning:'連絡・会話・学びが流れを変える' },
          { type:'aspect', label:'金星と木星の調和', meaning:'人との関わりからチャンスが広がる' },
          { type:'planet', label:'水星の活性化', meaning:'考えを言葉にすると状況が整理される' }
        ]
    };
  }

  function buildSections(granularity, plutoActive, heavy) {
    const reason = plutoActive ? '冥王星が深い感情と主導権のテーマを刺激しているため、表面的な出来事の奥にある本音が見えやすくなります。' : '月と水星が日常の動きを軽くし、金星が人との距離をやわらかくしています。';
    const long = (body) => body + (plutoActive ? ' ここで大切なのは、相手や状況を無理にコントロールしようとせず、自分が本当に守りたい価値を確認することです。' : ' 小さく動くほど、次の展開につながるヒントが見つかりやすいでしょう。');
    const sections = {
      mood: { title:'気分', astroReason: reason, body: long('気分は少し深いところに潜りやすく、普段なら流せる言葉にも反応しやすいかもしれません。ただ、それは弱さではなく、自分が本当は何を求めているのかに気づくサインです。') },
      action: { title:'行動', astroReason: '火星と水星の動きから、焦って大きく進めるより、短い作業や連絡の整理に向く配置です。', body: long('今は一気に突破するより、滞っていたものを一つずつ動かす方が波に乗れます。返信、予約、書類、メモ、部屋の整理など、すぐ終わる行動から始めてください。') },
      work: { title:'仕事', astroReason: '第10ハウスと土星のテーマが強まり、評価・責任・現実的な積み上げが重要になります。', body: long('仕事では派手な成果より、信頼の回復や条件整理が効きます。曖昧な約束を確認し、期限・役割・優先順位をはっきりさせると、重い流れが実務の強さに変わります。') },
      love: { title:'恋愛', astroReason: '金星と冥王星が関わる時は、ときめきだけでなく執着・不安・深い結びつきのテーマが出やすくなります。', body: long('恋愛では、相手の反応を深読みしすぎないことが鍵です。試す言葉ではなく、自分の本音を軽く、具体的に伝える方が関係は安定します。') },
      relationships: { title:'人間関係', astroReason: '水星と金星の状態から、会話の質が関係の流れを左右します。', body: long('人間関係では、合わせすぎて疲れる関係と、自然に話せる関係の差が見えやすくなります。距離を取ることは拒絶ではなく、関係を長く続けるための調整です。') },
      decision: { title:'決断', astroReason: '水星が土星と関わるため、勢いよりも条件確認・長期的な現実性を見る判断に向きます。', body: long('大きな決断は焦らなくて大丈夫です。今すぐ答えを出すより、何が怖くて迷っているのか、何が本音なのかを分けると、数日後に判断が軽くなります。') },
      caution: { title:'注意点', astroReason: '火星や冥王星が強い時は、反射的な言葉や支配したくなる気持ちが出やすくなります。', body: long('注意点は、疲れている時に強い言葉で結論を出してしまうことです。眠い、焦る、相手を試したいと感じる時ほど、返事を遅らせる勇気が流れを守ります。') },
      chance: { title:'チャンス', astroReason: '木星や金星の調和があるため、信頼できる人との会話から可能性が広がります。', body: long('チャンスは、ひとりで抱えていたことを誰かに話すところにあります。完璧な計画でなくても、今の状態を言葉にすると、紹介・助言・別ルートが見えてきます。') }
    };
    if (granularity === 'weekly') {
      sections.firstHalf = { title:'週前半の流れ', astroReason:'月の動きが内面整理を促すため、始まりは少し慎重です。', body:'週前半は無理に飛ばさず、予定や気持ちの棚卸しに向いています。何を進めるかより、何を減らすかが流れを軽くします。' };
      sections.secondHalf = { title:'週後半の流れ', astroReason:'水星と金星の働きが強まり、会話や調整が進みやすくなります。', body:'週後半は連絡、相談、提案に向きます。前半に整理したことを、やわらかく人に伝えると状況が動きます。' };
    }
    if (granularity === 'monthly') {
      sections.lifeDirection = { title:'人生・方向性', astroReason:'冥王星と土星の長期配置が、短期の出来事ではなく生き方の組み替えを促します。', body:'この月は、何を続けるかだけでなく、何をもう終わらせるかが大切です。古い役割や人に合わせる癖を見直すほど、次の方向性がはっきりします。' };
      sections.nextFlow = { title:'次の月への流れ', astroReason:'月末に向けて水星と金星の動きが軽くなり、対話から次の展開が生まれます。', body:'次の月は、今月整理したテーマを人に話すことで動きます。まだ完成していなくても、信頼できる相手に共有しておくと流れがつながります。' };
    }
    if (granularity === 'hourly') {
      sections.workTask = { title:'仕事・作業', astroReason:'月と水星が短時間の集中と確認作業に向く配置です。', body:'この時間は、新規の大勝負より、確認・返信・短い集中作業に向いています。気になることを一つだけ終わらせると波が整います。' };
      sections.loveContact = { title:'恋愛・連絡', astroReason:'金星の影響で、重い話より軽い一言が届きやすい時間です。', body:'長文で気持ちをぶつけるより、短くやさしい連絡が合っています。相手の反応を待つ余白も大切です。' };
      sections.bestAction = { title:'この時間にするとよいこと', astroReason:'月の短期的な流れが整える行動を後押しします。', body:'スマホの通知整理、短い返信、飲み物を用意して一息つく、次の予定を確認する。この小さな整え方が次の時間帯を軽くします。' };
    }
    return sections;
  }

  function buildPlutoLayer(granularity) {
    return {
      active: true,
      theme: '古い関係性の手放しと、自分の主導権を取り戻す変容',
      intensity: 88,
      timeScale: '数ヶ月〜数年単位',
      currentPhase: '表面化',
      astroBasis: 'トランジット冥王星がネイタル金星・太陽・MCなどの重要ポイントに触れる時期は、恋愛・自己価値・仕事上の立ち位置に深い変容が起きます。短期的には月や水星が触れた日に出来事として表面化します。',
      whatIsBeingTransformed: '相手に合わせすぎる関係、失うことへの恐れ、愛されるために自分を抑える癖、仕事で本音を飲み込む癖が変容の対象です。',
      shadow: '執着、嫉妬、相手を試す行動、状況をコントロールしたくなる気持ちが出やすくなります。',
      rebirthPoint: '自分の価値を相手の反応で測らず、自分で選び直すことが再生の入口になります。',
      signs: ['特定の人への執着が強くなる','昔の関係や未練が再浮上する','表面的には終わったはずの感情が戻ってくる','急に人間関係を整理したくなる','相手に合わせることへの違和感が強くなる'],
      howToWorkWithIt: ['感情をすぐ相手にぶつけず、まず何に反応しているかを見る','失う怖さと、本当に欲しい関係性を分ける','支配・依存・我慢で続いている関係を見直す','終わらせることを敗北ではなく再生の準備として捉える'],
      whenItEases: '短期的には月が冥王星から離れる2〜3日後に感情のピークは落ち着きます。ただし根本テーマは数ヶ月単位で続きます。',
      nextTrigger: '次に月・金星・火星が冥王星へ強く触れるタイミングで、同じテーマが再び表面化しやすいです。'
    };
  }

  function renderForecastChart() {
    const canvas = $('forecastChart');
    if (!canvas || !window.Chart) return;
    if (state.forecastChart) state.forecastChart.destroy();
    const items = state.forecastData.items;
    const nowIndex = Math.max(0, Math.min(items.length-1, Math.round(items.length * 0.55)));
    const ctx = canvas.getContext('2d');
    const plugin = { id:'nowLine', afterDraw(chart){ const x = chart.scales.x.getPixelForValue(nowIndex); const {top,bottom} = chart.chartArea; ctx.save(); ctx.strokeStyle='rgba(251,191,36,.9)'; ctx.setLineDash([4,4]); ctx.beginPath(); ctx.moveTo(x,top); ctx.lineTo(x,bottom); ctx.stroke(); ctx.restore(); } };
    state.forecastChart = new Chart(ctx, {
      type:'line',
      data:{ labels: items.map(x => x.label), datasets:[{ label:'影響度', data: items.map(x => x.score), tension:.35, pointRadius:4, pointHoverRadius:7 }] },
      options:{ responsive:true, maintainAspectRatio:false, plugins:{ legend:{display:false} }, scales:{ x:{ ticks:{ color:'#cbd5e1', maxTicksLimit:5 }, grid:{ color:'rgba(255,255,255,.07)' } }, y:{ min:0, max:100, ticks:{ color:'#cbd5e1' }, grid:{ color:'rgba(255,255,255,.07)' } } }, onClick:(evt, els) => { if (els.length) { state.selectedForecastIndex = els[0].index; const item = state.forecastData.items[state.selectedForecastIndex]; $('selectedForecast').innerHTML = renderForecastItem(item); bindForecastActions(item); $('selectedForecast').scrollIntoView({behavior:'smooth', block:'start'}); } } },
      plugins:[plugin]
    });
  }

  function renderForecastItem(item) {
    return `<span class="score">影響度 ${item.score}/100</span><span class="wave-type">${esc(item.wave.type)}</span>
      <h3>${esc(item.label)}</h3>
      <p><b>テーマ：</b>${esc(item.theme)}</p>
      <p class="muted"><b>なぜこのスコア？</b> ${esc(item.scoreReason)}</p>
      ${renderWave(item.wave)}
      ${renderAstroReason(item.astroReason)}
      ${item.plutoLayer?.active ? renderPluto(item.plutoLayer) : ''}
      ${renderSections(item.sections)}
      <div class="grid2" style="margin-top:12px"><button id="detailBtn" class="btn primary">この時点を詳しく見る</button><button id="askBtn" class="btn">AIに質問</button></div>`;
  }

  function bindForecastActions(item) {
    const detail = $('detailBtn'); if (detail) detail.onclick = () => openDetail(item, state.forecastGranularity);
    const ask = $('askBtn'); if (ask) ask.onclick = () => { state.chatContext = item; state.tab='chat'; document.querySelectorAll('.tab').forEach(b => b.classList.toggle('active', b.dataset.tab==='chat')); renderChat(); };
  }

  function renderWave(w) {
    return `<section class="forecast-section"><h4>この波の正体</h4><p>${esc(w.identity)}</p></section>
      <section class="forecast-section"><h4>この波はいつまで？</h4><ul class="bullet-list"><li>開始：${esc(w.timeline.start)}</li><li>ピーク：${esc(w.timeline.peak)}</li><li>抜ける時期：${esc(w.timeline.end)}</li><li>余韻：${esc(w.timeline.afterglow)}</li><li>次の波：${esc(w.timeline.nextWave)}</li></ul></section>
      <section class="forecast-section"><h4>乗り越えるポイント</h4><p>${esc(w.howToOvercome)}</p></section>
      <section class="forecast-section"><h4>良い波の活かし方</h4><p>${esc(w.goodWaveUsage)}</p></section>
      <section class="forecast-section"><h4>波が変わる予兆</h4><p>${esc(w.changeSigns)}</p></section>
      <section class="forecast-section"><h4>細かなサイン</h4><ul class="bullet-list">${w.smallSigns.map(x => `<li>${esc(x)}</li>`).join('')}</ul></section>
      <section class="forecast-section"><h4>やってはいけないこと</h4><ul class="bullet-list">${w.avoid.map(x => `<li>${esc(x)}</li>`).join('')}</ul></section>
      <section class="forecast-section"><h4>今やるとよいこと</h4><ul class="bullet-list">${w.recommendedActions.map(x => `<li>${esc(x)}</li>`).join('')}</ul></section>`;
  }

  function renderAstroReason(a) {
    return `<section class="forecast-section"><h4>占星術的な理由</h4><p>${esc(a.summary)}</p><ul class="factor-list">${a.factors.map(f => `<li><b>${esc(f.label)}</b>：${esc(f.meaning)}</li>`).join('')}</ul></section>`;
  }
  function renderPluto(p) {
    return `<section class="forecast-section pluto"><h4>冥王星の深いテーマ</h4><p><b>テーマ：</b>${esc(p.theme)}</p><p><b>時間軸：</b>${esc(p.timeScale)} / ${esc(p.currentPhase)}</p><p>${esc(p.astroBasis)}</p><p><b>何が変容している？</b><br>${esc(p.whatIsBeingTransformed)}</p><p><b>影として出やすいこと：</b><br>${esc(p.shadow)}</p><p><b>再生のポイント：</b><br>${esc(p.rebirthPoint)}</p><h4>予兆</h4><ul class="bullet-list">${p.signs.map(x => `<li>${esc(x)}</li>`).join('')}</ul><h4>どう向き合う？</h4><ul class="bullet-list">${p.howToWorkWithIt.map(x => `<li>${esc(x)}</li>`).join('')}</ul><p><b>いつ軽くなる？</b><br>${esc(p.whenItEases)}</p><p><b>次の表面化：</b><br>${esc(p.nextTrigger)}</p></section>`;
  }
  function renderSections(sections) {
    const order = ['lifeDirection','firstHalf','secondHalf','mood','action','work','workTask','love','loveContact','relationships','decision','caution','chance','bestAction','nextFlow'];
    return order.filter(k => sections[k]).map(k => {
      const s = sections[k];
      return `<section class="forecast-section"><h4>${esc(s.title)}</h4><div class="astro-note">占星術的には：${esc(s.astroReason || '')}</div><p>${esc(s.body || '')}</p></section>`;
    }).join('');
  }

  function openDetail(item, mode) {
    const pos = item.positions || makePlanetPositions(new Date(item.start || Date.now()));
    const houseGroups = groupByHouse(pos.transit);
    $('detailSlide').innerHTML = `<div class="between"><h2 class="title">詳細：${esc(item.label)}</h2><button class="btn small" id="closeDetail">閉じる</button></div>
      <div class="card"><h3 class="section-title">ホロスコープ</h3>${renderHoroscope(pos)}<p class="small muted">内側：ネイタル / 外側：トランジット。12ハウス境界と番号を表示しています。</p></div>
      <div class="card"><h3 class="section-title">この読み解きの根拠</h3>${item.plutoLayer?.active ? `<div class="forecast-section pluto"><h4>最重要：冥王星の影響</h4><p>${esc(item.plutoLayer.astroBasis)}</p><p>${esc(item.plutoLayer.whatIsBeingTransformed)}</p></div>` : ''}${renderAstroReason(item.astroReason)}<div class="forecast-section"><h4>ハウス分布</h4>${Object.keys(houseGroups).sort((a,b)=>a-b).map(h => `<p><b>第${h}ハウス</b>：${houseGroups[h].map(p=>p.jp).join('、')} / ${HOUSE_MEANINGS[h]}</p>`).join('')}</div></div>
      <div class="card"><h3 class="section-title">全体解説</h3>${renderWave(item.wave)}${renderSections(item.sections)}</div>
      <details class="details"><summary>天体位置の詳細を見る</summary>${renderPlanetTable(pos)}</details>`;
    $('closeDetail').onclick = () => closeSlide('detailSlide');
    openSlide('detailSlide');
  }

  function makePlanetPositions(date) {
    const seed = Math.floor(date.getTime() / 86400000);
    const natal = PLANETS.map((p, i) => planetPos(p, seed + i * 17, i, 0));
    const transit = PLANETS.map((p, i) => planetPos(p, seed + i * 29 + 77, i, 1));
    return { natal, transit };
  }
  function planetPos(p, seed, i, ring) {
    const lon = ((seed * (i + 3) * 7.13) % 360 + 360) % 360;
    return { key:p[0], jp:p[1], symbol:p[2], lon, sign:SIGNS[Math.floor(lon/30)], degree: +(lon%30).toFixed(1), house: Math.floor(((lon + 18) % 360) / 30) + 1, ring };
  }
  function groupByHouse(planets) { return planets.reduce((a,p) => ((a[p.house] ||= []).push(p), a), {}); }
  function polar(cx, cy, r, deg) { const a = (deg - 90) * Math.PI / 180; return [cx + r*Math.cos(a), cy + r*Math.sin(a)]; }
  function renderHoroscope(pos) {
    const cx=150, cy=150, outer=132, inner=78;
    let svg = `<svg class="horo" viewBox="0 0 300 300" role="img" aria-label="ホロスコープ図"><circle cx="${cx}" cy="${cy}" r="${outer}" fill="rgba(255,255,255,.04)" stroke="rgba(255,255,255,.28)"/><circle cx="${cx}" cy="${cy}" r="${inner}" fill="rgba(255,255,255,.03)" stroke="rgba(255,255,255,.18)"/>`;
    for (let h=0; h<12; h++) { const deg=h*30; const [x,y]=polar(cx,cy,outer,deg); const [lx,ly]=polar(cx,cy,outer-16,deg+15); svg += `<line class="house-line" x1="${cx}" y1="${cy}" x2="${x}" y2="${y}"/><text class="house-label" x="${lx}" y="${ly}" text-anchor="middle" dominant-baseline="middle">${h+1}</text>`; }
    pos.natal.forEach(p => { const [x,y]=polar(cx,cy,96,p.lon); svg += `<text x="${x}" y="${y}" text-anchor="middle" dominant-baseline="middle" fill="#fde68a" font-size="13" font-weight="900">${p.symbol}</text>`; });
    pos.transit.forEach(p => { const [x,y]=polar(cx,cy,120,p.lon); svg += `<text x="${x}" y="${y}" text-anchor="middle" dominant-baseline="middle" fill="#bfdbfe" font-size="13" font-weight="900">${p.symbol}</text>`; });
    return svg + `</svg>`;
  }
  function renderPlanetTable(pos) {
    return `<div class="grid2"><div><h4>ネイタル</h4>${pos.natal.map(p => `<p class="small">${p.symbol} ${p.jp}：${p.sign} ${p.degree}° / 第${p.house}ハウス</p>`).join('')}</div><div><h4>トランジット</h4>${pos.transit.map(p => `<p class="small">${p.symbol} ${p.jp}：${p.sign} ${p.degree}° / 第${p.house}ハウス</p>`).join('')}</div></div>`;
  }

  function renderCompat() {
    $('main').innerHTML = `<section class="screen">${adBlock()}<div class="card"><h2 class="title">相性</h2><p class="muted">相性機能は、相手との関わり方を読む機能です。冥王星が絡む場合は、強い引力・執着・関係性の再編も慎重に読みます。</p><button class="btn primary block">友達を追加</button></div></section>`;
  }
  function renderChat() {
    const badge = state.chatContext ? `<div class="card"><b>${esc(state.chatContext.label)}の予報について質問中</b><button id="clearCtx" class="btn small" style="float:right">解除</button></div>` : '';
    $('main').innerHTML = `<section class="screen">${adBlock()}${badge}<div class="chat-log" id="chatLog">${state.chats.map(m => `<div class="bubble ${m.role}">${esc(m.text)}</div>`).join('')}</div><div class="card"><textarea id="chatInput" class="textarea" placeholder="この波はいつ抜ける？ 冥王星はどう関係している？"></textarea><button id="sendChat" class="btn primary block" style="margin-top:8px">送信</button></div></section>`;
    const cc = $('clearCtx'); if (cc) cc.onclick = () => { state.chatContext = null; renderChat(); };
    $('sendChat').onclick = () => { const text = $('chatInput').value.trim(); if (!text) return; state.chats.push({role:'user', text}); const ctx = state.chatContext ? `${state.chatContext.label}の波では、${state.chatContext.wave.type}が中心です。冥王星の関与がある場合は、短期の感情と長期の変容を分けて見てください。` : ''; state.chats.push({role:'ai', text:`${ctx}\n占星術的には、まず月・水星・金星・火星の短期波と、土星・冥王星の深層波を分けて見ます。しんどさが強い場合は、冥王星的な「手放しと再生」が表面化している可能性があります。今は結論を急がず、不安・事実・本音を分けることが乗り越えるポイントです。`}); renderChat(); };
  }

  function openSettings() {
    $('settingsSlide').innerHTML = `<div class="between"><h2 class="title">通常設定</h2><button id="closeSettings" class="btn small">閉じる</button></div>
      <div class="card"><h3 class="section-title">プロフィール</h3><label class="label">名前</label><input id="setName" class="input" value="${esc(state.profile?.name || '')}"><label class="label">生年月日</label><input id="setBirth" type="date" class="input" value="${esc(state.profile?.birth || '')}"><label class="label">出生時間</label><input id="setTime" type="time" class="input" value="${esc(state.profile?.time || '')}"><label class="label">出生地</label><input id="setPlace" class="input" value="${esc(state.profile?.place || '')}"><button id="saveSetProfile" class="btn primary block" style="margin-top:14px">保存</button></div>
      <div class="card"><h3 class="section-title">アカウント</h3><p class="muted">現在はローカル保存モードです。モデル・プロンプト・APIキー・データ管理は管理用設定に移動済みです。</p><button id="adminShortcut" class="btn block">管理用設定を開く</button><p class="small muted">現在はパスワードなし。#admin または歯車長押しでも開けます。</p></div>`;
    $('closeSettings').onclick = () => closeSlide('settingsSlide');
    $('saveSetProfile').onclick = () => { const p = { name:$('setName').value.trim(), birth:$('setBirth').value, time:$('setTime').value, place:$('setPlace').value.trim() }; if (!p.name || !p.birth) return toast('名前と生年月日は必須です'); state.profile=p; store.set('profile',p); $('authStatus').textContent=`${p.name} / ローカル保存`; toast('プロフィールを保存しました'); render(); };
    $('adminShortcut').onclick = openAdmin;
    openSlide('settingsSlide');
  }

  function openAdmin() {
    state.adminOpen = true;
    const modelsText = JSON.stringify(state.modelConfig, null, 2);
    const promptsText = JSON.stringify(state.prompts, null, 2);
    const appText = JSON.stringify(state.appConfig, null, 2);
    $('settingsSlide').innerHTML = `<div class="between"><h2 class="title">管理用設定 <span class="admin-badge">NO PIN</span></h2><button id="closeAdmin" class="btn small">閉じる</button></div>
      <div class="card"><p class="muted">モデル・プロバイダー・APIキー・プロンプト・変数・データ管理はここに集約しています。現在はアドミンパスワードを削除済みです。本番ではCloudflare Worker/Firebase custom claimsで認可してください。</p></div>
      <div class="card"><h3 class="section-title">プロバイダー別APIキー</h3>${renderProviderKeys()}</div>
      <div class="card"><h3 class="section-title">モデル追加フォーム</h3>${renderModelForm()}<button id="addModelBtn" class="btn primary block" style="margin-top:10px">モデルを追加</button></div>
      <div class="card"><h3 class="section-title">models.json</h3><textarea id="modelsJson" class="textarea json-editor">${esc(modelsText)}</textarea><button data-save-json="models" class="btn primary block">models.jsonを保存</button></div>
      <div class="card"><h3 class="section-title">prompts.json</h3><textarea id="promptsJson" class="textarea json-editor">${esc(promptsText)}</textarea><button data-save-json="prompts" class="btn primary block">prompts.jsonを保存</button></div>
      <div class="card"><h3 class="section-title">app-config.json</h3><textarea id="appJson" class="textarea json-editor">${esc(appText)}</textarea><button data-save-json="app" class="btn primary block">app-config.jsonを保存</button></div>
      <div class="card"><h3 class="section-title">データ管理</h3><div class="grid2"><button id="exportData" class="btn">バックアップDL</button><button id="clearData" class="btn danger">全データ消去</button></div></div>`;
    $('closeAdmin').onclick = () => closeSlide('settingsSlide');
    bindAdminEvents();
    openSlide('settingsSlide');
  }
  function renderProviderKeys() {
    return (state.modelConfig.providers || []).map(p => {
      const saved = localStorage.getItem(STORE_PREFIX + p.apiKeyStorageKey) ? '保存済み' : '未保存';
      return `<div class="provider-card"><div class="between"><b>${esc(p.name)}</b><span class="small muted">${esc(saved)}</span></div><label class="label">API Key</label><input id="key_${esc(p.id)}" class="input" type="password" placeholder="${esc(p.apiKeyStorageKey)}"><div class="grid2" style="margin-top:8px"><button data-save-key="${esc(p.id)}" class="btn small">保存</button><button data-toggle-key="${esc(p.id)}" class="btn small">表示/非表示</button></div><p class="small muted">プロキシ利用時は通常不要。直接API利用時のみ使用します。</p></div>`;
    }).join('') || '<p class="muted">プロバイダーが未登録です。</p>';
  }
  function renderModelForm() {
    const providers = state.modelConfig.providers || [];
    return `<label class="label">プリセット</label><select id="presetSelect" class="select"><option value="">選択しない</option>${(state.modelConfig.presets||[]).map((p,i)=>`<option value="${i}">${esc(p.name)}</option>`).join('')}</select><label class="label">モデル名</label><input id="newModelName" class="input" placeholder="例：GPT-4.1 Mini"><label class="label">モデルID</label><input id="newModelId" class="input" placeholder="例：gpt-4.1-mini"><label class="label">プロバイダー</label><select id="newProviderId" class="select">${providers.map(p=>`<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('')}</select><label class="label">エンドポイントパス</label><input id="newModelPath" class="input" placeholder="/chat/completions"><div class="grid2"><label class="row small"><input id="newStreaming" type="checkbox" checked> Streaming</label><label class="row small"><input id="newProxy" type="checkbox" checked> Proxy対応</label><label class="row small"><input id="newRecommended" type="checkbox"> 推奨</label><label class="row small"><input id="newEnabled" type="checkbox" checked> 有効</label></div>`;
  }
  function bindAdminEvents() {
    document.querySelectorAll('[data-save-key]').forEach(btn => btn.onclick = () => { const p = (state.modelConfig.providers||[]).find(x => x.id === btn.dataset.saveKey); const v = $(`key_${p.id}`).value; if (!v) return toast('APIキーが空です'); localStorage.setItem(STORE_PREFIX + p.apiKeyStorageKey, v); toast(`${p.name}のAPIキーを保存しました`); });
    document.querySelectorAll('[data-toggle-key]').forEach(btn => btn.onclick = () => { const input = $(`key_${btn.dataset.toggleKey}`); input.type = input.type === 'password' ? 'text' : 'password'; });
    const preset = $('presetSelect'); if (preset) preset.onchange = () => { const p = state.modelConfig.presets?.[Number(preset.value)]; if (!p) return; $('newModelName').value=p.name; $('newModelId').value=p.id; $('newProviderId').value=p.providerId; $('newModelPath').value=p.path; };
    $('addModelBtn').onclick = () => { const m = { id:$('newModelId').value.trim(), name:$('newModelName').value.trim(), providerId:$('newProviderId').value, path:$('newModelPath').value.trim(), streaming:$('newStreaming').checked, recommended:$('newRecommended').checked, proxySupported:$('newProxy').checked, enabled:$('newEnabled').checked }; if (!m.id || !m.name || !m.providerId || !m.path) return toast('モデル名・ID・プロバイダー・パスは必須です'); state.modelConfig.models ||= []; state.modelConfig.models.push(m); store.set('admin_models_config', state.modelConfig); $('modelsJson').value = JSON.stringify(state.modelConfig, null, 2); toast('モデルを追加しました'); };
    document.querySelectorAll('[data-save-json]').forEach(btn => btn.onclick = () => {
      try {
        if (btn.dataset.saveJson === 'models') { state.modelConfig = JSON.parse($('modelsJson').value); store.set('admin_models_config', state.modelConfig); }
        if (btn.dataset.saveJson === 'prompts') { state.prompts = JSON.parse($('promptsJson').value); store.set('admin_prompts_config', state.prompts); }
        if (btn.dataset.saveJson === 'app') { state.appConfig = JSON.parse($('appJson').value); store.set('admin_app_config', state.appConfig); }
        toast('JSONを保存しました');
      } catch (e) { toast('JSON形式が不正です: ' + e.message); }
    });
    $('exportData').onclick = () => { const data = {}; Object.keys(localStorage).filter(k=>k.startsWith(STORE_PREFIX)).forEach(k=>data[k]=localStorage.getItem(k)); downloadText('astroinsight-backup.json', JSON.stringify(data,null,2)); };
    $('clearData').onclick = () => { if (!confirm('全データを消去しますか？')) return; Object.keys(localStorage).filter(k=>k.startsWith(STORE_PREFIX)).forEach(k=>localStorage.removeItem(k)); toast('全データを消去しました'); location.reload(); };
  }
  function downloadText(name, text) { const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([text],{type:'application/json'})); a.download=name; a.click(); URL.revokeObjectURL(a.href); }

  boot();
})();
