# GitHub Pages へのデプロイ手順

このプロジェクトは GitHub Pages の **root deploy** 構造になっています。`docs/` や `dist/` のようなサブディレクトリは使いません。

## 手順

### 1. リポジトリを作成

```bash
git init
git add .
git commit -m "AstroInsight initial deploy"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

### 2. GitHub Pages を有効化

1. リポジトリの **Settings → Pages** を開く
2. **Source** を `Deploy from a branch` に
3. **Branch** を `main` / `/ (root)` に設定して **Save**

数分後、`https://<your-username>.github.io/<your-repo>/` で公開されます。

> リポジトリ名を `<your-username>.github.io` にすると、ルートドメイン `https://<your-username>.github.io/` で公開されます。

### 3. Service Worker のスコープを確認

ブラウザの DevTools → Application → Service Workers を開き、登録されている SW のスコープがリポジトリのパスを含んでいることを確認してください。`./sw.js` で登録しているので、自動的に正しいスコープになります。

### 4. Google ログイン (GIS) を有効化

1. [Google Cloud Console](https://console.cloud.google.com/) でプロジェクトを開くか作成
2. **API とサービス → 認証情報 → 認証情報を作成 → OAuth クライアント ID**
3. アプリケーションの種類: **ウェブ アプリケーション**
4. **承認済みの JavaScript 生成元** に GitHub Pages の URL を追加（例: `https://<your-username>.github.io`）
5. 発行された **クライアント ID** をコピー
6. アプリで `#admin` を開く → 「🆔 Google ログイン (GIS)」セクションに Client ID と管理者メールを保存
7. リロードしてアカウントセクションに Google サインインボタンが表示されれば成功

### 5. （任意）Cloudflare Worker プロキシを有効化

1. Cloudflare Workers でプロキシ Worker をデプロイ（要件§5・§20 仕様に準拠した SSE 中継実装）
2. 管理画面でベース URL を保存
3. ログイン済みかつプロキシ対応モデルを選択した状態で生成すると、プロキシ経由になります

## トラブルシューティング

- **Google サインインボタンが表示されない**：DevTools コンソールで GIS のエラーを確認。多くの場合、承認済み JavaScript 生成元の登録漏れ。
- **`The given origin is not allowed for the given client ID`**：Google Cloud Console で承認済み生成元にこのサイトのオリジンが入っていません。プロトコル付き（`https://`）で完全一致が必要。
- **アイコンが反映されない / アプリ名が違う**：`#admin` から `app-config.json` の `app.name` / `app.description` / `ui.themeColor` を更新してください。起動時に動的 manifest にも反映されます。
- **APIキーがブラウザに保存されているのが心配**：本番では必ず Cloudflare Worker プロキシを有効化し、フロントには APIキーを置かないでください。
- **Service Worker が古いまま**：DevTools → Application → Service Workers で **Unregister** し、ハードリロードしてください。`sw.js` の `CACHE_NAME` も更新できます。

## 既知の制約

- フロント側のみで動作するため、サーバーサイドの認可検証が必要な場合は Cloudflare Worker 等を別途用意する
- GitHub Pages 単体では SSE プロキシは提供できない（直接 API を叩く構成のみ動作）
