/* ============================================================
 * AstroInsight - AI Generation Web Worker（v9）
 * SSE / JSONレスポンスを横断的に扱う。
 * ============================================================ */

function extractTextChunk(data, provider, proxy) {
    if (!data) return '';
    if (typeof data === 'string') return data;
    // Proxy implementations may normalize to these shapes.
    if (proxy && proxy.url) {
        if (typeof data.chunk === 'string') return data.chunk;
        if (typeof data.text === 'string') return data.text;
        if (typeof data.delta === 'string') return data.delta;
        if (data.delta && typeof data.delta.text === 'string') return data.delta.text;
        if (data.message && typeof data.message.content === 'string') return data.message.content;
    }
    // Google Gemini SSE / JSON
    if (data.candidates?.[0]?.content?.parts?.[0]?.text) return data.candidates[0].content.parts[0].text;
    if (Array.isArray(data.candidates?.[0]?.content?.parts)) {
        return data.candidates[0].content.parts.map((p) => p.text || '').join('');
    }
    // OpenAI Responses API SSE / JSON
    if (data.type === 'response.output_text.delta' && typeof data.delta === 'string') return data.delta;
    if (typeof data.output_text === 'string') return data.output_text;
    if (typeof data.response?.output_text === 'string') return data.response.output_text;
    if (Array.isArray(data.output)) {
        return data.output.flatMap((item) => item.content || [])
            .map((part) => part.text || part.output_text || '')
            .join('');
    }
    // OpenAI / xAI chat completions SSE / JSON
    if (data.choices?.[0]?.delta?.content) return data.choices[0].delta.content;
    if (data.choices?.[0]?.message?.content) return data.choices[0].message.content;
    if (data.choices?.[0]?.text) return data.choices[0].text;
    // Anthropic SSE / JSON
    if (data.type === 'content_block_delta' && data.delta?.text) return data.delta.text;
    if (Array.isArray(data.content)) return data.content.map((p) => p.text || '').join('');
    if (typeof data.completion === 'string') return data.completion;
    return '';
}

self.onmessage = async function (e) {
    const { action, apiKey, model, modelMeta, prompt, isJson, proxy, ai } = e.data;
    if (action !== 'generate') return;

    const aiOpts = ai || {};
    const maxTokens = aiOpts.maxTokens || 4500;
    const temperature = (aiOpts.temperature != null) ? aiOpts.temperature : 0.85;
    const topP = (aiOpts.topP != null) ? aiOpts.topP : 0.9;

    try {
        let url, headers, body;
        let provider = modelMeta && (modelMeta.provider || modelMeta.providerId) ? (modelMeta.provider || modelMeta.providerId) : null;
        if (!provider) {
            if (model.startsWith('gemini')) provider = 'google';
            else if (model.startsWith('claude')) provider = 'anthropic';
            else if (model.startsWith('gpt') || model.startsWith('o1') || model.startsWith('o3')) provider = 'openai';
            else if (model.startsWith('grok')) provider = 'xai';
            else provider = 'openai';
        }

        if (proxy && proxy.url) {
            url = proxy.url;
            headers = Object.assign({ 'Content-Type': 'application/json' }, proxy.headers || {});
            body = JSON.stringify({ provider, model, prompt, stream: true, max_tokens: maxTokens, temperature, top_p: topP });
        } else if (provider === 'google') {
            const baseEndpoint = (modelMeta && modelMeta.endpoint) || 'https://generativelanguage.googleapis.com/v1beta/models/' + model + ':streamGenerateContent';
            const sep = baseEndpoint.includes('?') ? '&' : '?';
            url = baseEndpoint + sep + 'alt=sse&key=' + apiKey;
            headers = { 'Content-Type': 'application/json' };
            body = JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { maxOutputTokens: maxTokens, temperature, topP } });
        } else if (provider === 'openai') {
            url = (modelMeta && modelMeta.endpoint) || 'https://api.openai.com/v1/responses';
            headers = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + apiKey };
            if (url.includes('/responses')) {
                body = JSON.stringify({ model, input: prompt, stream: true, max_output_tokens: maxTokens, temperature, top_p: topP });
            } else {
                body = JSON.stringify({ model, messages: [{ role: 'user', content: prompt }], stream: true, max_tokens: maxTokens, temperature, top_p: topP });
            }
        } else if (provider === 'xai') {
            url = (modelMeta && modelMeta.endpoint) || 'https://api.x.ai/v1/chat/completions';
            headers = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + apiKey };
            body = JSON.stringify({ model, messages: [{ role: 'user', content: prompt }], stream: true, max_tokens: maxTokens, temperature, top_p: topP });
        } else if (provider === 'anthropic') {
            url = (modelMeta && modelMeta.endpoint) || 'https://api.anthropic.com/v1/messages';
            headers = {
                'Content-Type': 'application/json',
                'x-api-key': apiKey,
                'anthropic-version': '2023-06-01',
                'anthropic-dangerously-allow-browser': 'true'
            };
            body = JSON.stringify({ model, max_tokens: maxTokens, temperature, top_p: topP, messages: [{ role: 'user', content: prompt }], stream: true });
        } else {
            throw new Error('未対応のプロバイダー: ' + provider);
        }

        const response = await fetch(url, { method: 'POST', headers, body });
        if (!response.ok) {
            const errBody = await response.text().catch(() => '');
            throw new Error('API Error: ' + response.status + (errBody ? ' / ' + errBody.slice(0, 300) : ''));
        }

        const contentType = response.headers.get('content-type') || '';
        let fullText = '';
        if (!response.body || contentType.includes('application/json')) {
            const json = await response.json();
            fullText = extractTextChunk(json, provider, proxy);
        } else {
            const reader = response.body.getReader();
            const decoder = new TextDecoder('utf-8');
            let buffer = '';
            const handleLine = (line) => {
                line = line.trim();
                if (!line || line === 'data: [DONE]') return;
                if (line.startsWith('data: ')) line = line.substring(6).trim();
                if (!line || line === '[DONE]') return;
                try {
                    const data = JSON.parse(line);
                    const chunk = extractTextChunk(data, provider, proxy);
                    if (chunk) {
                        fullText += chunk;
                        if (!isJson) self.postMessage({ type: 'chunk', text: fullText });
                    }
                } catch (err) {
                    // Some proxies may stream plain text lines.
                    if (proxy && proxy.url && !line.startsWith('event:')) {
                        fullText += line;
                        if (!isJson) self.postMessage({ type: 'chunk', text: fullText });
                    }
                }
            };
            while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split(/\r?\n/);
                buffer = lines.pop();
                for (const line of lines) handleLine(line);
            }
            if (buffer.trim()) handleLine(buffer);
        }

        if (!fullText) throw new Error('応答データが空でした。');
        self.postMessage({ type: 'done', text: fullText });
    } catch (error) {
        self.postMessage({ type: 'error', message: error.message });
    }
};
