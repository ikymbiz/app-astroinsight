/* ============================================================
 * AstroInsight - Main App（v9 admin/bootstrap fixes）
 * 全体オーケストレーション。要件§1 §2 §5 §17 §20 §22 を統合。
 * ============================================================ */

class AstroApp {
    constructor() {
        this.db = new AstroDB();
        this.auth = new AuthService(this.db);
        this.proxy = new ProxyService(this.db);
        this.config = new ConfigLoader(this.db);
        this.flags = new FeatureFlags(this.db, this.auth, this.config);
        this.snackbar = new Snackbar();
        this.workerMgr = new AIWorkerManager('./js/workers/ai-worker.js', 4);

        this.ui = new UIController(this);
        this.profile = new ProfileComponent(this);
        this.natal = new NatalComponent(this);
        this.today = new TodayComponent(this);
        this.forecast = new ForecastComponent(this);
        this.compat = new CompatComponent(this);
        this.chat = new ChatComponent(this);
        this.detail = new DetailComponent(this);
        this.settings = new SettingsComponent(this);
        this.onboarding = new OnboardingComponent(this);
        this.ads = new AdsComponent(this);

        this.chartInstance = null;
        this._wakeLock = null;
        this._splashMinMs = 650;
        this._bootStartedAt = Date.now();
        this._manifestObjectUrl = null;
    }

    async init() {
        console.log('%c[AstroInsight] build=v9-admin-splash-fixes-2026-04-28', 'color:#7c3aed;font-weight:bold');
        try {
            this._setSplashStatus('星の設定を読み込み中…');
            await this.db.init();
            await this.config.loadDefaults();
            this.auth.setConfig(this.config);
            this.proxy.setConfig(this.config);

            this._setSplashStatus('認証とプロキシを確認中…');
            await this.auth.init();
            await this.flags.load();
            await this.proxy.init();
            this.applyAppChrome();

            this.auth.onChange(() => {
                if (this.settings._renderAccountSection) this.settings._renderAccountSection();
                if (this.settings._renderAdminButton) this.settings._renderAdminButton();
                if (this.settings._renderModelSection) this.settings._renderModelSection();
                this.ads.refresh();
            });

            this._setSplashStatus('画面を準備中…');
            await this.settings.load();
            await this.profile.load();
            await this.natal.load();
            await this.today.load();
            await this.forecast.load({ applyDefault: true });
            await this.compat.load();
            await this.chat.load();

            this.ui.setupEventListeners();
            this.ui.bindAdminTriggers();
            this.ads.refresh();

            const adminAtBoot = location.hash === '#admin';
            if (adminAtBoot) {
                this.ui.hideOnboarding();
                this.ui.switchTab('today');
                this.ui.openSettings();
                setTimeout(() => this.settings.openAdminPanel(), 180);
            } else {
                const showed = await this.onboarding.maybeShow();
                if (!showed) this.ui.switchTab('today');
            }
        } catch (e) {
            console.error('[AstroInsight] init failed:', e);
            this.showError('起動に失敗しました: ' + (e?.message || e));
        } finally {
            await this.hideSplash();
        }
    }

    applyAppChrome() {
        const appName = this.flags.get('app_name') || this.config.getAppConfig()?.app?.name || 'AstroInsight';
        const desc = this.flags.get('app_description') || this.config.getAppConfig()?.app?.description || '';
        const theme = this.flags.get('theme_color') || this.config.getAppConfig()?.ui?.themeColor || '#7c3aed';
        const t = document.querySelector('title');
        if (t) t.textContent = appName;
        const h = document.getElementById('appTitle');
        if (h) h.textContent = appName;
        const mDesc = document.querySelector('meta[name="description"]');
        if (mDesc && desc) mDesc.setAttribute('content', desc);
        const mTheme = document.querySelector('meta[name="theme-color"]');
        if (mTheme && theme) mTheme.setAttribute('content', theme);
        document.documentElement.style.setProperty('--astro-color', theme);
        this._applyDynamicManifest(appName, desc, theme);
    }

    _applyDynamicManifest(appName, description, themeColor) {
        const link = document.querySelector('link[rel="manifest"]');
        if (!link || typeof Blob === 'undefined' || typeof URL === 'undefined') return;
        if (this._manifestObjectUrl) URL.revokeObjectURL(this._manifestObjectUrl);
        const esc = encodeURIComponent;
        const icon192 = `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 192 192'><rect width='192' height='192' rx='40' fill='${esc(themeColor)}'/><text x='96' y='128' font-size='110' text-anchor='middle' fill='white'>✨</text></svg>`;
        const icon512 = `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><rect width='512' height='512' rx='110' fill='${esc(themeColor)}'/><text x='256' y='340' font-size='280' text-anchor='middle' fill='white'>✨</text></svg>`;
        const manifest = {
            name: appName || 'AstroInsight',
            short_name: appName || 'AstroInsight',
            description: description || '',
            start_url: './',
            scope: './',
            display: 'standalone',
            orientation: 'portrait',
            background_color: '#0f172a',
            theme_color: themeColor || '#7c3aed',
            lang: 'ja',
            icons: [
                { src: icon192, sizes: '192x192', type: 'image/svg+xml', purpose: 'any' },
                { src: icon512, sizes: '512x512', type: 'image/svg+xml', purpose: 'any maskable' }
            ]
        };
        const blob = new Blob([JSON.stringify(manifest)], { type: 'application/manifest+json' });
        this._manifestObjectUrl = URL.createObjectURL(blob);
        link.setAttribute('href', this._manifestObjectUrl);
    }

    renderMarkdown(text) {
        const src = String(text == null ? '' : text);
        if (window.marked && typeof window.marked.parse === 'function') return window.marked.parse(src);
        return this.escapeHtml(src).replace(/\n/g, '<br>');
    }

    escapeHtml(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    showError(message) {
        const msg = String(message || 'エラーが発生しました。');
        if (this.snackbar && typeof this.snackbar.notice === 'function') this.snackbar.notice(msg, 'error');
        else alert(msg);
    }

    showNotice(message) {
        if (this.snackbar && typeof this.snackbar.notice === 'function') this.snackbar.notice(message, 'info');
    }

    _setSplashStatus(text) {
        const el = document.getElementById('splash-status');
        if (el) el.textContent = text;
    }

    async hideSplash() {
        const el = document.getElementById('splash-screen');
        if (!el) return;
        const elapsed = Date.now() - this._bootStartedAt;
        const wait = Math.max(0, this._splashMinMs - elapsed);
        if (wait) await new Promise((r) => setTimeout(r, wait));
        el.classList.add('splash-hide');
        setTimeout(() => el.remove(), 360);
    }

    async _resolveGenerationRoute() {
        const modelId = (await this.db.get('selected_model')) || this.config.defaultModelsConfig?.defaultModelId || 'gemini-2.5-flash';
        const modelMeta = await this.config.getModelById(modelId);
        if (!modelMeta) {
            return { ok: false, message: 'モデルが見つかりません: ' + modelId, modelId };
        }
        const providerId = modelMeta.providerId || modelMeta.provider;
        if (!providerId) {
            return { ok: false, message: 'モデルの providerId が未設定です: ' + modelId, modelId, modelMeta };
        }
        const loggedIn = this.auth.isLoggedIn();
        if (loggedIn && this.proxy.isConfigured() && modelMeta?.proxySupported && !this.proxy.token) {
            await this.proxy.fetchToken(this.auth.currentUid());
        }
        const useProxy = this.proxy.canUseProxy(modelMeta, loggedIn);
        const proxyReq = useProxy ? this.proxy.buildProxyRequest(modelMeta) : null;
        const apiKey = await this.config.getProviderApiKey(providerId);
        if (!useProxy && !apiKey) {
            const provName = this.config.getProviderById(providerId)?.name || providerId;
            return {
                ok: false,
                message: `APIキーが未設定です。設定→AIモデル、または管理者設定→プロバイダーAPIキーで「${provName}」のAPIキーを入力してください。`,
                modelId,
                modelMeta,
                providerId
            };
        }
        return { ok: true, modelId, modelMeta, providerId, apiKey, proxyReq };
    }

    /**
     * 統合: AI生成エントリーポイント（要件§20 ルーティング）
     * 生成前検証 → 試用回数消費 → Worker送信の順に統一する。
     */
    async startGeneration(opts) {
        const { taskId, taskLabel, prompt, isJson } = opts;
        const route = await this._resolveGenerationRoute();
        if (!route.ok) {
            if (typeof opts.onError === 'function') opts.onError(route.message);
            else this.showError(route.message);
            return false;
        }

        const costsTrial = opts.costsTrial !== false;
        if (costsTrial && !await this.auth.consumeTrial()) {
            const max = this.flags.get('guest_trial_max') || 3;
            const msg = `ログインしてください。\n（無料試用は${max}回までです）`;
            if (typeof opts.onError === 'function') opts.onError(msg);
            else this.showError(msg);
            return false;
        }

        this.snackbar.start(taskId, taskLabel || '生成中…');
        this._acquireWakeLock();

        const aiOpts = {
            maxTokens: this.flags.get('ai_max_tokens'),
            temperature: this.flags.get('ai_temperature'),
            topP: this.flags.get('ai_top_p'),
            streaming: this.flags.get('ai_streaming')
        };

        this.workerMgr.submit(taskId, {
            apiKey: route.apiKey,
            model: route.modelId,
            modelMeta: route.modelMeta,
            prompt,
            isJson,
            proxy: route.proxyReq,
            ai: aiOpts
        }, {
            onChunk: (msg) => {
                if (typeof opts.onProgress === 'function') opts.onProgress(msg.text);
                this.snackbar.update(taskId, taskLabel || '生成中…');
            },
            onDone: (msg) => {
                opts.onDone && opts.onDone(msg.text);
                if (this.workerMgr.active.size === 0) this._releaseWakeLock();
            },
            onError: (msg) => {
                const message = msg.message || '生成に失敗しました。';
                opts.onError && opts.onError(message);
                if (this.workerMgr.active.size === 0) this._releaseWakeLock();
            }
        });
        return true;
    }

    async _acquireWakeLock() {
        if (this._wakeLock || !('wakeLock' in navigator)) return;
        try {
            this._wakeLock = await navigator.wakeLock.request('screen');
        } catch (e) {}
    }
    _releaseWakeLock() {
        if (this._wakeLock) {
            try { this._wakeLock.release(); } catch (e) {}
            this._wakeLock = null;
        }
    }

    handleChatSubmit(e) {
        return this.chat.handleSubmit(e);
    }
}

window.addEventListener('DOMContentLoaded', async () => {
    window.app = new AstroApp();
    await window.app.init();
    if ('serviceWorker' in navigator) {
        try { await navigator.serviceWorker.register('./sw.js'); } catch (e) {}
    }
});
