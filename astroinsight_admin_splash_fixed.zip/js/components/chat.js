/* ============================================================
 * AstroInsight - Chat Component（v5）
 * 要件§14：
 *   - AIとの自由チャット、履歴をIndexedDBに永続保存、ストリーミング、Markdown対応。
 *   - 文脈引き継ぎ: 他画面の「AIに質問」から遷移時、その分析結果をシステム文脈として付与。
 *     入力欄上部に「〇〇の分析について質問中」バッジ。✕で文脈クリア。
 * ============================================================ */

class ChatComponent {
    constructor(app) {
        this.app = app;
        this.db = app.db;
        this.context = ''; // 文脈引き継ぎ
    }

    async load() {
        const chats = (await this.db.get('chat_history')) || [];
        const cont = document.getElementById('chat-messages');
        if (!cont) return;
        if (chats.length > 0) {
            cont.innerHTML = '';
            for (const c of chats) this.app.ui.appendChatBubble(c.role, c.text);
            setTimeout(() => (cont.scrollTop = cont.scrollHeight), 100);
        }
        this._renderContextBadge();
    }

    /** 詳細画面から呼ばれる（要件§14） */
    setContext(text) {
        this.context = text || '';
        this._renderContextBadge();
    }

    clearContext() {
        this.context = '';
        this._renderContextBadge();
    }

    _renderContextBadge() {
        const badge = document.getElementById('chat-context-badge');
        if (!badge) return;
        if (this.context) {
            badge.classList.remove('hidden');
            badge.querySelector('span').textContent = `${this.context}を質問中`;
        } else {
            badge.classList.add('hidden');
        }
    }

    async handleSubmit(e) {
        e.preventDefault();
        const input = document.getElementById('chat-input');
        const text = input.value.trim();
        if (!text) return;
        input.value = '';
        await this.add('user', text);
        const profileStr = (await this.app.profile.getProfileString()) || '未設定';
        // ネイタル要約
        const natalCacheKey = `natal_${await this.app.profile.getProfileHash()}`;
        const natalCached = await this.db.cacheGet(natalCacheKey);
        const natalText = natalCached?.text ? natalCached.text.substring(0, 300) : 'なし';
        // 履歴
        const chats = (await this.db.get('chat_history')) || [];
        const hist = chats.slice(-6).map((c) => `${c.role}: ${c.text}`).join('\n');
        const sysPrompt = await this.app.config.getPrompt('prompt_chat');
        const ctxBlock = this.context ? `【現在の質問文脈】${this.context}\n` : '';
        const prompt = `${sysPrompt}\n\nユーザーの質問に答えてください。
【プロフ】${profileStr}
【ネイタル要約】${natalText}
${ctxBlock}【履歴】${hist}
最新の質問: ${text}
回答:`;
        const taskId = `chat-${Date.now()}`;
        // 一旦空のAIバブルを作って、ストリーミングで埋める
        const placeholder = this._appendStreamingBubble();
        await this.app.startGeneration({
            taskId,
            taskLabel: 'チャットを生成中…',
            prompt,
            isJson: false,
            onProgress: (text) => {
                placeholder.innerHTML = this.app.renderMarkdown(text + ' ▍');
                const cont = document.getElementById('chat-messages');
                cont.scrollTop = cont.scrollHeight;
            },
            onDone: async (text) => {
                placeholder.innerHTML = this.app.renderMarkdown(text);
                await this._persist('model', text);
                this.app.snackbar.succeed(taskId, '✓ 回答を生成しました');
            },
            onError: (msg) => {
                placeholder.innerHTML = `<span class="text-red-500 text-sm">エラー: ${msg}</span>`;
                this.app.snackbar.fail(taskId, msg, () => {});
            }
        });
    }

    _appendStreamingBubble() {
        const c = document.getElementById('chat-messages');
        const div = document.createElement('div');
        div.className = 'flex justify-start';
        const b = document.createElement('div');
        b.className = 'px-4 py-3 max-w-[85%] text-sm leading-relaxed chat-ai';
        b.innerHTML = '<i class="fa-solid fa-circle-notch animate-spin text-astro"></i>';
        div.appendChild(b);
        c.appendChild(div);
        c.scrollTop = c.scrollHeight;
        return b;
    }

    async add(role, text) {
        await this._persist(role, text);
        this.app.ui.appendChatBubble(role, text);
    }

    async _persist(role, text) {
        const chats = (await this.db.get('chat_history')) || [];
        chats.push({ role, text, time: Date.now() });
        await this.db.set('chat_history', chats);
    }

    async clearHistory() {
        if (!confirm('チャット履歴を消去しますか？')) return;
        await this.db.set('chat_history', []);
        const cont = document.getElementById('chat-messages');
        cont.innerHTML = `
            <div class="flex justify-start">
                <div class="chat-ai px-4 py-3 max-w-[85%] text-sm leading-relaxed">こんにちは！星のこと、なんでも聞いてください。</div>
            </div>`;
    }
}

window.ChatComponent = ChatComponent;
