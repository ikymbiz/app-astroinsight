/* ============================================================
 * AstroInsight - Natal Analysis Component（v5）
 * 要件§7 §9 §15：
 *   - ネイタル（出生図・本質）の生成。初回はオンボーディング、以降は手動更新。
 *   - キャッシュキー: {uid}_natal_{プロフィールハッシュ}
 * ============================================================ */

class NatalComponent {
    constructor(app) {
        this.app = app;
        this.db = app.db;
    }

    async cacheKey() {
        const h = await this.app.profile.getProfileHash();
        return `natal_${h}`;
    }

    async load() {
        const k = await this.cacheKey();
        const cached = await this.db.cacheGet(k);
        if (cached) this._render(cached.text);
    }

    /** ネイタル分析を生成（要件§7） */
    async generate(opts = {}) {
        const p = await this.app.profile.getProfileString();
        if (!p) return alert('プロフィールを設定してください。');
        const sysPrompt = await this.app.config.getPrompt('prompt_natal');
        const prompt = `${sysPrompt}\n\n以下のプロフィールから、ネイタルチャート（出生図）に基づく本質的な性格・人生の傾向の分析を行ってください。\n専門用語は避けつつ、絵文字を交えて読みやすく表現してください。\nプロフィール: ${p}`;
        const k = await this.cacheKey();
        await this.app.startGeneration({
            taskId: 'natal',
            taskLabel: 'ネイタル分析を生成中…',
            prompt,
            isJson: false,
            onProgress: (text) => this._render(text + ' ▍'),
            onDone: async (text) => {
                await this.db.cacheSet(k, { text, ts: Date.now() });
                this._render(text);
                if (typeof opts.onComplete === 'function') opts.onComplete(text);
            },
            onError: (msg) => {
                if (typeof opts.onError === 'function') opts.onError(msg);
                else this.app.snackbar.fail('natal', msg, () => this.generate());
            }
        });
    }

    _render(text) {
        const el = document.getElementById('natal-result');
        if (!el) return;
        el.innerHTML = this.app.renderMarkdown(text || '');
        // オンボーディングのプログレス表示
        const onbProg = document.getElementById('onb-natal-result');
        if (onbProg) onbProg.innerHTML = this.app.renderMarkdown(text || '');
    }
}

window.NatalComponent = NatalComponent;
