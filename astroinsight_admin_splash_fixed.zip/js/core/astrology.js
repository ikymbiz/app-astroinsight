/* ============================================================
 * AstroInsight - Astrology Compute（v5）
 * 要件§8 を実装する：
 *   - astronomy-engine（CDN）で天体黄経を計算。
 *   - ハウス計算は ASC 起点の Equal House 簡易実装。
 *   - 計算する天体: 太陽・月・水星・金星・火星・木星・土星・天王星・海王星・冥王星 + ASC・MC。
 *   - サイン（12星座）・ハウス（1〜12）・アスペクト（合0/対180/トライン120/スクエア90/セクスタイル60）。
 *
 * 注：astronomy-engine が CDN で読み込まれていること前提。
 *     （index.html で <script src="https://cdn.jsdelivr.net/npm/astronomy-engine">）
 * ============================================================ */

const PLANETS = [
    { key: 'Sun',     ja: '太陽',   en: 'Sun',     symbol: '☉', meaning: '本質・自我・人生の方向性' },
    { key: 'Moon',    ja: '月',     en: 'Moon',    symbol: '☽', meaning: '感情・無意識・幼少期の傾向' },
    { key: 'Mercury', ja: '水星',   en: 'Mercury', symbol: '☿', meaning: '思考・コミュニケーション' },
    { key: 'Venus',   ja: '金星',   en: 'Venus',   symbol: '♀', meaning: '愛・美・喜び' },
    { key: 'Mars',    ja: '火星',   en: 'Mars',    symbol: '♂', meaning: '行動・闘争・情熱' },
    { key: 'Jupiter', ja: '木星',   en: 'Jupiter', symbol: '♃', meaning: '拡大・幸運・成長' },
    { key: 'Saturn',  ja: '土星',   en: 'Saturn',  symbol: '♄', meaning: '試練・責任・構造' },
    { key: 'Uranus',  ja: '天王星', en: 'Uranus',  symbol: '♅', meaning: '革新・自由・突発' },
    { key: 'Neptune', ja: '海王星', en: 'Neptune', symbol: '♆', meaning: '夢・霊性・幻想' },
    { key: 'Pluto',   ja: '冥王星', en: 'Pluto',   symbol: '♇', meaning: '変容・破壊と再生・運命的転機' }
];
const SIGNS = ['牡羊座', '牡牛座', '双子座', '蟹座', '獅子座', '乙女座', '天秤座', '蠍座', '射手座', '山羊座', '水瓶座', '魚座'];
const SIGN_SYMBOLS = ['♈', '♉', '♊', '♋', '♌', '♍', '♎', '♏', '♐', '♑', '♒', '♓'];
const ASPECTS = [
    { name: '合', en: 'conjunction', angle: 0,   orb: 8, color: '#f59e0b' },
    { name: '対', en: 'opposition',  angle: 180, orb: 8, color: '#ef4444' },
    { name: 'トライン', en: 'trine', angle: 120, orb: 6, color: '#10b981' },
    { name: 'スクエア', en: 'square', angle: 90, orb: 6, color: '#dc2626' },
    { name: 'セクスタイル', en: 'sextile', angle: 60, orb: 4, color: '#3b82f6' }
];
// 12ハウスの意味（要件§13・詳細画面のハウス分布表示で利用）
const HOUSE_MEANINGS = {
    1:  '自分自身・印象・始まり',
    2:  'お金・価値観・才能',
    3:  '会話・学び・連絡',
    4:  '家・安心・土台',
    5:  '恋愛・表現・楽しみ',
    6:  '仕事習慣・健康・日課',
    7:  '対人関係・パートナー',
    8:  '深い関係・共有・変容',
    9:  '学び・旅・視野拡大',
    10: '仕事・社会的役割・評価',
    11: '仲間・未来・コミュニティ',
    12: '内省・癒し・手放し'
};

class AstrologyCompute {
    static planets() { return PLANETS; }
    static signs()   { return SIGNS; }
    static signSymbols() { return SIGN_SYMBOLS; }
    static aspects() { return ASPECTS; }
    static houseMeanings() { return HOUSE_MEANINGS; }
    static houseMeaning(n) { return HOUSE_MEANINGS[n] || ''; }

    /** 黄経からサイン番号(0-11)と度数(0-29.9999) */
    static signFromLongitude(lon) {
        const norm = ((lon % 360) + 360) % 360;
        const idx = Math.floor(norm / 30);
        const deg = norm - idx * 30;
        return { signIndex: idx, signName: SIGNS[idx], degInSign: deg, longitude: norm };
    }

    /**
     * astronomy-engine を使った黄経計算。
     * @param {Date} date - UT
     * @returns {Object} { Sun: 黄経, Moon: ..., ... }
     */
    static computePlanetLongitudes(date) {
        if (typeof Astronomy === 'undefined') {
            return this._fallbackLongitudes(date);
        }
        const time = Astronomy.MakeTime(date);
        const result = {};
        for (const p of PLANETS) {
            try {
                let lon;
                if (p.key === 'Moon') {
                    const ec = Astronomy.EclipticGeoMoon(time);
                    lon = ec.lon;
                } else if (p.key === 'Sun') {
                    const ec = Astronomy.SunPosition(time);
                    lon = ec.elon;
                } else {
                    const v = Astronomy.GeoVector(Astronomy.Body[p.key], time, true);
                    const ec = Astronomy.Ecliptic(v);
                    lon = ec.elon;
                }
                result[p.key] = ((lon % 360) + 360) % 360;
            } catch (e) {
                result[p.key] = 0;
            }
        }
        return result;
    }

    /** astronomy-engine が無い時のフォールバック（おおまかな概算、表示優先） */
    static _fallbackLongitudes(date) {
        // ユリウス通日からの経過日数で 1日=1°程度の概算（精度は出ないが表示は崩れない）
        const t = (date.getTime() - Date.UTC(2000, 0, 1)) / 86400000;
        const r = {};
        const speeds = { Sun: 0.985, Moon: 13.176, Mercury: 1.4, Venus: 1.2, Mars: 0.524,
            Jupiter: 0.083, Saturn: 0.034, Uranus: 0.012, Neptune: 0.006, Pluto: 0.004 };
        for (const p of PLANETS) {
            r[p.key] = (((speeds[p.key] || 1) * t) % 360 + 360) % 360;
        }
        return r;
    }

    /**
     * ハウスカスプ計算（ASC起点のEqual House簡易実装）。
     * @param {Date} date - UT
     * @param {number} lat - 緯度（度）
     * @param {number} lon - 経度（度、東経+）
     * @returns {Object} { ASC, MC, cusps:[12], obliquity }
     */
    static computeHouses(date, lat, lon) {
        const ε = 23.4393 * Math.PI / 180; // 黄道傾斜（簡略）
        const φ = lat * Math.PI / 180;

        // GMST → LST → RAMC
        const jd = (date.getTime() / 86400000) + 2440587.5;
        const T = (jd - 2451545.0) / 36525;
        let gmst = 280.46061837 + 360.98564736629 * (jd - 2451545.0)
                 + 0.000387933 * T * T - (T * T * T) / 38710000;
        gmst = ((gmst % 360) + 360) % 360;
        const lst = (gmst + lon) % 360;
        const ramc = lst * Math.PI / 180;

        // MC（中天黄経）
        const mc = Math.atan2(Math.sin(ramc), Math.cos(ramc) * Math.cos(ε));
        let mcLon = mc * 180 / Math.PI;
        mcLon = ((mcLon % 360) + 360) % 360;

        // ASC（上昇宮黄経）
        const ascArg = -Math.cos(ramc);
        const ascDen = Math.sin(ε) * Math.tan(φ) + Math.cos(ε) * Math.sin(ramc);
        let ascLon = Math.atan2(ascArg, ascDen) * 180 / Math.PI;
        ascLon = ((ascLon % 360) + 360) % 360;

        // 12ハウスは ASC を起点に等分（Equal House）。
        // README/画面説明も Equal House 表記に統一する。
        const cusps = [];
        for (let i = 0; i < 12; i++) {
            cusps.push((ascLon + 30 * i) % 360);
        }
        return { ASC: ascLon, MC: mcLon, cusps, obliquity: ε * 180 / Math.PI };
    }

    /**
     * 天体黄経からハウス番号(1-12)を判定
     * @param {number} lon
     * @param {number[]} cusps - cusps[0]=1H, cusps[1]=2H, ...
     */
    static houseOf(lon, cusps) {
        const norm = ((lon % 360) + 360) % 360;
        for (let i = 0; i < 12; i++) {
            const a = cusps[i];
            const b = cusps[(i + 1) % 12];
            const inHouse = (a <= b)
                ? (norm >= a && norm < b)
                : (norm >= a || norm < b);
            if (inHouse) return i + 1;
        }
        return 1;
    }

    /**
     * 主要アスペクトの検出
     * @param {Object} pos1 - { Sun:°, Moon:°, ... }
     * @param {Object} pos2 - 二重円の場合は別人/トランジット
     * @param {boolean} isSelfChart - 単独図ならtrue（同一天体ペアは除外）
     */
    static detectAspects(pos1, pos2, isSelfChart = false) {
        const out = [];
        const keys1 = Object.keys(pos1);
        const keys2 = Object.keys(pos2);
        for (let i = 0; i < keys1.length; i++) {
            for (let j = (isSelfChart ? i + 1 : 0); j < keys2.length; j++) {
                if (isSelfChart && keys1[i] === keys2[j]) continue;
                const a = pos1[keys1[i]];
                const b = pos2[keys2[j]];
                let diff = Math.abs(a - b);
                if (diff > 180) diff = 360 - diff;
                for (const asp of ASPECTS) {
                    if (Math.abs(diff - asp.angle) <= asp.orb) {
                        out.push({
                            p1: keys1[i],
                            p2: keys2[j],
                            aspect: asp.name,
                            aspectEn: asp.en,
                            angle: asp.angle,
                            orb: Math.abs(diff - asp.angle).toFixed(2),
                            color: asp.color
                        });
                    }
                }
            }
        }
        return out;
    }

    /** 出生地 → 緯度経度（簡易ジオコーダはなし。手入力 or 0,0 fallback） */
    static guessLatLon(placeText) {
        // 主要都市の簡易テーブル（要件§8 ハウス計算には緯度経度が必須）
        const map = {
            '東京': [35.6895, 139.6917], 'Tokyo': [35.6895, 139.6917],
            '大阪': [34.6937, 135.5023], '京都': [35.0116, 135.7681],
            '横浜': [35.4437, 139.6380], '名古屋': [35.1815, 136.9066],
            '福岡': [33.5904, 130.4017], '札幌': [43.0618, 141.3545],
            '仙台': [38.2682, 140.8694], '広島': [34.3853, 132.4553],
            '神戸': [34.6901, 135.1955], '那覇': [26.2124, 127.6809],
            'さいたま': [35.8617, 139.6455], '千葉': [35.6074, 140.1065],
            '金沢': [36.5613, 136.6562], '新潟': [37.9161, 139.0364],
            '静岡': [34.9756, 138.3828], '岡山': [34.6551, 133.9195],
            '松山': [33.8392, 132.7657], '熊本': [32.8031, 130.7079],
            '鹿児島': [31.5966, 130.5571],
            'New York': [40.7128, -74.0060], 'London': [51.5074, -0.1278],
            'Paris': [48.8566, 2.3522], 'Seoul': [37.5665, 126.9780],
            'Taipei': [25.0330, 121.5654], 'Singapore': [1.3521, 103.8198]
        };
        if (!placeText) return [35.6895, 139.6917]; // 未入力時のみ東京を既定値にする
        const raw = String(placeText).trim();
        const m = raw.match(/(-?\d+(?:\.\d+)?)\s*[,，]\s*(-?\d+(?:\.\d+)?)/);
        if (m) return [parseFloat(m[1]), parseFloat(m[2])];
        for (const k of Object.keys(map)) {
            if (raw.includes(k)) return map[k];
        }
        return [0, 0]; // 未対応地名を東京扱いにしない
    }

    /**
     * プロフィールからフルチャート計算。
     * @param {Object} profile - { name, date, time, place }
     * @param {Date|null} when - null ならネイタル(profile.date+time), Dateならトランジット
     */
    static computeChart(profile, when = null) {
        // 出生日時 → Date
        const birthDate = profile.date || '2000-01-01';
        const birthTime = profile.time || '12:00';
        const target = when || new Date(`${birthDate}T${birthTime}:00`);
        const [lat, lng] = this.guessLatLon(profile.place);
        const longs = this.computePlanetLongitudes(target);
        const houses = this.computeHouses(target, lat, lng);
        // 各天体に サイン・ハウスを付与
        const planets = {};
        for (const p of PLANETS) {
            const lon = longs[p.key];
            const sg = this.signFromLongitude(lon);
            planets[p.key] = {
                ...p,
                longitude: lon,
                signIndex: sg.signIndex,
                signName: sg.signName,
                degInSign: sg.degInSign,
                house: this.houseOf(lon, houses.cusps)
            };
        }
        return {
            target,
            lat, lng,
            planets,
            ASC: houses.ASC,
            MC: houses.MC,
            cusps: houses.cusps
        };
    }
}

window.AstrologyCompute = AstrologyCompute;
