/* ============================================================
 * AstroInsight - IndexedDB Wrapper（v5）
 * 要件§19「全てのIndexedDB操作はラッパー関数経由に統一」、
 * 要件§2「IndexedDBキープレフィックス: 未ログイン guest_temp / ログイン {uid}」、
 * 要件§13「友達は複数人分を管理」を満たす。
 * 将来Firestore移行時はこのクラスのみ差し替えれば良い。
 * ============================================================ */

class AstroDB {
    constructor(dbName = 'AstroInsightDB', dbVersion = 2) {
        this.dbName = dbName;
        this.dbVersion = dbVersion;
        this.db = null;
        // 現在のキープレフィックス（'guest_temp' or '{uid}'）。AuthService から setUidPrefix() で切替。
        this.uidPrefix = 'guest_temp';
    }

    init() {
        return new Promise((resolve, reject) => {
            const req = indexedDB.open(this.dbName, this.dbVersion);
            req.onupgradeneeded = (e) => {
                const db = e.target.result;
                // 既存：汎用ストア
                if (!db.objectStoreNames.contains('store')) db.createObjectStore('store');
                if (!db.objectStoreNames.contains('backups')) db.createObjectStore('backups');
                // 追加：キャッシュ・フレンド・ファクト（要件§13 §19）
                if (!db.objectStoreNames.contains('cache')) db.createObjectStore('cache');
                if (!db.objectStoreNames.contains('friends')) db.createObjectStore('friends');
                // 認証関連（プレフィックス非適用のグローバル領域）
                if (!db.objectStoreNames.contains('auth')) db.createObjectStore('auth');
            };
            req.onsuccess = (e) => {
                this.db = e.target.result;
                resolve();
            };
            req.onerror = (e) => reject(e.target.error);
        });
    }

    /** Authサービスから呼ばれてプレフィックス切替（要件§2） */
    setUidPrefix(prefix) {
        this.uidPrefix = prefix || 'guest_temp';
    }
    getUidPrefix() {
        return this.uidPrefix;
    }
    /** UIDプレフィックスを付与したキー */
    _k(key) {
        return `${this.uidPrefix}::${key}`;
    }

    // -------- 汎用 store ストア（プレフィックス付与あり） --------
    async get(key) {
        if (!this.db) await this.init();
        return new Promise((res) => {
            const req = this.db.transaction('store').objectStore('store').get(this._k(key));
            req.onsuccess = () => res(req.result);
            req.onerror = () => res(null);
        });
    }
    async set(key, value) {
        if (!this.db) await this.init();
        return new Promise((res, rej) => {
            const tx = this.db.transaction('store', 'readwrite');
            tx.objectStore('store').put(value, this._k(key));
            tx.oncomplete = () => res();
            tx.onerror = (e) => rej(e.target.error);
        });
    }
    async delete(key) {
        if (!this.db) await this.init();
        return new Promise((res, rej) => {
            const tx = this.db.transaction('store', 'readwrite');
            tx.objectStore('store').delete(this._k(key));
            tx.oncomplete = () => res();
            tx.onerror = (e) => rej(e.target.error);
        });
    }

    // -------- グローバル領域（auth/設定など、プレフィックスを付与しない） --------
    async getRaw(store, key) {
        if (!this.db) await this.init();
        return new Promise((res) => {
            const req = this.db.transaction(store).objectStore(store).get(key);
            req.onsuccess = () => res(req.result);
            req.onerror = () => res(null);
        });
    }
    async setRaw(store, key, value) {
        if (!this.db) await this.init();
        return new Promise((res, rej) => {
            const tx = this.db.transaction(store, 'readwrite');
            tx.objectStore(store).put(value, key);
            tx.oncomplete = () => res();
            tx.onerror = (e) => rej(e.target.error);
        });
    }
    async deleteRaw(store, key) {
        if (!this.db) await this.init();
        return new Promise((res, rej) => {
            const tx = this.db.transaction(store, 'readwrite');
            tx.objectStore(store).delete(key);
            tx.oncomplete = () => res();
            tx.onerror = (e) => rej(e.target.error);
        });
    }

    // -------- friends ストア（要件§13 友達は複数人を一覧管理） --------
    /** uidプレフィックス + friendId をキーとする */
    async friendPut(friendId, data) {
        return this.setRaw('friends', `${this.uidPrefix}::${friendId}`, data);
    }
    async friendGet(friendId) {
        return this.getRaw('friends', `${this.uidPrefix}::${friendId}`);
    }
    async friendDelete(friendId) {
        return this.deleteRaw('friends', `${this.uidPrefix}::${friendId}`);
    }
    async friendList() {
        if (!this.db) await this.init();
        return new Promise((res) => {
            const out = [];
            const tx = this.db.transaction('friends');
            const store = tx.objectStore('friends');
            const req = store.openCursor();
            req.onsuccess = (e) => {
                const cur = e.target.result;
                if (cur) {
                    if (typeof cur.key === 'string' && cur.key.startsWith(`${this.uidPrefix}::`)) {
                        out.push(cur.value);
                    }
                    cur.continue();
                } else {
                    res(out);
                }
            };
            req.onerror = () => res([]);
        });
    }

    // -------- cacheストア（要件§19 キャッシュキーは {uid}_* プレフィックス） --------
    async cacheGet(key) {
        return this.getRaw('cache', `${this.uidPrefix}::${key}`);
    }
    async cacheSet(key, value) {
        return this.setRaw('cache', `${this.uidPrefix}::${key}`, value);
    }
    async cacheDelete(key) {
        return this.deleteRaw('cache', `${this.uidPrefix}::${key}`);
    }
    /** 現UIDプレフィックスのキャッシュをまとめて消す */
    async cacheClearForUid() {
        if (!this.db) await this.init();
        return new Promise((res) => {
            const tx = this.db.transaction('cache', 'readwrite');
            const store = tx.objectStore('cache');
            const req = store.openCursor();
            req.onsuccess = (e) => {
                const cur = e.target.result;
                if (cur) {
                    if (typeof cur.key === 'string' && cur.key.startsWith(`${this.uidPrefix}::`)) {
                        cur.delete();
                    }
                    cur.continue();
                } else {
                    res();
                }
            };
            req.onerror = () => res();
        });
    }

    // -------- guest_temp 領域だけクリア（要件§2 起動時） --------
    async clearGuestTemp() {
        if (!this.db) await this.init();
        const stores = ['store', 'cache', 'friends'];
        return new Promise((res) => {
            const tx = this.db.transaction(stores, 'readwrite');
            stores.forEach((s) => {
                const o = tx.objectStore(s);
                const req = o.openCursor();
                req.onsuccess = (e) => {
                    const cur = e.target.result;
                    if (cur) {
                        if (typeof cur.key === 'string' && cur.key.startsWith('guest_temp::')) {
                            cur.delete();
                        }
                        cur.continue();
                    }
                };
            });
            tx.oncomplete = () => res();
            tx.onerror = () => res();
        });
    }

    /** 全消去（要件§15データ管理） */
    async clearAll() {
        if (!this.db) await this.init();
        const stores = ['store', 'backups', 'cache', 'friends', 'auth'];
        return new Promise((res, rej) => {
            const tx = this.db.transaction(stores, 'readwrite');
            stores.forEach((s) => tx.objectStore(s).clear());
            tx.oncomplete = () => res();
            tx.onerror = (e) => rej(e.target.error);
        });
    }
}

window.AstroDB = AstroDB;
