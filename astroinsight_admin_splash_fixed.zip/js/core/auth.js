/* ============================================================
 * AstroInsight - Auth Service（v9 / GIS のみ）
 * 要件§2 を実装する：
 *   - 未ログイン状態でもアプリは即起動。ログイン画面は出さない。
 *   - 未ログイン: AI生成は累計3回まで。3回超過後は「ログインしてください」。
 *   - Google Identity Services (GIS) で直接ログイン → ID Token (JWT) を取得し
 *     payload から uid(sub)/name/email/picture を読み取る。
 *   - 管理者: app-config.auth.adminEmails に email が含まれていれば admin。
 *   - ログアウト: ゲスト状態に戻る（端末DBは残る）。
 *
 * 認証プロバイダ: Google Identity Services (GIS) 一択。
 * googleClientId が未設定の場合はゲストモード（3回試用）のみで動作する。
 * ============================================================ */

class AuthService {
    /**
     * @param {AstroDB} db
     * @param {ConfigLoader} [config] - app-config.auth.googleClientId / adminEmails を参照
     */
    constructor(db, config = null) {
        this.db = db;
        this.config = config; // app.init で代入される（init より前に new されるため後注入）
        this.user = null;
        this._listeners = [];
        this._gisReady = false;
        this._gisClientId = '';
        this._adminEmails = [];
    }

    /** AstroApp から ConfigLoader を後注入する */
    setConfig(config) { this.config = config; }

    /** アプリ起動時に呼ぶ */
    async init() {
        // 起動ごとに guest_temp を消すと初回プロフィール・オンボーディング状態が失われるため、
        // guest_temp の清掃はログイン移行完了時だけ行う。
        // 旧バージョンで保存された firebase_config を清掃（このアプリは GIS のみ）
        try { await this.db.deleteRaw('auth', 'firebase_config'); } catch (e) {}

        // app-config.auth から GIS 設定を読む（管理者上書きあれば優先）
        const ac = this.config?.getAppConfig?.() || {};
        const adminGoogleClientId = await this.db.getRaw('auth', 'google_client_id');
        const adminAdminEmails = await this.db.getRaw('auth', 'admin_emails');
        this._gisClientId = adminGoogleClientId || ac.auth?.googleClientId || '';
        this._adminEmails = (adminAdminEmails || ac.auth?.adminEmails || [])
            .filter(Boolean).map((e) => String(e).trim().toLowerCase());

        // GIS 初期化（Client ID があれば）
        if (this._gisClientId) {
            await this._tryInitGIS(this._gisClientId).catch((e) => console.warn('[Auth] GIS init failed:', e));
        }

        // 直前のセッションがあれば復元。期限切れ・改ざん疑いの値は破棄する。
        const cached = await this.db.getRaw('auth', 'cached_user');
        if (cached && cached.uid && cached.expiresAt && cached.expiresAt > Date.now()) {
            if (cached.email && this._adminEmails.length) {
                cached.isAdmin = this._adminEmails.includes(String(cached.email).toLowerCase());
            } else {
                cached.isAdmin = false;
            }
            this.user = cached;
            this.db.setUidPrefix(cached.uid);
        } else {
            if (cached) await this.db.deleteRaw('auth', 'cached_user');
            this.db.setUidPrefix('guest_temp');
        }
        this._notify();
    }

    // ==========================================================
    // Google Identity Services (GIS) 経路
    // ==========================================================

    /** GIS スクリプトをロード＋initialize */
    async _tryInitGIS(clientId) {
        await this._loadScript('https://accounts.google.com/gsi/client');
        if (!window.google || !window.google.accounts || !window.google.accounts.id) {
            throw new Error('GIS スクリプトのロードに失敗');
        }
        window.google.accounts.id.initialize({
            client_id: clientId,
            callback: (resp) => this._handleGoogleCredential(resp),
            auto_select: false,
            cancel_on_tap_outside: true,
            ux_mode: 'popup',
            use_fedcm_for_prompt: true
        });
        this._gisReady = true;
    }

    _loadScript(src) {
        return new Promise((res, rej) => {
            if (document.querySelector(`script[src="${src}"]`)) return res();
            const s = document.createElement('script');
            s.src = src;
            s.async = true;
            s.defer = true;
            s.onload = () => res();
            s.onerror = (e) => rej(e);
            document.head.appendChild(s);
        });
    }

    /** GIS から credential (JWT) を受け取り、ユーザーを確定する */
    async _handleGoogleCredential(resp) {
        if (!resp || !resp.credential) return;
        const payload = this._decodeJwt(resp.credential);
        if (!payload || !payload.sub) {
            console.error('[Auth] JWTのデコードに失敗');
            return;
        }
        const email = (payload.email || '').toLowerCase();
        const isAdmin = this._adminEmails.length ? this._adminEmails.includes(email) : false;
        this.user = {
            uid: payload.sub,
            name: payload.name || payload.email || '',
            email: payload.email || '',
            photoURL: payload.picture || '',
            isAdmin,
            iss: 'gis',
            expiresAt: payload.exp ? payload.exp * 1000 : Date.now() + 60 * 60 * 1000
        };
        this.db.setUidPrefix(payload.sub);
        await this.db.setRaw('auth', 'cached_user', this.user);
        if (window.app?.proxy?.fetchToken) {
            try { await window.app.proxy.fetchToken(payload.sub); } catch (e) {}
        }
        this._notify();
    }

    /** JWT (header.payload.signature) の payload を base64url デコード */
    _decodeJwt(token) {
        try {
            const parts = token.split('.');
            if (parts.length !== 3) return null;
            const b64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
            const padded = b64 + '==='.slice((b64.length + 3) % 4);
            const json = decodeURIComponent(atob(padded).split('').map((c) =>
                '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2)
            ).join(''));
            return JSON.parse(json);
        } catch (e) {
            console.error('[Auth] JWT decode failed:', e);
            return null;
        }
    }

    /** GIS のレンダードボタンを指定要素に描画（推奨UX） */
    renderGoogleButton(elementId, opts = {}) {
        if (!this._gisReady) return false;
        const el = document.getElementById(elementId);
        if (!el || !window.google?.accounts?.id) return false;
        el.innerHTML = '';
        try {
            window.google.accounts.id.renderButton(el, Object.assign({
                type: 'standard',
                theme: 'outline',
                size: 'large',
                text: 'signin_with',
                shape: 'pill',
                logo_alignment: 'left',
                width: 280,
                locale: 'ja'
            }, opts));
            return true;
        } catch (e) {
            console.error('[Auth] renderButton failed:', e);
            return false;
        }
    }

    /** One Tap 表示（任意） */
    promptOneTap() {
        if (!this._gisReady) return;
        try { window.google.accounts.id.prompt(); } catch (e) {}
    }

    // ==========================================================
    // 公開 API
    // ==========================================================

    /** Googleログイン（GISボタンを描画 + One Tap も試行） */
    async signInGoogle() {
        if (this._gisReady) {
            const renderOk = this.renderGoogleButton('g_id_signin_btn');
            if (renderOk) {
                try { window.google.accounts.id.prompt(); } catch (e) {}
                return;
            }
            this.promptOneTap();
            return;
        }
        alert('Google認証が未設定です。\n管理者設定からGoogle Client IDを入力してください。');
    }

    async signOut() {
        if (this._gisReady && window.google?.accounts?.id) {
            try { window.google.accounts.id.disableAutoSelect(); } catch (e) {}
        }
        this.user = null;
        await this.db.deleteRaw('auth', 'cached_user');
        if (window.app?.proxy?.clearToken) await window.app.proxy.clearToken();
        this.db.setUidPrefix('guest_temp');
        this._notify();
    }

    isLoggedIn() { return !!this.user; }
    isAdmin() { return !!this.user?.isAdmin; }
    hasConfiguredAdmins() { return Array.isArray(this._adminEmails) && this._adminEmails.length > 0; }
    currentUid() { return this.user?.uid || null; }

    /** GIS 設定が完了しているか（UI判定用） */
    isGISReady() { return this._gisReady; }

    /** 状態変化リスナー */
    onChange(fn) { this._listeners.push(fn); }
    _notify() {
        for (const fn of this._listeners) {
            try { fn(this.user); } catch (e) {}
        }
    }

    // ---- 試用回数管理（要件§2 ゲストは累計3回まで） ----

    async remainingTrials() {
        if (this.isLoggedIn()) return Infinity;
        const used = (await this.db.getRaw('auth', 'guest_trial_used')) || 0;
        const max = (await this.db.getRaw('auth', 'guest_trial_max')) || 3;
        return Math.max(0, max - used);
    }

    async consumeTrial() {
        if (this.isLoggedIn()) return true;
        const used = (await this.db.getRaw('auth', 'guest_trial_used')) || 0;
        const max = (await this.db.getRaw('auth', 'guest_trial_max')) || 3;
        if (used >= max) return false;
        await this.db.setRaw('auth', 'guest_trial_used', used + 1);
        return true;
    }

    async resetTrial() {
        await this.db.setRaw('auth', 'guest_trial_used', 0);
    }

    /** ゲスト→ログイン移行時、guest_temp のデータを uid 領域へコピー */
    async migrateGuestData() {
        if (!this.isLoggedIn()) return;
        const uid = this.currentUid();
        await this._copyByPrefix('store', 'guest_temp::', `${uid}::`);
        await this._copyByPrefix('cache', 'guest_temp::', `${uid}::`);
        await this._copyByPrefix('friends', 'guest_temp::', `${uid}::`);
        await this.db.clearGuestTemp();
    }

    async _copyByPrefix(storeName, fromPrefix, toPrefix) {
        if (!this.db.db) await this.db.init();
        return new Promise((res) => {
            const tx = this.db.db.transaction(storeName, 'readwrite');
            const o = tx.objectStore(storeName);
            const req = o.openCursor();
            req.onsuccess = (e) => {
                const cur = e.target.result;
                if (cur) {
                    if (typeof cur.key === 'string' && cur.key.startsWith(fromPrefix)) {
                        const newKey = toPrefix + cur.key.substring(fromPrefix.length);
                        o.put(cur.value, newKey);
                    }
                    cur.continue();
                }
            };
            tx.oncomplete = () => res();
            tx.onerror = () => res();
        });
    }

    /** 管理画面から Client ID / 管理者メール一覧を更新 */
    async updateGoogleAuthSettings({ clientId, adminEmails }) {
        if (clientId !== undefined) {
            await this.db.setRaw('auth', 'google_client_id', clientId);
            this._gisClientId = clientId;
            this._gisReady = false;
            if (clientId) {
                try { await this._tryInitGIS(clientId); } catch (e) { console.warn('[Auth] GIS re-init failed:', e); }
            }
        }
        if (adminEmails !== undefined) {
            const arr = Array.isArray(adminEmails) ? adminEmails : String(adminEmails).split(/[,\n]/);
            const cleaned = arr.map((e) => String(e).trim().toLowerCase()).filter(Boolean);
            await this.db.setRaw('auth', 'admin_emails', cleaned);
            this._adminEmails = cleaned;
            // 現セッションの admin 判定を即時更新
            if (this.user && this.user.email) {
                this.user.isAdmin = cleaned.includes(this.user.email.toLowerCase());
                await this.db.setRaw('auth', 'cached_user', this.user);
                this._notify();
            }
        }
    }
}

window.AuthService = AuthService;
