/* ============================================================
 * AstroInsight - Snackbar / Task Toast（v9）
 * 要件§17：バックグラウンドタスクの開始/成功/失敗/リトライ表示。
 * ============================================================ */

class Snackbar {
    constructor() {
        this.tasks = new Map();
        this.container = null;
        this._ensure();
    }

    _ensure() {
        if (this.container) return;
        this.container = document.createElement('div');
        this.container.id = 'snackbar-container';
        this.container.className = 'fixed left-0 right-0 bottom-20 z-[90] px-4 space-y-2 pointer-events-none';
        document.body.appendChild(this.container);
    }

    start(taskId, label) {
        this._ensure();
        const existing = this.tasks.get(taskId);
        if (existing) existing.el.remove();
        const el = document.createElement('div');
        el.className = 'pointer-events-auto bg-white border border-slate-200 shadow-lg rounded-2xl px-4 py-3 flex items-center gap-3 text-sm';
        el.innerHTML = `
            <div class="dot-flashing"></div>
            <div class="flex-1 text-slate-700">${this._esc(label || '処理中…')}</div>
        `;
        this.container.appendChild(el);
        this.tasks.set(taskId, { el, label });
    }

    update(taskId, label) {
        const t = this.tasks.get(taskId);
        if (!t) return;
        t.label = label;
        const text = t.el.querySelector('.flex-1');
        if (text) text.textContent = label;
    }

    succeed(taskId, message) {
        const t = this.tasks.get(taskId);
        if (!t) return this.notice(message || '完了しました。', 'success');
        t.el.innerHTML = `
            <i class="fa-solid fa-circle-check text-emerald-500 text-lg"></i>
            <div class="flex-1 text-slate-700">${this._esc(message || '完了しました。')}</div>
        `;
        setTimeout(() => this._remove(taskId), 2500);
    }

    fail(taskId, message, retryFn) {
        const t = this.tasks.get(taskId);
        if (!t) return this.notice(message || 'エラーが発生しました。', 'error', retryFn);
        t.el.className = 'pointer-events-auto bg-white border border-red-200 shadow-lg rounded-2xl px-4 py-3 flex items-center gap-3 text-sm';
        t.el.innerHTML = `
            <i class="fa-solid fa-triangle-exclamation text-red-500 text-lg"></i>
            <div class="flex-1 text-red-700 whitespace-pre-line">${this._esc(message || 'エラーが発生しました。')}</div>
            ${retryFn ? '<button class="retry bg-red-50 text-red-700 px-2 py-1 rounded-lg text-xs font-bold">再試行</button>' : ''}
        `;
        const btn = t.el.querySelector('.retry');
        if (btn) btn.addEventListener('click', () => {
            this._remove(taskId);
            retryFn();
        });
        if (!retryFn) setTimeout(() => this._remove(taskId), 5000);
    }

    notice(message, type = 'info', retryFn = null) {
        this._ensure();
        const id = 'notice-' + Date.now() + '-' + Math.random().toString(36).slice(2);
        const el = document.createElement('div');
        const isError = type === 'error';
        const isSuccess = type === 'success';
        const icon = isError ? 'fa-triangle-exclamation text-red-500' : isSuccess ? 'fa-circle-check text-emerald-500' : 'fa-circle-info text-astro';
        el.className = `pointer-events-auto bg-white border ${isError ? 'border-red-200' : isSuccess ? 'border-emerald-200' : 'border-slate-200'} shadow-lg rounded-2xl px-4 py-3 flex items-center gap-3 text-sm`;
        el.innerHTML = `
            <i class="fa-solid ${icon} text-lg"></i>
            <div class="flex-1 ${isError ? 'text-red-700' : 'text-slate-700'} whitespace-pre-line">${this._esc(message || '')}</div>
            ${retryFn ? '<button class="retry bg-red-50 text-red-700 px-2 py-1 rounded-lg text-xs font-bold">再試行</button>' : ''}
        `;
        this.container.appendChild(el);
        this.tasks.set(id, { el, label: message });
        const btn = el.querySelector('.retry');
        if (btn) btn.addEventListener('click', () => {
            this._remove(id);
            retryFn();
        });
        if (!retryFn) setTimeout(() => this._remove(id), isError ? 6500 : 3500);
        return id;
    }

    _remove(taskId) {
        const t = this.tasks.get(taskId);
        if (!t) return;
        t.el.style.opacity = '0';
        t.el.style.transform = 'translateY(8px)';
        t.el.style.transition = 'all 200ms ease';
        setTimeout(() => t.el.remove(), 220);
        this.tasks.delete(taskId);
    }

    _esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }
}

window.Snackbar = Snackbar;
