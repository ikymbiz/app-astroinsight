/* ============================================================
 * AstroInsight - Proxy Service（v9）
 * 要件§5：Cloudflare Worker プロキシ設定・トークン管理。
 * ============================================================ */

class ProxyService {
    constructor(db, config = null) {
        this.db = db;
        this.config = config;
        this.baseUrl = null;
        this.token = null;
    }

    setConfig(config) { this.config = config; }

    async init() {
        const adminCfg = (await this.db.getRaw('auth', 'admin_config')) || {};
        const appCfg = this.config?.getAppConfig?.() || {};
        this.baseUrl = (adminCfg.proxy_base_url || appCfg.proxy?.baseUrl || '').trim() || null;
        const tk = await this.db.getRaw('auth', 'proxy_token');
        if (tk) this.token = tk;
    }

    isConfigured() { return !!this.baseUrl; }

    async setBaseUrl(url, uid = null) {
        const clean = String(url || '').trim().replace(/\/$/, '');
        const adminCfg = (await this.db.getRaw('auth', 'admin_config')) || {};
        adminCfg.proxy_base_url = clean;
        await this.db.setRaw('auth', 'admin_config', adminCfg);
        this.baseUrl = clean || null;
        if (!this.baseUrl) await this.clearToken();
        else if (uid) await this.fetchToken(uid);
    }

    async fetchToken(uid) {
        if (!this.baseUrl || !uid) return null;
        try {
            const res = await fetch(this.baseUrl.replace(/\/$/, '') + '/auth/token', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ uid })
            });
            if (!res.ok) throw new Error('proxy token: ' + res.status);
            const data = await res.json();
            if (!data || !data.token) throw new Error('proxy token response is empty');
            this.token = data.token;
            await this.db.setRaw('auth', 'proxy_token', this.token);
            return this.token;
        } catch (e) {
            console.warn('[Proxy] トークン取得失敗:', e.message);
            await this.clearToken();
            return null;
        }
    }

    async clearToken() {
        this.token = null;
        await this.db.deleteRaw('auth', 'proxy_token');
    }

    canUseProxy(modelMeta, loggedIn) {
        return !!(loggedIn && this.baseUrl && this.token && modelMeta?.proxySupported);
    }

    buildProxyRequest(modelMeta) {
        if (!this.canUseProxy(modelMeta, true)) return null;
        return {
            url: this.baseUrl.replace(/\/$/, '') + '/v1/' + (modelMeta.providerId || modelMeta.provider) + '/generate',
            headers: {
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.token
            }
        };
    }
}

window.ProxyService = ProxyService;
