# AstroInsight v9（GitHub Pages root deploy）

星の波を「気分・行動・仕事・恋愛・人間関係・決断・注意点・チャンス」に翻訳する、AI占星術アプリ。

## このリリースの位置づけ

要件定義書 v5 の23セクション全てをカバーしつつ、管理者初期設定・スプラッシュ画面・安全な起動前検証を補強した v9 です。

### 主な変更点

- **モデル・プロバイダー・プロンプトを `js/config/*.json` に分離**（`models.json` / `prompts.json` / `app-config.json`）
- **管理者初期ブートストラップ**：`adminEmails` 未設定時は `#admin` ハッシュ・歯車アイコン長押し（700ms）・通常設定内ボタンから初期設定可能。`adminEmails` 設定後は管理者メールでログインしたユーザーに限定
- **APIキーをモデル単位 → プロバイダー単位に変更**：`provider_{providerId}_api_key` 形式で保存。同じプロバイダーを使う他のモデルでも再利用できる
- **モデル追加フォームを管理画面に配置**（プリセット選択あり）
- **予報一覧カードを廃止 → グラフで選択時点のみ表示**：折れ線グラフの点をタップした時点だけが詳細展開される
- **予報の各時点に追加項目**：波の正体／開始・ピーク・抜ける時期／占星術的な理由／乗り越えるポイント／良い波の活かし方／波が変わる予兆／細かなサイン／やってはいけないこと／今やるとよいこと／気分・行動・仕事・恋愛・人間関係・決断・注意点・チャンス／冥王星レイヤー
- **GitHub Pages root deploy 構造**：`/` 直下に `index.html` を配置
- **認証は Google Identity Services (GIS) のみ**：Firebase は完全に削除済み
- **起動時スプラッシュ画面を追加**：アプリ初期化中に専用スプラッシュを表示し、初期化完了後に自動でフェードアウト
- **初期設定不能バグを修正**：`#admin` 起動時にオンボーディングが管理画面を覆わないようにし、管理画面を前面に表示
- **生成前検証を中央化**：APIキー・プロキシ・モデル不備を生成前に表示し、失敗時に試用回数を消費しない
- **安全版バックアップ**：既定では APIキー・ログインキャッシュ・プロキシトークン等を除外し、必要時のみ秘密情報込みでエクスポート

## 主な機能（要件 v5 全23§）

- §1 SPA / PWA / Wake Lock / オフラインキャッシュ
- §2 認証（GIS Google ログイン、ゲスト3回試用→ログイン誘導、`adminEmails` で管理者判定）
- §3 広告（`ADS_ENABLED(uid)`／管理者非表示）と `PREMIUM_ENABLED(uid)` スタブ
- §4 §6 §16 AIモデル・プロンプト・アプリ設定をJSON管理。管理画面から編集可
- §5 Cloudflareプロキシ（ログイン済+対応モデルでのみ経由）
- §7 IndexedDB（`{uid}_*` プレフィックスでマルチアカウント対応・要件§19）
- §8 ホロスコープSVG（`astronomy-engine` + Equal House簡易計算）／天体タップツールチップ／ネイタル単独↔二重円トグル
- §9 オンボーディング4ステップ（ようこそ→プロフィール→ネイタル生成→完了）
- §10 §21 4タブ構成＋設定スライドイン＋詳細スライドイン（フェード・スライドアニメ）
- §11 今日タブ（今日／今週／今月セグメント）
- §12 予報タブ（月次／週次／日次／時間粒度。一覧廃止・選択時点のみ表示）
- §13 相性タブ（友達カード／+追加／長押しメニュー／自動相性生成／4カテゴリスコア＋総合）
- §14 チャット（SSEストリーミング・履歴永続化・文脈引き継ぎバッジ）
- §15 設定（アカウント／プロフ／AIモデル／プロンプト／データ管理／管理者ボタン）
- §16 管理者設定（フィーチャーフラグ／プロキシ／プロバイダーAPIキー／GIS設定／JSON個別保存／プリセットモデル追加）
- §17 バックグラウンド処理（スナックバー進捗・並列タスク・プリフェッチ）
- §18 🔄更新ボタンで強制再生成
- §19 キャッシュキー `{uid}_*`
- §20 リクエストルーティング（プロキシ↔直接APIの自動切替）
- §22 将来拡張用フラグ（`PREMIUM_ENABLED` 等）
- §23 CDNライブラリ（Tailwind / Font Awesome 6.5.1 / marked / Chart.js / astronomy-engine / Noto Sans JP / GIS は `accounts.google.com/gsi/client` を動的ロード）

## Google ログイン (GIS) 設定

このアプリの認証は **Google Identity Services (GIS)** のみです。

### 必要なもの

- Google Cloud Console の **OAuth 2.0 クライアント ID**（Web アプリケーション）

### 設定手順

1. [Google Cloud Console](https://console.cloud.google.com/) でプロジェクトを開くか作成する
2. **API とサービス → 認証情報 → 認証情報を作成 → OAuth クライアント ID** を選択
3. アプリケーションの種類: **ウェブ アプリケーション**
4. **承認済みの JavaScript 生成元** にこのアプリのオリジンを追加：
   - 例: `https://<your-username>.github.io`
   - ローカル動作確認なら `http://localhost:8000` 等
5. （リダイレクト URI は GIS では不要）
6. 作成された **クライアント ID**（末尾が `.apps.googleusercontent.com`）をコピー
7. アプリ側 `js/config/app-config.json` の `auth.googleClientId` に貼り付ける（または `#admin` から管理画面で保存）
8. `auth.adminEmails` に管理者にしたい Google アカウントのメールアドレスを追加（カンマ区切り or 配列）
9. リロードすると設定セクションに Google 公式のサインインボタンが表示される

### 動作

- ログイン成功時：JWT (ID Token) の payload から `sub`(uid) / `email` / `name` / `picture` / `exp` を読み取り、ローカルには ID Token 本体を保存しない
- `auth.adminEmails` に email が含まれていれば自動的に管理者ロールを付与
- IndexedDB は `{uid}_*` プレフィックスで分離。キャッシュ済みログインは期限内のみ復元

## 管理画面の開き方

1. URL末尾に `#admin` を付ける（例: `https://example.com/#admin`）
2. ヘッダーの ⚙ アイコンを **700ms 長押し**
3. 設定画面下部の「管理用設定を開く」ボタン

`adminEmails` が未設定の初期状態ではブートストラップ用に開けます。`adminEmails` 設定後は、管理者メールでログインしたユーザーのみ通常ボタンから開けます。本番では Cloudflare Worker 側で別途認可することを推奨。

## 修正済みの重要挙動

- `#admin` で起動した場合はオンボーディングを隠し、設定画面と管理者パネルを前面に表示します。
- `adminEmails` が空の間だけ初期ブートストラップとして管理画面を開けます。管理者メール保存後は、ログイン済み管理者のみ開けます。
- APIキー未設定・プロキシトークン未取得・モデル設定不備は、生成前に画面通知します。この段階では試用回数を消費しません。
- 詳細表示やバックグラウンドの予報プリフェッチでは追加の試用回数を消費しません。
- 予報の月次／週次／日次／時間粒度は選択状態を保持し、日次件数は説明と一致する約75日分です。
- `app-config.json` の `proxy.baseUrl` と管理画面のプロキシ URL は同じ経路で扱います。ログアウト時はプロキシトークンを削除します。
- `全データ消去` は APIキー・管理設定を含む `auth` ストアも消去します。
- 不明な出生地は東京へ黙って置換せず、緯度経度 `35.6895,139.6917` 形式の直接入力にも対応します。

## デプロイ

GitHub Pages へのデプロイ手順は `DEPLOY_GITHUB_PAGES.md` を参照。

## ファイル構成

```
/
├── .nojekyll            ← GitHub Pages 用（_ で始まるディレクトリも配信）
├── 404.html             ← SPA フォールバック
├── index.html
├── manifest.webmanifest
├── sw.js                ← Service Worker（root scope）
├── README.md
├── DEPLOY_GITHUB_PAGES.md
├── css/
│   └── styles.css
└── js/
    ├── app.js
    ├── config/
    │   ├── app-config.json
    │   ├── models.json
    │   └── prompts.json
    ├── core/
    │   ├── ai-worker-manager.js
    │   ├── astrology.js
    │   ├── auth.js
    │   ├── config-loader.js
    │   ├── db.js
    │   ├── feature-flags.js
    │   ├── horoscope-renderer.js
    │   ├── proxy.js
    │   └── snackbar.js
    ├── components/
    │   ├── ads.js
    │   ├── chat.js
    │   ├── compat.js
    │   ├── detail.js
    │   ├── forecast.js
    │   ├── natal.js
    │   ├── onboarding.js
    │   ├── profile.js
    │   ├── settings.js
    │   ├── today.js
    │   └── ui-controller.js
    └── workers/
        └── ai-worker.js
```

## ライセンス

Private. © 2026
