/* ============================================================
 * AstroInsight - Auth Service（v5）
 * 要件§2 を実装する：
 *   - 未ログイン状態でもアプリは即起動。ログイン画面は出さない。
 *   - 未ログイン: AI生成は累計3回まで。3回超過後は「ログインしてください」。
 *   - Googleログイン後: UID取得、Cloudflare Workerにトークン要求、IndexedDBに保存。
 *   - 管理者: Firebase Auth カスタムクレームで判定。広告非表示・管理者画面アクセス可。
 *   - ログアウト: ゲスト状態に戻る（端末DBは残る）。
 *
 * Firebase 実SDK は管理者設定で API キー等を入れると有効化される。
 * 未設定時はモックとして「ゲスト」状態のみで動作する（要件通り3回まで使える）。
 * ============================================================ */

class AuthService {
    /**
     * @param {AstroDB} db
     */
    constructor(db) {
        this.db = db;
        this.user = null; // { uid, name, email, photoURL, isAdmin }
        this._listeners = [];
        this._firebase = null; // 後から init で設定
    }

    /** アプリ起動時に呼ぶ */
    async init() {
        // 起動時に guest_temp 領域はクリアする（要件§2「アプリを閉じると消える」）。
        // ※前回のセッションが正常に閉じられず残った場合に備えて常に走らせる。
        await this.db.clearGuestTemp();

        // Firebase 設定が管理者設定に保存されていれば SDK を有効化（任意）
        const fbCfg = await this.db.getRaw('auth', 'firebase_config');
        if (fbCfg && fbCfg.apiKey && fbCfg.authDomain && fbCfg.projectId) {
            await this._tryInitFirebase(fbCfg);
        }

        // 直前のログインセッションがあれば復元（Firebase未起動時の擬似永続）
        const cached = await this.db.getRaw('auth', 'cached_user');
        if (cached && cached.uid) {
            this.user = cached;
            this.db.setUidPrefix(cached.uid);
        } else {
            this.db.setUidPrefix('guest_temp');
        }

        this._notify();
    }

    /** Firebase SDKの動的ロード（管理者設定を使う場合） */
    async _tryInitFirebase(cfg) {
        try {
            // CDNモジュールから動的import（要件§23 Firebase SDK CDN）
            const appMod = await import('https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js');
            const authMod = await import('https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js');
            const app = appMod.initializeApp({
                apiKey: cfg.apiKey,
                authDomain: cfg.authDomain,
                projectId: cfg.projectId
            });
            const auth = authMod.getAuth(app);
            this._firebase = { auth, app, mod: authMod };
            // ログイン状態の監視
            authMod.onAuthStateChanged(auth, async (u) => {
                if (u) {
                    // カスタムクレーム取得（管理者判定）
                    let isAdmin = false;
                    try {
                        const tok = await u.getIdTokenResult();
                        isAdmin = !!tok.claims.admin;
                    } catch (e) {}
                    this.user = {
                        uid: u.uid,
                        name: u.displayName || '',
                        email: u.email || '',
                        photoURL: u.photoURL || '',
                        isAdmin
                    };
                    this.db.setUidPrefix(u.uid);
                    await this.db.setRaw('auth', 'cached_user', this.user);
                    // ログイン後にプロキシトークン取得（要件§5）
                    if (window.app?.proxy) await window.app.proxy.fetchToken(u.uid);
                    this._notify();
                } else {
                    this.user = null;
                    this.db.setUidPrefix('guest_temp');
                    this._notify();
                }
            });
        } catch (e) {
            console.warn('[Auth] Firebase 初期化失敗（モックで続行）:', e.message);
        }
    }

    /** Googleログイン（要件§2） */
    async signInGoogle() {
        if (this._firebase) {
            const { auth, mod } = this._firebase;
            const provider = new mod.GoogleAuthProvider();
            await mod.signInWithPopup(auth, provider);
            return;
        }
        // Firebase 未設定時はスタブとして動作（管理者設定でキーを入れるよう促す）
        alert('Firebase認証が未設定です。管理者設定からFirebase設定を入力してください。\n（要件§2: Googleログインに必須）');
    }

    /** ログアウト（要件§2） */
    async signOut() {
        if (this._firebase) {
            await this._firebase.mod.signOut(this._firebase.auth);
        } else {
            this.user = null;
            await this.db.deleteRaw('auth', 'cached_user');
            this.db.setUidPrefix('guest_temp');
            this._notify();
        }
    }

    isLoggedIn() {
        return !!this.user;
    }
    isAdmin() {
        return !!this.user?.isAdmin;
    }
    currentUid() {
        return this.user?.uid || null;
    }

    /** 状態変化リスナー */
    onChange(fn) {
        this._listeners.push(fn);
    }
    _notify() {
        for (const fn of this._listeners) {
            try {
                fn(this.user);
            } catch (e) {}
        }
    }

    // ---- 試用回数管理（要件§2 ゲストは累計3回まで） ----

    /** 残り試用回数 */
    async remainingTrials() {
        if (this.isLoggedIn()) return Infinity;
        const used = (await this.db.getRaw('auth', 'guest_trial_used')) || 0;
        const max = (await this.db.getRaw('auth', 'guest_trial_max')) || 3;
        return Math.max(0, max - used);
    }

    /** 試用1回消費。残あり=true / 残ゼロ=false */
    async consumeTrial() {
        if (this.isLoggedIn()) return true;
        const used = (await this.db.getRaw('auth', 'guest_trial_used')) || 0;
        const max = (await this.db.getRaw('auth', 'guest_trial_max')) || 3;
        if (used >= max) return false;
        await this.db.setRaw('auth', 'guest_trial_used', used + 1);
        return true;
    }

    async resetTrial() {
        await this.db.setRaw('auth', 'guest_trial_used', 0);
    }

    /** ゲスト→ログイン移行時、guest_temp のデータを uid 領域へコピー（要件§2 移行オプション） */
    async migrateGuestData() {
        if (!this.isLoggedIn()) return;
        const uid = this.currentUid();
        // store ストアの guest_temp::* を uid::* にコピー
        await this._copyByPrefix('store', 'guest_temp::', `${uid}::`);
        await this._copyByPrefix('cache', 'guest_temp::', `${uid}::`);
        await this._copyByPrefix('friends', 'guest_temp::', `${uid}::`);
        await this.db.clearGuestTemp();
    }

    async _copyByPrefix(storeName, fromPrefix, toPrefix) {
        if (!this.db.db) await this.db.init();
        return new Promise((res) => {
            const tx = this.db.db.transaction(storeName, 'readwrite');
            const o = tx.objectStore(storeName);
            const req = o.openCursor();
            req.onsuccess = (e) => {
                const cur = e.target.result;
                if (cur) {
                    if (typeof cur.key === 'string' && cur.key.startsWith(fromPrefix)) {
                        const newKey = toPrefix + cur.key.substring(fromPrefix.length);
                        o.put(cur.value, newKey);
                    }
                    cur.continue();
                }
            };
            tx.oncomplete = () => res();
            tx.onerror = () => res();
        });
    }
}

window.AuthService = AuthService;
