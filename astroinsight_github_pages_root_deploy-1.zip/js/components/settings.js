/* ============================================================
 * AstroInsight - Settings Component（v6）
 * 要件§15 通常設定 + 要件§16 管理者設定
 * v6 改：APIキーを「プロバイダー単位」で管理（README追加要件）。
 *
 * 通常設定（§15）:
 *   - AIモデル設定（モデル選択、プロバイダー単位APIキー保存）
 *   - 一覧（カスタム削除・デフォルト非表示切替）は管理者画面に集約
 *   - システムプロンプト設定（機能ごとに編集、デフォルトに戻す）
 *   - プロフィール管理（編集、ネイタル分析手動再生成）
 *   - アカウント管理
 *   - データ管理（バックアップDL/復元/全消去）
 *   - 管理者設定ボタン（管理者のみ表示）
 *
 * 管理者設定（§16）:
 *   - フィーチャーフラグ（max_tokens, temperature, top_p, guest_trial_max,
 *     ads_enabled, premium_enabled, app_name 等）
 *   - プロバイダー単位APIキー（フロント露出なし、ローカル保管のみ）
 *   - Cloudflareプロキシ設定（ベースURL）
 *   - Google ログイン (GIS) 設定（Client ID / 管理者メール一覧）
 *   - models.json / prompts.json / app-config.json のJSON編集
 *   - モデル追加プリセット
 * ============================================================ */

class SettingsComponent {
    constructor(app) {
        this.app = app;
        this.db = app.db;
    }

    async load() {
        await this._renderModelSection();
        await this._renderPromptSection();
        await this.app.profile.load();
        await this._renderAccountSection();
        this._renderAdminButton();
    }

    // ===================== AIモデル =====================
    async _renderModelSection() {
        const select = document.getElementById('set-model-select');
        if (!select) return;
        const models = await this.app.config.getMergedModels();
        const current = (await this.db.get('selected_model')) || (models[0]?.id || '');
        select.innerHTML = '';
        for (const m of models) {
            const op = document.createElement('option');
            op.value = m.id;
            op.textContent = m.name + (m.recommended ? ' ★' : '');
            if (m.id === current) op.selected = true;
            select.appendChild(op);
        }
        select.onchange = () => {
            this.db.set('selected_model', select.value);
            this._renderProviderApiKeyField(select.value);
        };
        await this._renderProviderApiKeyField(current);
    }

    /**
     * モデル選択 → 対応プロバイダーのAPIキー入力欄を表示（要件§4 v6改）。
     * プロキシ対応モデル + ログイン済み + プロキシ設定済みの場合はグレーアウト。
     */
    async _renderProviderApiKeyField(modelId) {
        const input = document.getElementById('set-api-key');
        const note = document.getElementById('set-api-key-note');
        const label = document.getElementById('set-api-key-label');
        if (!input) return;
        const m = await this.app.config.getModelById(modelId);
        if (!m) return;
        const providerId = m.providerId || m.provider;
        const provider = this.app.config.getProviderById(providerId);
        const apiKey = await this.app.config.getProviderApiKey(providerId);
        input.value = apiKey;
        if (label) label.textContent = `${provider?.name || providerId} のAPIキー`;
        const loggedIn = this.app.auth.isLoggedIn();
        const proxyOk = m.proxySupported && loggedIn && this.app.proxy.isConfigured();
        input.disabled = proxyOk;
        if (note) {
            note.textContent = proxyOk
                ? '（プロキシ経由のためAPIキーは任意です）'
                : `（このプロバイダーのAPIキーが必要です。同じ${provider?.name || ''}を使う他モデルでも共有されます）`;
        }
    }

    /** APIキー保存（プロバイダー単位） */
    async saveApiKey() {
        const select = document.getElementById('set-model-select');
        const input = document.getElementById('set-api-key');
        if (!select || !input) return;
        const m = await this.app.config.getModelById(select.value);
        if (!m) return;
        const providerId = m.providerId || m.provider;
        await this.app.config.setProviderApiKey(providerId, input.value);
        const provider = this.app.config.getProviderById(providerId);
        this.app.snackbar.start('save-key', 'APIキー保存中…');
        this.app.snackbar.succeed('save-key', `✓ ${provider?.name || providerId} のAPIキーを保存しました`);
    }

    /** ＋モデル追加（要件§4 §15 §16） */
    async addCustomModel() {
        const id = document.getElementById('set-newmodel-id')?.value.trim();
        const name = document.getElementById('set-newmodel-name')?.value.trim();
        const providerId = document.getElementById('set-newmodel-provider')?.value;
        const path = document.getElementById('set-newmodel-path')?.value.trim();
        const endpoint = document.getElementById('set-newmodel-endpoint')?.value.trim();
        const proxy = document.getElementById('set-newmodel-proxy')?.checked;
        if (!id || !name || !providerId) return alert('ID・表示名・プロバイダーは必須です。');
        if (!path && !endpoint) return alert('エンドポイントURLまたはプロバイダーパスのいずれかは必須です。');
        const provider = this.app.config.getProviderById(providerId);
        const finalEndpoint = endpoint || (provider ? provider.baseUrl.replace(/\/$/, '') + path : '');
        await this.app.config.addCustomModel({
            id, name, providerId, provider: providerId, path, endpoint: finalEndpoint,
            streaming: 'sse', recommended: false, proxySupported: !!proxy, enabled: true
        });
        ['set-newmodel-id', 'set-newmodel-name', 'set-newmodel-path', 'set-newmodel-endpoint'].forEach((i) => {
            const e = document.getElementById(i); if (e) e.value = '';
        });
        await this._renderModelSection();
        this.app.snackbar.start('add-model', 'モデル追加中…');
        this.app.snackbar.succeed('add-model', '✓ モデルを追加しました');
    }

    // ===================== プロンプト =====================
    async _renderPromptSection() {
        const cont = document.getElementById('set-prompts');
        if (!cont) return;
        const prompts = await this.app.config.getAllCurrentPrompts();
        cont.innerHTML = '';
        for (const key of Object.keys(prompts)) {
            const p = prompts[key];
            const row = document.createElement('div');
            row.className = 'mb-3';
            row.innerHTML = `
                <div class="flex justify-between items-center mb-1">
                    <label class="text-xs font-bold text-slate-700">${this._esc(p.label)}</label>
                    <button data-reset="${this._esc(key)}" class="text-xs text-astro hover:text-astro-dark"><i class="fa-solid fa-rotate-left mr-1"></i>デフォルトに戻す</button>
                </div>
                <p class="text-[10px] text-slate-500 mb-1">${this._esc(p.description || '')}</p>
                <textarea data-key="${this._esc(key)}" rows="3" class="w-full text-xs p-2 border border-slate-300 rounded-lg">${this._esc(p.value || '')}</textarea>`;
            cont.appendChild(row);
            row.querySelector('textarea').addEventListener('blur', async (e) => {
                await this.app.config.saveUserPrompt(key, e.target.value);
            });
            row.querySelector('button').addEventListener('click', async () => {
                await this.app.config.resetUserPrompt(key);
                await this._renderPromptSection();
            });
        }
    }

    // ===================== プロフィール =====================
    async saveProfile() {
        await this.app.profile.save();
    }
    async regenerateNatal() {
        if (!confirm('ネイタル分析を再生成しますか？')) return;
        const k = `natal_${await this.app.profile.getProfileHash()}`;
        await this.db.cacheDelete(k);
        await this.app.natal.generate();
    }

    // ===================== アカウント（要件§15） =====================
    async _renderAccountSection() {
        const el = document.getElementById('set-account');
        if (!el) return;
        const u = this.app.auth.user;
        if (u) {
            el.innerHTML = `
                <div class="flex items-center gap-3">
                    ${u.photoURL ? `<img src="${u.photoURL}" class="w-12 h-12 rounded-full">` : `<i class="fa-solid fa-user-circle text-4xl text-astro"></i>`}
                    <div class="flex-1">
                        <div class="font-bold text-slate-800">${this._esc(u.name || u.email || 'ユーザー')}</div>
                        <div class="text-xs text-slate-500">${this._esc(u.email || '')}</div>
                        ${u.isAdmin ? '<span class="text-[10px] bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full">管理者</span>' : ''}
                    </div>
                </div>
                <div class="flex gap-2 mt-3">
                    <button id="btn-migrate-guest" class="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-2 rounded-xl text-xs">
                        <i class="fa-solid fa-arrows-turn-right mr-1"></i>ゲストデータを移行
                    </button>
                    <button id="btn-logout" class="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-2 rounded-xl text-sm">
                        <i class="fa-solid fa-right-from-bracket mr-1"></i>ログアウト
                    </button>
                </div>`;
            el.querySelector('#btn-logout').addEventListener('click', async () => {
                await this.app.auth.signOut();
                location.reload();
            });
            el.querySelector('#btn-migrate-guest').addEventListener('click', async () => {
                await this.app.auth.migrateGuestData();
                this.app.snackbar.start('mig', '移行中…');
                this.app.snackbar.succeed('mig', '✓ ゲストデータを移行しました');
                location.reload();
            });
        } else {
            const remain = await this.app.auth.remainingTrials();
            const max = this.app.flags.get('guest_trial_max') || 3;
            const gisReady = this.app.auth.isGISReady && this.app.auth.isGISReady();
            el.innerHTML = `
                <p class="text-sm text-slate-700 mb-2">未ログインです。</p>
                <p class="text-xs text-slate-500 mb-3">無料試用 残り <b class="text-astro">${remain}</b> 回 / 上限${max}回</p>
                <div id="g_id_signin_btn" class="flex justify-center mb-2"></div>
                <button id="btn-login-fallback" class="w-full bg-astro hover:bg-astro-dark text-white font-bold py-2 rounded-xl text-sm ${gisReady ? 'hidden' : ''}">
                    <i class="fa-brands fa-google mr-1"></i> Googleでログイン
                </button>
                <p class="text-[10px] text-slate-400 mt-2">ログインするとデータをアカウントに紐付けて永続化できます。</p>
                ${gisReady ? '' : '<p class="text-[10px] text-amber-600 mt-1">※ Google Identity Services が初期化されていません。管理者設定の Client ID を確認してください。</p>'}`;
            el.querySelector('#btn-login-fallback').addEventListener('click', () => this.app.auth.signInGoogle());
            // GIS 公式ボタンを描画
            if (gisReady) {
                this.app.auth.renderGoogleButton('g_id_signin_btn');
            }
        }
    }

    // ===================== データ管理（要件§15） =====================
    async backupDownload() {
        const out = { exportedAt: new Date().toISOString(), uidPrefix: this.db.getUidPrefix(), data: {} };
        const stores = ['store', 'cache', 'friends', 'auth'];
        for (const s of stores) {
            out.data[s] = await this._dumpStore(s);
        }
        const blob = new Blob([JSON.stringify(out, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url; a.download = 'astroinsight-backup.json';
        a.click();
        URL.revokeObjectURL(url);
    }

    async restoreFromFile(file) {
        try {
            const txt = await file.text();
            const data = JSON.parse(txt);
            for (const s of Object.keys(data.data || {})) {
                for (const item of data.data[s]) {
                    await this.db.setRaw(s, item.key, item.value);
                }
            }
            alert('復元しました。');
            location.reload();
        } catch (e) {
            alert('復元に失敗しました: ' + e.message);
        }
    }

    async clearAllData() {
        if (!confirm('全データを削除します。本当によろしいですか？\n（バックアップを取っていない場合は復元できません）')) return;
        await this.db.clearAll();
        alert('削除しました。リロードします。');
        location.reload();
    }

    async _dumpStore(storeName) {
        if (!this.db.db) await this.db.init();
        return new Promise((res) => {
            const out = [];
            const tx = this.db.db.transaction(storeName);
            const o = tx.objectStore(storeName);
            const req = o.openCursor();
            req.onsuccess = (e) => {
                const cur = e.target.result;
                if (cur) { out.push({ key: cur.key, value: cur.value }); cur.continue(); }
                else res(out);
            };
            req.onerror = () => res([]);
        });
    }

    // ===================== 管理者（要件§16） =====================
    _renderAdminButton() {
        const el = document.getElementById('set-admin-btn');
        if (!el) return;
        // 認可：管理者のみ表示。ユーザー版同様、未ログイン状態でも #admin で開ける
        // ようにしてあるので、ボタンは管理者ロール保有時のみ表示。
        if (this.app.auth.isAdmin()) {
            el.classList.remove('hidden');
            el.onclick = () => this.openAdminPanel();
        } else {
            el.classList.add('hidden');
        }
    }

    async openAdminPanel() {
        const panel = document.getElementById('admin-panel');
        if (!panel) return;
        const flags = this.app.flags.flags;
        const adminCfg = (await this.db.getRaw('auth', 'admin_config')) || {};
        const providers = this.app.config.getProviders();
        const presets = this.app.config.getPresets();
        const modelsJson = JSON.stringify(this.app.config.defaultModelsConfig, null, 2);
        const promptsJson = JSON.stringify(this.app.config.defaultPrompts, null, 2);
        const appCfgJson = JSON.stringify(this.app.config.getAppConfig(), null, 2);

        // プロバイダー単位APIキー一覧
        const providerKeyRows = [];
        for (const p of providers) {
            const v = await this.app.config.getProviderApiKey(p.id);
            providerKeyRows.push(`
                <div class="bg-slate-50 rounded-xl p-3 mb-2 border border-slate-200">
                    <div class="flex items-center justify-between mb-1">
                        <b class="text-xs">${this._esc(p.name)}</b>
                        <span id="status_${p.id}" class="text-[10px] ${v ? 'text-emerald-600' : 'text-slate-400'}">${v ? '保存済み' : '未保存'}</span>
                    </div>
                    <p class="text-[10px] text-slate-500 mb-1">Provider ID: <code>${this._esc(p.id)}</code> / Auth: ${this._esc(p.authType || '')}</p>
                    <input id="adm-key-${p.id}" type="password" class="w-full text-xs border p-1 rounded" value="${this._esc(v || '')}">
                    <div class="flex gap-1 mt-1">
                        <button data-save-prov-key="${p.id}" class="flex-1 bg-astro text-white text-[10px] font-bold py-1.5 rounded">保存</button>
                        <button data-toggle-prov-key="${p.id}" class="bg-slate-200 text-slate-700 text-[10px] font-bold px-2 py-1.5 rounded">表示/非表示</button>
                    </div>
                </div>`);
        }

        // モデル追加プリセット
        const presetOpts = ['<option value="">プリセット選択</option>']
            .concat(presets.map((p, i) => `<option value="${i}">${this._esc(p.name)}</option>`))
            .join('');
        const providerOpts = providers.map((p) => `<option value="${this._esc(p.id)}">${this._esc(p.name)}</option>`).join('');

        panel.classList.remove('hidden');
        panel.innerHTML = `
            <div class="space-y-3">
                <p class="text-[10px] text-slate-500">本番ではフロントPINではなく、adminEmails または Cloudflare Worker 側で管理者認可してください。</p>

                <div class="bg-white rounded-xl p-3 border border-slate-200">
                    <h3 class="font-bold text-sm mb-2">📊 フィーチャーフラグ</h3>
                    <label class="text-xs block mb-1">max_tokens <input id="adm-max-tokens" class="w-full text-xs border p-1 rounded" type="number" value="${flags.ai_max_tokens}"></label>
                    <label class="text-xs block mb-1">temperature <input id="adm-temp" class="w-full text-xs border p-1 rounded" type="number" step="0.05" value="${flags.ai_temperature}"></label>
                    <label class="text-xs block mb-1">top_p <input id="adm-top-p" class="w-full text-xs border p-1 rounded" type="number" step="0.05" value="${flags.ai_top_p}"></label>
                    <label class="text-xs block mb-1">未ログイン試用回数上限 <input id="adm-trial" class="w-full text-xs border p-1 rounded" type="number" value="${flags.guest_trial_max}"></label>
                    <label class="text-xs flex items-center gap-2 mt-1"><input id="adm-ads" type="checkbox" ${flags.ads_enabled ? 'checked' : ''}> ADS_ENABLED</label>
                    <label class="text-xs flex items-center gap-2"><input id="adm-premium" type="checkbox" ${flags.premium_enabled ? 'checked' : ''}> PREMIUM_ENABLED (スタブ)</label>
                    <label class="text-xs block mt-1">アプリ名 <input id="adm-app-name" class="w-full text-xs border p-1 rounded" value="${this._esc(flags.app_name)}"></label>
                    <button id="adm-save-flags" class="mt-2 w-full bg-astro text-white text-xs font-bold py-2 rounded-lg">保存</button>
                </div>

                <div class="bg-white rounded-xl p-3 border border-slate-200">
                    <h3 class="font-bold text-sm mb-2">☁️ Cloudflareプロキシ</h3>
                    <label class="text-xs block">ベースURL <input id="adm-proxy-url" class="w-full text-xs border p-1 rounded" value="${this._esc(adminCfg.proxy_base_url || '')}" placeholder="https://your-worker.example.workers.dev"></label>
                    <button id="adm-save-proxy" class="mt-2 w-full bg-astro text-white text-xs font-bold py-2 rounded-lg">保存</button>
                </div>

                <div class="bg-white rounded-xl p-3 border border-slate-200">
                    <h3 class="font-bold text-sm mb-2">🔑 プロバイダー単位APIキー</h3>
                    <p class="text-[10px] text-slate-500 mb-2">同じプロバイダーを使う複数モデルで共有。フロント露出なし、ローカル保管のみ。</p>
                    ${providerKeyRows.join('')}
                </div>

                <div class="bg-white rounded-xl p-3 border border-slate-200">
                    <h3 class="font-bold text-sm mb-2">🆔 Google ログイン (GIS)</h3>
                    <p class="text-[10px] text-slate-500 mb-2">Google Cloud Console の OAuth 2.0 クライアント ID。<br>承認済み JavaScript 生成元にこのサイトのオリジン (例: <code>https://username.github.io</code>) を必ず追加してください。</p>
                    <label class="text-xs block">Google OAuth Client ID
                        <input id="adm-gis-client" class="w-full text-xs border p-1 rounded" value="${this._esc(this.app.auth._gisClientId || '')}" placeholder="xxxxxxxx-xxxxxxxxx.apps.googleusercontent.com">
                    </label>
                    <p class="text-[10px] mt-2">管理者メール (改行/カンマ区切り。ここに含まれるメールでログインしたユーザーが管理者になります)</p>
                    <textarea id="adm-gis-admins" rows="3" class="w-full text-xs border p-1 rounded font-mono" placeholder="admin@example.com\nother@example.com">${this._esc((this.app.auth._adminEmails || []).join('\n'))}</textarea>
                    <button id="adm-save-gis" class="mt-2 w-full bg-astro text-white text-xs font-bold py-2 rounded-lg">保存</button>
                    <p class="text-[10px] text-slate-400 mt-1">※ Client ID 変更後は GIS の再初期化のため一度リロードしてください。</p>
                </div>

                <div class="bg-white rounded-xl p-3 border border-slate-200">
                    <h3 class="font-bold text-sm mb-2">🤖 モデル追加プリセット</h3>
                    <select id="adm-preset" class="w-full text-xs border p-1 rounded mb-1">${presetOpts}</select>
                    <label class="text-xs block">表示名 <input id="adm-newmodel-name" class="w-full text-xs border p-1 rounded"></label>
                    <label class="text-xs block">モデルID <input id="adm-newmodel-id" class="w-full text-xs border p-1 rounded"></label>
                    <label class="text-xs block">プロバイダー <select id="adm-newmodel-provider" class="w-full text-xs border p-1 rounded">${providerOpts}</select></label>
                    <label class="text-xs block">パス <input id="adm-newmodel-path" class="w-full text-xs border p-1 rounded" placeholder="/chat/completions"></label>
                    <label class="text-xs flex items-center gap-2 mt-1"><input id="adm-newmodel-proxy" type="checkbox" checked> プロキシ対応</label>
                    <button id="adm-add-model" class="mt-2 w-full bg-astro text-white text-xs font-bold py-2 rounded-lg">モデルを追加</button>
                </div>

                <div class="bg-white rounded-xl p-3 border border-slate-200">
                    <h3 class="font-bold text-sm mb-2">📋 models.json</h3>
                    <textarea id="adm-models-json" rows="6" class="w-full text-[10px] border p-1 rounded font-mono">${this._esc(modelsJson)}</textarea>
                    <button data-save-json="models" class="mt-2 w-full bg-astro text-white text-xs font-bold py-2 rounded-lg">models.json を保存</button>
                </div>

                <div class="bg-white rounded-xl p-3 border border-slate-200">
                    <h3 class="font-bold text-sm mb-2">📜 prompts.json</h3>
                    <textarea id="adm-prompts-json" rows="6" class="w-full text-[10px] border p-1 rounded font-mono">${this._esc(promptsJson)}</textarea>
                    <button data-save-json="prompts" class="mt-2 w-full bg-astro text-white text-xs font-bold py-2 rounded-lg">prompts.json を保存</button>
                </div>

                <div class="bg-white rounded-xl p-3 border border-slate-200">
                    <h3 class="font-bold text-sm mb-2">⚙️ app-config.json</h3>
                    <textarea id="adm-app-json" rows="6" class="w-full text-[10px] border p-1 rounded font-mono">${this._esc(appCfgJson)}</textarea>
                    <button data-save-json="app" class="mt-2 w-full bg-astro text-white text-xs font-bold py-2 rounded-lg">app-config.json を保存</button>
                </div>

                <button id="adm-close" class="w-full bg-slate-200 text-slate-700 font-bold py-2 rounded-xl text-sm">閉じる</button>
            </div>`;

        // フィーチャーフラグ保存
        panel.querySelector('#adm-save-flags').addEventListener('click', async () => {
            await this.app.flags.save({
                ai_max_tokens: parseInt(panel.querySelector('#adm-max-tokens').value),
                ai_temperature: parseFloat(panel.querySelector('#adm-temp').value),
                ai_top_p: parseFloat(panel.querySelector('#adm-top-p').value),
                guest_trial_max: parseInt(panel.querySelector('#adm-trial').value),
                ads_enabled: panel.querySelector('#adm-ads').checked,
                premium_enabled: panel.querySelector('#adm-premium').checked,
                app_name: panel.querySelector('#adm-app-name').value
            });
            this.app.ads.refresh();
            this.app.snackbar.start('flags', '保存中…');
            this.app.snackbar.succeed('flags', '✓ フィーチャーフラグを保存');
        });

        // プロキシ保存
        panel.querySelector('#adm-save-proxy').addEventListener('click', async () => {
            await this.app.proxy.setBaseUrl(panel.querySelector('#adm-proxy-url').value.trim());
            this.app.snackbar.start('proxy', '保存中…');
            this.app.snackbar.succeed('proxy', '✓ プロキシURLを保存');
        });

        // プロバイダーAPIキー保存
        panel.querySelectorAll('[data-save-prov-key]').forEach((btn) => {
            btn.addEventListener('click', async () => {
                const pid = btn.dataset.saveProvKey;
                const v = panel.querySelector(`#adm-key-${pid}`).value.trim();
                await this.app.config.setProviderApiKey(pid, v);
                const status = panel.querySelector(`#status_${pid}`);
                if (status) {
                    status.textContent = v ? '保存済み' : '未保存';
                    status.classList.toggle('text-emerald-600', !!v);
                    status.classList.toggle('text-slate-400', !v);
                }
                this.app.snackbar.start('pk-' + pid, '保存中…');
                this.app.snackbar.succeed('pk-' + pid, '✓ APIキーを保存');
            });
        });
        panel.querySelectorAll('[data-toggle-prov-key]').forEach((btn) => {
            btn.addEventListener('click', () => {
                const pid = btn.dataset.toggleProvKey;
                const inp = panel.querySelector(`#adm-key-${pid}`);
                if (inp) inp.type = inp.type === 'password' ? 'text' : 'password';
            });
        });

        // GIS (Google Identity Services) 設定保存
        panel.querySelector('#adm-save-gis').addEventListener('click', async () => {
            const clientId = panel.querySelector('#adm-gis-client').value.trim();
            const adminText = panel.querySelector('#adm-gis-admins').value;
            const adminEmails = adminText.split(/[,\n]/).map((e) => e.trim()).filter(Boolean);
            await this.app.auth.updateGoogleAuthSettings({ clientId, adminEmails });
            this.app.snackbar.start('gis', '保存中…');
            this.app.snackbar.succeed('gis', '✓ GIS設定を保存。Client ID変更時はリロードで反映');
            await this._renderAccountSection();
        });

        // プリセット選択 → フォームに反映
        const preset = panel.querySelector('#adm-preset');
        if (preset) preset.addEventListener('change', () => {
            const p = presets[Number(preset.value)];
            if (!p) return;
            panel.querySelector('#adm-newmodel-name').value = p.name;
            panel.querySelector('#adm-newmodel-id').value = p.id;
            panel.querySelector('#adm-newmodel-provider').value = p.providerId;
            panel.querySelector('#adm-newmodel-path').value = p.path;
        });

        // モデル追加
        panel.querySelector('#adm-add-model').addEventListener('click', async () => {
            const id = panel.querySelector('#adm-newmodel-id').value.trim();
            const name = panel.querySelector('#adm-newmodel-name').value.trim();
            const providerId = panel.querySelector('#adm-newmodel-provider').value;
            const path = panel.querySelector('#adm-newmodel-path').value.trim();
            const proxy = panel.querySelector('#adm-newmodel-proxy').checked;
            if (!id || !name || !providerId || !path) return alert('全項目入力必須');
            const provider = this.app.config.getProviderById(providerId);
            const endpoint = provider ? provider.baseUrl.replace(/\/$/, '') + path : '';
            await this.app.config.addCustomModel({
                id, name, providerId, provider: providerId, path, endpoint,
                streaming: 'sse', recommended: false, proxySupported: !!proxy, enabled: true
            });
            this.app.snackbar.start('addm', '追加中…');
            this.app.snackbar.succeed('addm', '✓ モデルを追加しました');
            await this._renderModelSection();
        });

        // 各 JSON 保存
        panel.querySelectorAll('[data-save-json]').forEach((btn) => {
            btn.addEventListener('click', async () => {
                try {
                    if (btn.dataset.saveJson === 'models') {
                        const parsed = JSON.parse(panel.querySelector('#adm-models-json').value);
                        if (!Array.isArray(parsed.providers) || !Array.isArray(parsed.models)) throw new Error('models.json には providers と models の配列が必要です');
                        await this.app.config.saveAdminModelsConfig(parsed);
                        this.app.snackbar.start('mj', '保存中…');
                        this.app.snackbar.succeed('mj', '✓ models.json を保存しました');
                        await this._renderModelSection();
                        return;
                    }
                    if (btn.dataset.saveJson === 'prompts') {
                        const parsed = JSON.parse(panel.querySelector('#adm-prompts-json').value);
                        if (!parsed.prompts) throw new Error('prompts.json には prompts オブジェクトが必要です');
                        await this.app.config.saveAdminPromptsConfig(parsed);
                        this.app.snackbar.start('pj', '保存中…');
                        this.app.snackbar.succeed('pj', '✓ prompts.json を保存しました');
                        await this._renderPromptSection();
                        return;
                    }
                    if (btn.dataset.saveJson === 'app') {
                        const parsed = JSON.parse(panel.querySelector('#adm-app-json').value);
                        await this.app.config.saveAdminAppConfig(parsed);
                        await this.app.flags.load();
                        this.app.snackbar.start('aj', '保存中…');
                        this.app.snackbar.succeed('aj', '✓ app-config.json を保存しました');
                        return;
                    }
                } catch (e) { alert('JSON形式が不正です: ' + e.message); }
            });
        });

        panel.querySelector('#adm-close').addEventListener('click', () => panel.classList.add('hidden'));
    }

    _esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }
}

window.SettingsComponent = SettingsComponent;
