(() => {
  'use strict';

  // ============================================================
  // 定数
  // ============================================================
  const STORE_PREFIX = 'astroinsight:';

  const FALLBACK_APP_CONFIG = {
    app: { name: 'AstroInsight', description: '星の波を読むAI占星術アプリ' },
    limits: { guestTrialLimit: 3 },
    ads: { enabled: false },
    admin: { pinEnabled: false },
    ai: { temperature: 0.85, topP: 0.9, maxTokens: 4500 },
    forecast: { defaultGranularity: 'daily', showList: false, selectedOnly: true, requireAstroReason: true, requireWaveReading: true, prioritizePluto: true }
  };
  const FALLBACK_MODELS = { defaultModelId: 'gemini-2.5-flash', providers: [], models: [] };
  const FALLBACK_PROMPTS = { prompts: {} };

  const PLANETS = [
    ['Sun','太陽','☉'], ['Moon','月','☽'], ['Mercury','水星','☿'], ['Venus','金星','♀'], ['Mars','火星','♂'],
    ['Jupiter','木星','♃'], ['Saturn','土星','♄'], ['Uranus','天王星','♅'], ['Neptune','海王星','♆'], ['Pluto','冥王星','♇'], ['ASC','ASC','ASC'], ['MC','MC','MC']
  ];
  const PLANET_MEANINGS = {
    Sun:'本質・自我・人生の方向性', Moon:'感情・無意識・幼少期', Mercury:'思考・コミュニケーション',
    Venus:'愛・美・喜び・価値観', Mars:'行動・闘争・情熱', Jupiter:'拡大・幸運・成長',
    Saturn:'試練・責任・構造', Uranus:'革新・自由・突発', Neptune:'夢・霊性・幻想',
    Pluto:'変容・破壊と再生・運命的転機', ASC:'第一印象・人生のスタート', MC:'社会的役割・キャリア'
  };
  const SIGNS = ['牡羊座','牡牛座','双子座','蟹座','獅子座','乙女座','天秤座','蠍座','射手座','山羊座','水瓶座','魚座'];
  const SIGN_SYMBOLS = ['♈','♉','♊','♋','♌','♍','♎','♏','♐','♑','♒','♓'];
  const HOUSE_MEANINGS = {
    1:'自分自身・印象・始まり',2:'お金・価値観・才能',3:'会話・学び・連絡',4:'家・安心・土台',5:'恋愛・表現・楽しみ',6:'仕事習慣・健康・日課',
    7:'対人関係・パートナー',8:'深い関係・共有・変容',9:'学び・旅・視野拡大',10:'仕事・社会的役割・評価',11:'仲間・未来・コミュニティ',12:'内省・癒し・手放し'
  };
  const ASPECTS = [
    { name:'合', en:'conjunction', angle:0,   orb:8, color:'#fbbf24' },
    { name:'対', en:'opposition',  angle:180, orb:8, color:'#fb7185' },
    { name:'トライン', en:'trine', angle:120, orb:6, color:'#34d399' },
    { name:'スクエア', en:'square', angle:90, orb:6, color:'#ef4444' },
    { name:'セクスタイル', en:'sextile', angle:60, orb:4, color:'#60a5fa' }
  ];
  const CITY_TABLE = {
    '東京':[35.6895,139.6917], '大阪':[34.6937,135.5023], '京都':[35.0116,135.7681],
    '横浜':[35.4437,139.6380], '名古屋':[35.1815,136.9066], '福岡':[33.5904,130.4017],
    '札幌':[43.0618,141.3545], '仙台':[38.2682,140.8694], '広島':[34.3853,132.4553],
    '神戸':[34.6901,135.1955], '那覇':[26.2124,127.6809]
  };
  const CORE_CONSTRAINT = '【重要】ポジティブでポップな言葉遣いをベースとしつつ、ネガティブな側面や気をつけるべき点も、ユーザーが前向きに対処できるよう具体的なアドバイスと共に含めてください。\n【重要】冥王星がもたらす長期的な変容、運命的な転機、深遠な影響（位置関係やアスペクト）を非常に重要視し、詳細に分析・解説に必ず織り込んでください。\n【重要】専門用語は避け、絵文字を適切に使用してください。';

  // ============================================================
  // 状態
  // ============================================================
  const state = {
    tab: 'today',
    profile: null,
    appConfig: FALLBACK_APP_CONFIG,
    modelConfig: FALLBACK_MODELS,
    prompts: FALLBACK_PROMPTS,
    adminOpen: false,
    forecastGranularity: 'daily',
    selectedForecastIndex: 0,
    forecastData: null,
    forecastChart: null,
    todayMode: 'today',
    chatContext: null,
    chats: [],
    // 追加（要件§v5 補完）
    user: null,                 // { uid, name, email, isAdmin } / null=ゲスト
    uidPrefix: 'guest_temp',    // §2 §19 IndexedDBキープレフィックス
    proxyToken: null,           // §5
    horoscopeMode: 'dual',      // §8 'natal'|'dual'
    horoscopeRenderer: null,    // §8 描画状態
    onboardingStep: 0,          // §9
    natalCache: null,           // §7 ネイタル分析テキスト
    friends: [],                // §13
    currentFriend: null,        // §13 詳細表示中の友達
    activeTasks: 0,             // §17 並列タスク数
    wakeLock: null              // §1
  };

  const $ = (id) => document.getElementById(id);
  const esc = (s='') => String(s).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  const md = (s='') => (window.marked ? window.marked.parse(String(s||'')) : esc(s));
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const uidp = () => state.uidPrefix;

  // ============================================================
  // IndexedDB（§19 ラッパー統一）
  // ============================================================
  const DB_NAME = 'astroinsight_admin_store';
  const DB_STORE = 'kv';
  const DB_FRIENDS = 'friends';
  const DB_CACHE = 'cache';
  const DB_AUTH = 'auth';
  const DB_VERSION = 2;

  function openDb() {
    return new Promise((resolve, reject) => {
      if (!('indexedDB' in window)) return resolve(null);
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(DB_STORE))   db.createObjectStore(DB_STORE);
        if (!db.objectStoreNames.contains(DB_FRIENDS)) db.createObjectStore(DB_FRIENDS);
        if (!db.objectStoreNames.contains(DB_CACHE))   db.createObjectStore(DB_CACHE);
        if (!db.objectStoreNames.contains(DB_AUTH))    db.createObjectStore(DB_AUTH);
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  async function idbSet(key, value, storeName=DB_STORE) {
    try { const db = await openDb(); if (!db) return; const tx = db.transaction(storeName, 'readwrite'); tx.objectStore(storeName).put(value, key); } catch {}
  }
  async function idbGet(key, storeName=DB_STORE) {
    try {
      const db = await openDb(); if (!db) return null;
      return await new Promise((resolve) => {
        const tx = db.transaction(storeName, 'readonly');
        const req = tx.objectStore(storeName).get(key);
        req.onsuccess = () => resolve(req.result == null ? null : req.result);
        req.onerror = () => resolve(null);
      });
    } catch { return null; }
  }
  async function idbRemove(key, storeName=DB_STORE) {
    try { const db = await openDb(); if (!db) return; const tx = db.transaction(storeName, 'readwrite'); tx.objectStore(storeName).delete(key); } catch {}
  }
  async function idbGetAll() {
    try {
      const db = await openDb(); if (!db) return {};
      return await new Promise((resolve) => {
        const tx = db.transaction(DB_STORE, 'readonly');
        const st = tx.objectStore(DB_STORE);
        const keysReq = st.getAllKeys();
        const valsReq = st.getAll();
        tx.oncomplete = () => {
          const out = {};
          (keysReq.result || []).forEach((k, i) => out[k] = valsReq.result[i]);
          resolve(out);
        };
        tx.onerror = () => resolve({});
      });
    } catch { return {}; }
  }
  async function idbAllKeys(storeName=DB_CACHE) {
    try {
      const db = await openDb(); if (!db) return [];
      return await new Promise((resolve) => {
        const tx = db.transaction(storeName, 'readonly');
        const req = tx.objectStore(storeName).getAllKeys();
        req.onsuccess = () => resolve(req.result || []);
        req.onerror = () => resolve([]);
      });
    } catch { return []; }
  }
  async function hydrateFromIndexedDb() {
    const all = await idbGetAll();
    Object.entries(all).forEach(([key, value]) => {
      try { if (localStorage.getItem(STORE_PREFIX + key) == null) localStorage.setItem(STORE_PREFIX + key, JSON.stringify(value)); } catch {}
    });
  }

  // ============================================================
  // store: localStorage + IndexedDB 二重保存（既存維持）
  // ============================================================
  const store = {
    get(key, fallback=null) { try { const v = localStorage.getItem(STORE_PREFIX + key); return v ? JSON.parse(v) : fallback; } catch { return fallback; } },
    set(key, value) { try { localStorage.setItem(STORE_PREFIX + key, JSON.stringify(value)); } catch {} idbSet(key, value); },
    remove(key) { try { localStorage.removeItem(STORE_PREFIX + key); } catch {} idbRemove(key); }
  };

  // UIDプレフィックス対応のスコープ付きストア（§2 §19）
  const pStore = {
    _k: (key) => uidp() + '::' + key,
    get(key, fallback=null) { return store.get(pStore._k(key), fallback); },
    set(key, value) { store.set(pStore._k(key), value); },
    remove(key) { store.remove(pStore._k(key)); }
  };

  // 友達ストア（§13）
  const friendsDb = {
    async put(friendId, data) { return idbSet(uidp() + '::' + friendId, data, DB_FRIENDS); },
    async get(friendId) { return idbGet(uidp() + '::' + friendId, DB_FRIENDS); },
    async remove(friendId) { return idbRemove(uidp() + '::' + friendId, DB_FRIENDS); },
    async list() {
      try {
        const db = await openDb(); if (!db) return [];
        return await new Promise((resolve) => {
          const out = [];
          const tx = db.transaction(DB_FRIENDS, 'readonly');
          const req = tx.objectStore(DB_FRIENDS).openCursor();
          req.onsuccess = (e) => {
            const cur = e.target.result;
            if (cur) {
              if (typeof cur.key === 'string' && cur.key.startsWith(uidp() + '::')) out.push(cur.value);
              cur.continue();
            } else resolve(out);
          };
          req.onerror = () => resolve([]);
        });
      } catch { return []; }
    }
  };

  // キャッシュストア（§19）
  const cacheDb = {
    async get(key) { return idbGet(uidp() + '::' + key, DB_CACHE); },
    async set(key, value) { return idbSet(uidp() + '::' + key, value, DB_CACHE); },
    async del(key) { return idbRemove(uidp() + '::' + key, DB_CACHE); }
  };

  // 認証グローバル領域（§2）
  const authDb = {
    async get(key) { return idbGet(key, DB_AUTH); },
    async set(key, value) { return idbSet(key, value, DB_AUTH); },
    async del(key) { return idbRemove(key, DB_AUTH); }
  };

  // ============================================================
  // toast / snackbar（§17 進捗表示）
  // ============================================================
  const toast = (msg) => { const t = $('toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(t._timer); t._timer = setTimeout(() => t.classList.remove('show'), 2800); };

  const snackbar = {
    tasks: new Map(),
    _host() {
      let el = $('snackbarHost');
      if (!el) {
        el = document.createElement('div');
        el.id = 'snackbarHost';
        el.className = 'snackbar-host';
        document.body.appendChild(el);
      }
      return el;
    },
    start(taskId, label) {
      const host = this._host();
      const node = document.createElement('div');
      node.className = 'snack snack-info';
      node.innerHTML = `<span class="snack-spin">◐</span><span class="snack-label">${esc(label||'生成中')}</span>`;
      host.appendChild(node);
      this.tasks.set(taskId, { node, label });
      return taskId;
    },
    update(taskId, label) {
      const t = this.tasks.get(taskId); if (!t) return;
      t.node.querySelector('.snack-label').textContent = label;
    },
    succeed(taskId, label) {
      const t = this.tasks.get(taskId); if (!t) return;
      t.node.className = 'snack snack-ok';
      t.node.innerHTML = `<span>✓</span><span class="snack-label">${esc(label||'更新しました')}</span>`;
      setTimeout(() => this._remove(taskId), 2000);
    },
    fail(taskId, msg, retryFn) {
      const t = this.tasks.get(taskId); if (!t) return;
      t.node.className = 'snack snack-err';
      t.node.innerHTML = `<span>⚠</span><span class="snack-label">${esc(msg||'エラー')}</span><button class="snack-retry">再試行</button><button class="snack-close">×</button>`;
      const [retry, close] = t.node.querySelectorAll('button');
      retry.onclick = () => { this._remove(taskId); if (typeof retryFn === 'function') retryFn(); };
      close.onclick = () => this._remove(taskId);
    },
    _remove(taskId) {
      const t = this.tasks.get(taskId); if (!t) return;
      t.node.remove(); this.tasks.delete(taskId);
    }
  };

  // ============================================================
  // 認証スタブ（§2）
  // ============================================================
  const auth = {
    async init() {
      // §2: アプリ起動時に guest_temp 領域をクリア（前回終了時に残ってる場合の保険）
      await this._clearGuestTemp();
      // 復元
      const cached = await authDb.get('cached_user');
      if (cached && cached.uid) {
        state.user = cached;
        state.uidPrefix = cached.uid;
      } else {
        state.user = null;
        state.uidPrefix = 'guest_temp';
      }
      // Firebase 設定があれば動的読込
      const fbCfg = await authDb.get('firebase_config');
      if (fbCfg && fbCfg.apiKey && fbCfg.projectId) {
        await this._tryInitFirebase(fbCfg).catch(() => {});
      }
    },
    async _tryInitFirebase(cfg) {
      try {
        const appMod = await import('https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js');
        const authMod = await import('https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js');
        const fbApp = appMod.initializeApp({ apiKey: cfg.apiKey, authDomain: cfg.authDomain, projectId: cfg.projectId });
        this._fb = { auth: authMod.getAuth(fbApp), mod: authMod };
        authMod.onAuthStateChanged(this._fb.auth, async (u) => {
          if (u) {
            let isAdmin = false;
            try { const tok = await u.getIdTokenResult(); isAdmin = !!tok.claims.admin; } catch {}
            state.user = { uid: u.uid, name: u.displayName||'', email: u.email||'', photoURL: u.photoURL||'', isAdmin };
            state.uidPrefix = u.uid;
            await authDb.set('cached_user', state.user);
            await proxy.fetchToken(u.uid);
            updateAuthStatus();
          } else {
            state.user = null;
            state.uidPrefix = 'guest_temp';
            updateAuthStatus();
          }
        });
      } catch (e) { console.warn('[Auth] Firebase init failed:', e.message); }
    },
    async signInGoogle() {
      if (this._fb) {
        const provider = new this._fb.mod.GoogleAuthProvider();
        await this._fb.mod.signInWithPopup(this._fb.auth, provider);
        return;
      }
      toast('Firebase認証は管理用設定で設定後に有効になります');
    },
    async signOut() {
      if (this._fb) { await this._fb.mod.signOut(this._fb.auth); return; }
      state.user = null;
      state.uidPrefix = 'guest_temp';
      await authDb.del('cached_user');
      updateAuthStatus();
    },
    isLoggedIn() { return !!state.user; },
    isAdmin() { return !!state.user?.isAdmin; },
    currentUid() { return state.user?.uid || null; },

    async remainingTrials() {
      if (this.isLoggedIn()) return Infinity;
      const used = (await authDb.get('guest_trial_used')) || 0;
      const max = state.appConfig.limits?.guestTrialLimit ?? 3;
      return Math.max(0, max - used);
    },
    async consumeTrial() {
      if (this.isLoggedIn()) return true;
      const used = (await authDb.get('guest_trial_used')) || 0;
      const max = state.appConfig.limits?.guestTrialLimit ?? 3;
      if (used >= max) return false;
      await authDb.set('guest_trial_used', used + 1);
      return true;
    },
    async resetTrial() { await authDb.set('guest_trial_used', 0); },

    async _clearGuestTemp() {
      try {
        const db = await openDb(); if (!db) return;
        const stores = [DB_FRIENDS, DB_CACHE];
        await new Promise((resolve) => {
          const tx = db.transaction(stores, 'readwrite');
          stores.forEach((s) => {
            const o = tx.objectStore(s);
            const req = o.openCursor();
            req.onsuccess = (e) => {
              const cur = e.target.result;
              if (cur) {
                if (typeof cur.key === 'string' && cur.key.startsWith('guest_temp::')) cur.delete();
                cur.continue();
              }
            };
          });
          tx.oncomplete = () => resolve();
          tx.onerror = () => resolve();
        });
      } catch {}
    },

    async migrateGuestData() {
      if (!this.isLoggedIn()) return;
      const uid = this.currentUid();
      try {
        const db = await openDb(); if (!db) return;
        const stores = [DB_FRIENDS, DB_CACHE];
        await new Promise((resolve) => {
          const tx = db.transaction(stores, 'readwrite');
          stores.forEach((s) => {
            const o = tx.objectStore(s);
            const req = o.openCursor();
            req.onsuccess = (e) => {
              const cur = e.target.result;
              if (cur) {
                if (typeof cur.key === 'string' && cur.key.startsWith('guest_temp::')) {
                  const newKey = uid + '::' + cur.key.substring('guest_temp::'.length);
                  o.put(cur.value, newKey);
                }
                cur.continue();
              }
            };
          });
          tx.oncomplete = () => resolve();
          tx.onerror = () => resolve();
        });
        await this._clearGuestTemp();
        toast('ゲストデータをアカウントに移行しました');
      } catch (e) { toast('移行失敗: ' + e.message); }
    }
  };

  function updateAuthStatus() {
    const el = $('authStatus'); if (!el) return;
    if (state.user) el.textContent = `${state.user.name || state.user.email || 'アカウント'}${state.user.isAdmin ? ' (管理者)' : ''}`;
    else el.textContent = state.profile ? `${state.profile.name} / ローカル保存` : 'ゲスト';
  }

  // ============================================================
  // プロキシスタブ（§5）
  // ============================================================
  const proxy = {
    baseUrl: null,
    token: null,
    async init() {
      const cfg = (await authDb.get('admin_proxy')) || {};
      this.baseUrl = cfg.baseUrl || null;
      this.token = (await authDb.get('proxy_token')) || null;
    },
    async setBaseUrl(url) {
      const cfg = (await authDb.get('admin_proxy')) || {};
      cfg.baseUrl = url;
      await authDb.set('admin_proxy', cfg);
      this.baseUrl = url;
    },
    isConfigured() { return !!this.baseUrl; },
    async fetchToken(uid) {
      if (!this.baseUrl) return null;
      try {
        const r = await fetch(this.baseUrl.replace(/\/$/, '') + '/auth/token', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ uid })
        });
        if (!r.ok) throw new Error('proxy token: ' + r.status);
        const data = await r.json();
        this.token = data.token;
        await authDb.set('proxy_token', this.token);
        return this.token;
      } catch (e) { console.warn('[Proxy] token failed:', e.message); return null; }
    },
    canUseProxy(modelDef) {
      return !!(auth.isLoggedIn() && this.baseUrl && this.token && modelDef?.proxySupported);
    },
    buildRequest() {
      return { url: this.baseUrl, token: this.token };
    }
  };

  // ============================================================
  // フィーチャーフラグ関数（§3 §22）
  // ============================================================
  function ADS_ENABLED(uid) {
    if (auth.isAdmin()) return false; // 要件§2 管理者は広告非表示
    return !!state.appConfig.ads?.enabled;
  }
  function PREMIUM_ENABLED(uid) {
    // 要件§3 §22: スタブ・常にtrue
    return state.appConfig.premium?.enabled !== false;
  }

  // ============================================================
  // AI Worker Manager（§17 並列タスク）
  // ============================================================
  const workerMgr = {
    max: 4,
    active: new Map(),
    submit(taskId, payload, handlers) {
      let w;
      try { w = new Worker('assets/worker.js'); }
      catch (e) { return this._fallbackBlob(taskId, payload, handlers); }
      this.active.set(taskId, w);
      w.onmessage = (e) => {
        const msg = e.data;
        if (msg.type === 'chunk') handlers.onChunk?.(msg);
        else if (msg.type === 'done') { handlers.onDone?.(msg); this._terminate(taskId); }
        else if (msg.type === 'error') { handlers.onError?.(msg); this._terminate(taskId); }
      };
      w.onerror = (e) => { handlers.onError?.({ message: e.message || 'Worker error' }); this._terminate(taskId); };
      w.postMessage({ action: 'generate', ...payload });
    },
    async _fallbackBlob(taskId, payload, handlers) {
      try {
        const res = await fetch('assets/worker.js'); const code = await res.text();
        const blob = new Blob([code], { type: 'application/javascript' });
        const w = new Worker(URL.createObjectURL(blob));
        this.active.set(taskId, w);
        w.onmessage = (e) => {
          const msg = e.data;
          if (msg.type === 'chunk') handlers.onChunk?.(msg);
          else if (msg.type === 'done') { handlers.onDone?.(msg); this._terminate(taskId); }
          else if (msg.type === 'error') { handlers.onError?.(msg); this._terminate(taskId); }
        };
        w.postMessage({ action: 'generate', ...payload });
      } catch (e) { handlers.onError?.({ message: 'Worker起動失敗: ' + e.message }); }
    },
    _terminate(taskId) {
      const w = this.active.get(taskId);
      if (w) { try { w.terminate(); } catch {} this.active.delete(taskId); }
    }
  };

  // ============================================================
  // 統合 AI 生成エントリ（§20 ルーティング）
  // ============================================================
  async function startGeneration(opts) {
    const { taskId, taskLabel, prompt, isJson, onProgress, onDone, onError } = opts;

    // 試用回数（§2）
    if (!await auth.consumeTrial()) {
      onError?.('ログインしてください（無料試用は3回までです）');
      toast('ログインしてください（無料試用は3回までです）');
      return;
    }

    // モデル決定
    const modelId = pStore.get('selected_model_id') || state.modelConfig.defaultModelId
                  || state.modelConfig.models?.[0]?.id;
    const modelDef = (state.modelConfig.models || []).find(m => m.id === modelId);
    if (!modelDef) {
      onError?.('モデルが見つかりません: ' + modelId);
      return;
    }
    const provider = (state.modelConfig.providers || []).find(p => p.id === modelDef.providerId);
    if (!provider) {
      onError?.('プロバイダーが見つかりません: ' + modelDef.providerId);
      return;
    }
    const usingProxy = proxy.canUseProxy(modelDef);
    const apiKey = usingProxy ? '' : getProviderKey(provider);
    if (!usingProxy && !apiKey) {
      onError?.(`APIキー未設定です。管理用設定で「${provider.name}」のAPIキーを入力してください。`);
      toast(`${provider.name}のAPIキーを管理用設定に登録してください`);
      return;
    }

    // スナックバー（§17）
    snackbar.start(taskId, taskLabel || '生成中…');
    state.activeTasks++;
    acquireWakeLock();

    workerMgr.submit(taskId, {
      provider, modelDef, prompt, isJson, apiKey,
      proxy: usingProxy ? proxy.buildRequest() : null
    }, {
      onChunk: (m) => { onProgress?.(m.text); },
      onDone:  (m) => { onDone?.(m.text); snackbar.succeed(taskId, '✓ ' + (taskLabel||'生成完了')); state.activeTasks--; if (state.activeTasks <= 0) releaseWakeLock(); },
      onError: (m) => { onError?.(m.message); snackbar.fail(taskId, m.message, () => startGeneration(opts)); state.activeTasks--; if (state.activeTasks <= 0) releaseWakeLock(); }
    });
  }

  async function acquireWakeLock() {
    if (state.wakeLock || !('wakeLock' in navigator)) return;
    try { state.wakeLock = await navigator.wakeLock.request('screen'); } catch {}
  }
  function releaseWakeLock() {
    if (state.wakeLock) { try { state.wakeLock.release(); } catch {} state.wakeLock = null; }
  }

  // ============================================================
  // 天体計算（§8）
  // ============================================================
  const astrology = {
    longitudes(date) {
      if (typeof Astronomy !== 'undefined') {
        const time = Astronomy.MakeTime(date);
        const out = {};
        const map = { Sun:'Sun', Moon:'Moon', Mercury:'Mercury', Venus:'Venus', Mars:'Mars',
          Jupiter:'Jupiter', Saturn:'Saturn', Uranus:'Uranus', Neptune:'Neptune', Pluto:'Pluto' };
        for (const k of Object.keys(map)) {
          try {
            let lon;
            if (k === 'Moon') lon = Astronomy.EclipticGeoMoon(time).lon;
            else if (k === 'Sun') lon = Astronomy.SunPosition(time).elon;
            else { const v = Astronomy.GeoVector(Astronomy.Body[k], time, true); lon = Astronomy.Ecliptic(v).elon; }
            out[k] = ((lon % 360) + 360) % 360;
          } catch { out[k] = 0; }
        }
        return out;
      }
      // astronomy-engine なし：日数経過に基づく概算
      const t = (date.getTime() - Date.UTC(2000, 0, 1)) / 86400000;
      const speeds = { Sun:0.985, Moon:13.176, Mercury:1.4, Venus:1.2, Mars:0.524,
        Jupiter:0.083, Saturn:0.034, Uranus:0.012, Neptune:0.006, Pluto:0.004 };
      const out = {};
      for (const k of Object.keys(speeds)) out[k] = (((speeds[k] * t) % 360) + 360) % 360;
      return out;
    },
    houses(date, lat, lon) {
      // 簡易：等ハウス（Equal House）。astronomy-engine 不要のJS算術で ASC/MCを算出。
      const eps = 23.4393 * Math.PI/180;
      const phi = lat * Math.PI/180;
      const jd = (date.getTime()/86400000) + 2440587.5;
      const T = (jd - 2451545.0) / 36525;
      let gmst = 280.46061837 + 360.98564736629*(jd-2451545.0) + 0.000387933*T*T - (T*T*T)/38710000;
      gmst = ((gmst % 360) + 360) % 360;
      const lst = (gmst + lon) % 360;
      const ramc = lst * Math.PI/180;
      let mcLon = Math.atan2(Math.sin(ramc), Math.cos(ramc)*Math.cos(eps)) * 180/Math.PI;
      mcLon = ((mcLon % 360) + 360) % 360;
      let ascLon = Math.atan2(-Math.cos(ramc), Math.sin(eps)*Math.tan(phi) + Math.cos(eps)*Math.sin(ramc)) * 180/Math.PI;
      ascLon = ((ascLon % 360) + 360) % 360;
      const cusps = [];
      for (let i=0; i<12; i++) cusps.push((ascLon + i*30) % 360);
      return { ASC: ascLon, MC: mcLon, cusps };
    },
    cityToLatLon(text) {
      if (!text) return [35.6895, 139.6917];
      for (const k of Object.keys(CITY_TABLE)) if (text.includes(k)) return CITY_TABLE[k];
      return [35.6895, 139.6917];
    },
    houseOf(lon, cusps) {
      const norm = ((lon % 360) + 360) % 360;
      for (let i=0; i<12; i++) {
        const a = cusps[i], b = cusps[(i+1)%12];
        const inH = (a <= b) ? (norm >= a && norm < b) : (norm >= a || norm < b);
        if (inH) return i+1;
      }
      return 1;
    },
    computeChart(profile, when) {
      const birthDate = profile?.birth || '2000-01-01';
      const birthTime = profile?.time || '12:00';
      const target = when || new Date(`${birthDate}T${birthTime}:00`);
      const [lat, lng] = this.cityToLatLon(profile?.place);
      const longs = this.longitudes(target);
      const houses = this.houses(target, lat, lng);
      const planets = {};
      for (const p of PLANETS) {
        const key = p[0];
        if (key === 'ASC') {
          planets[key] = { key, jp:p[1], symbol:p[2], longitude: houses.ASC, sign: SIGNS[Math.floor(houses.ASC/30)], degree: +(houses.ASC%30).toFixed(2), house: 1 };
        } else if (key === 'MC') {
          planets[key] = { key, jp:p[1], symbol:p[2], longitude: houses.MC, sign: SIGNS[Math.floor(houses.MC/30)], degree: +(houses.MC%30).toFixed(2), house: this.houseOf(houses.MC, houses.cusps) };
        } else {
          const lon = longs[key] || 0;
          planets[key] = { key, jp:p[1], symbol:p[2], longitude: lon, sign: SIGNS[Math.floor(lon/30)], degree: +(lon%30).toFixed(2), house: this.houseOf(lon, houses.cusps) };
        }
      }
      return { target, lat, lng, planets, ASC: houses.ASC, MC: houses.MC, cusps: houses.cusps };
    },
    detectAspects(chartA, chartB, isSelf) {
      const out = [];
      const keysA = Object.keys(chartA.planets);
      const keysB = Object.keys(chartB.planets);
      for (let i=0; i<keysA.length; i++) {
        for (let j = (isSelf ? i+1 : 0); j<keysB.length; j++) {
          if (isSelf && keysA[i] === keysB[j]) continue;
          const a = chartA.planets[keysA[i]].longitude;
          const b = chartB.planets[keysB[j]].longitude;
          let d = Math.abs(a - b); if (d > 180) d = 360 - d;
          for (const asp of ASPECTS) {
            if (Math.abs(d - asp.angle) <= asp.orb) {
              out.push({ p1: keysA[i], p2: keysB[j], aspect: asp.name, en: asp.en, angle: asp.angle, orb: +(Math.abs(d - asp.angle)).toFixed(2), color: asp.color });
            }
          }
        }
      }
      return out;
    }
  };

  // ============================================================
  // ホロスコープ描画（§8 SVG・タップ・モード切替）
  // ============================================================
  const horoscope = {
    state: { mode:'dual', chartA:null, chartB:null, aspects:[], selected:null },
    setCharts(chartA, chartB, mode) {
      this.state.chartA = chartA;
      this.state.chartB = chartB;
      this.state.mode = mode || 'dual';
      this._computeAspects();
      this.render();
    },
    setMode(m) { this.state.mode = m; this._computeAspects(); this.render(); },
    _computeAspects() {
      if (!this.state.chartA) { this.state.aspects = []; return; }
      if (this.state.mode === 'dual' && this.state.chartB) {
        this.state.aspects = astrology.detectAspects(this.state.chartA, this.state.chartB, false);
      } else {
        this.state.aspects = astrology.detectAspects(this.state.chartA, this.state.chartA, true);
      }
    },
    _lonToAngle(lon) {
      const ascLon = (this.state.chartA && this.state.chartA.ASC) || 0;
      const rel = (((lon - ascLon) % 360) + 360) % 360;
      const deg = 180 - rel;
      return deg * Math.PI/180;
    },
    polar(cx, cy, r, ang) { return [cx + r*Math.cos(ang), cy + r*Math.sin(ang)]; },
    render() {
      const svg = $('horoscopeSvg');
      if (!svg || !this.state.chartA) return;
      const size = 320; const cx = size/2, cy = size/2;
      const rOuter = size*0.46, rZodiac = size*0.40, rInner = size*0.28;
      const rPlanetA = size*0.34, rPlanetB = size*0.42;

      svg.setAttribute('viewBox', `0 0 ${size} ${size}`);
      svg.setAttribute('width', '100%'); svg.setAttribute('height', size);
      while (svg.firstChild) svg.removeChild(svg.firstChild);
      const NS = 'http://www.w3.org/2000/svg';

      // 背景円
      const bg = document.createElementNS(NS, 'circle');
      bg.setAttribute('cx', cx); bg.setAttribute('cy', cy); bg.setAttribute('r', rOuter);
      bg.setAttribute('fill', 'rgba(255,255,255,0.04)'); bg.setAttribute('stroke', 'rgba(255,255,255,0.28)');
      svg.appendChild(bg);

      // ハウスカスプ線
      const cusps = this.state.chartA.cusps || [];
      for (let i=0; i<12; i++) {
        const ang = this._lonToAngle(cusps[i] || (i*30));
        const [x1,y1] = this.polar(cx, cy, rInner, ang);
        const [x2,y2] = this.polar(cx, cy, rOuter, ang);
        const ln = document.createElementNS(NS, 'line');
        ln.setAttribute('x1', x1); ln.setAttribute('y1', y1);
        ln.setAttribute('x2', x2); ln.setAttribute('y2', y2);
        ln.setAttribute('stroke', i===0 ? '#8b5cf6' : 'rgba(255,255,255,0.22)');
        ln.setAttribute('stroke-width', i===0 ? 2 : 1);
        svg.appendChild(ln);

        const cuspMid = ((cusps[i] || (i*30)) + 15) % 360;
        const [hx, hy] = this.polar(cx, cy, rInner-10, this._lonToAngle(cuspMid));
        const t = document.createElementNS(NS, 'text');
        t.setAttribute('x', hx); t.setAttribute('y', hy);
        t.setAttribute('font-size', 10); t.setAttribute('fill', '#e9d5ff');
        t.setAttribute('text-anchor','middle'); t.setAttribute('dominant-baseline','middle');
        t.setAttribute('font-weight','900'); t.textContent = (i+1).toString();
        svg.appendChild(t);
      }

      // サイン記号
      for (let i=0; i<12; i++) {
        const ang = this._lonToAngle(i*30 + 15);
        const [x, y] = this.polar(cx, cy, rZodiac+8, ang);
        const t = document.createElementNS(NS, 'text');
        t.setAttribute('x', x); t.setAttribute('y', y);
        t.setAttribute('font-size', 13); t.setAttribute('fill', '#cbd5e1');
        t.setAttribute('text-anchor','middle'); t.setAttribute('dominant-baseline','middle');
        t.textContent = SIGN_SYMBOLS[i];
        svg.appendChild(t);
      }

      // 内側円
      const innerC = document.createElementNS(NS, 'circle');
      innerC.setAttribute('cx', cx); innerC.setAttribute('cy', cy); innerC.setAttribute('r', rInner);
      innerC.setAttribute('fill', 'none'); innerC.setAttribute('stroke', 'rgba(255,255,255,0.18)');
      svg.appendChild(innerC);

      // アスペクトライン
      for (const a of this.state.aspects) {
        const cA = this.state.chartA.planets[a.p1];
        const cB = (this.state.mode === 'dual' && this.state.chartB)
                 ? this.state.chartB.planets[a.p2]
                 : this.state.chartA.planets[a.p2];
        if (!cA || !cB) continue;
        const [x1,y1] = this.polar(cx, cy, rInner, this._lonToAngle(cA.longitude));
        const [x2,y2] = this.polar(cx, cy, rInner, this._lonToAngle(cB.longitude));
        const ln = document.createElementNS(NS, 'line');
        ln.setAttribute('x1', x1); ln.setAttribute('y1', y1);
        ln.setAttribute('x2', x2); ln.setAttribute('y2', y2);
        ln.setAttribute('stroke', a.color); ln.setAttribute('stroke-width', 1); ln.setAttribute('opacity', 0.55);
        svg.appendChild(ln);
      }

      // 天体A（内側）
      this._drawPlanets(svg, NS, this.state.chartA, rPlanetA, '#fde68a', 'A', cx, cy);
      // 天体B（外側・dualのみ）
      if (this.state.mode === 'dual' && this.state.chartB) {
        const ringB = document.createElementNS(NS, 'circle');
        ringB.setAttribute('cx', cx); ringB.setAttribute('cy', cy); ringB.setAttribute('r', rOuter*0.92);
        ringB.setAttribute('fill', 'none'); ringB.setAttribute('stroke', 'rgba(236,72,153,0.45)');
        ringB.setAttribute('stroke-dasharray', '3 3');
        svg.appendChild(ringB);
        this._drawPlanets(svg, NS, this.state.chartB, rPlanetB, '#bfdbfe', 'B', cx, cy);
      }
    },
    _drawPlanets(svg, NS, chart, r, color, ring, cx, cy) {
      for (const p of PLANETS) {
        const pl = chart.planets[p[0]]; if (!pl) continue;
        const ang = this._lonToAngle(pl.longitude);
        const [x, y] = this.polar(cx, cy, r, ang);
        // タップ領域
        const hit = document.createElementNS(NS, 'circle');
        hit.setAttribute('cx', x); hit.setAttribute('cy', y); hit.setAttribute('r', 13);
        hit.setAttribute('fill', 'rgba(255,255,255,0.001)');
        hit.style.cursor = 'pointer';
        hit.addEventListener('click', (e) => { e.stopPropagation(); this._showTooltip(p[0], ring); });
        // 背景の小円
        const bg = document.createElementNS(NS, 'circle');
        bg.setAttribute('cx', x); bg.setAttribute('cy', y); bg.setAttribute('r', 11);
        bg.setAttribute('fill', 'rgba(15,23,42,0.6)');
        bg.setAttribute('stroke', this.state.selected===p[0] ? '#fb7185' : color);
        bg.setAttribute('stroke-width', this.state.selected===p[0] ? 2 : 1.2);
        // シンボル
        const sym = document.createElementNS(NS, 'text');
        sym.setAttribute('x', x); sym.setAttribute('y', y+1);
        sym.setAttribute('font-size', 13); sym.setAttribute('fill', color);
        sym.setAttribute('text-anchor','middle'); sym.setAttribute('dominant-baseline','middle');
        sym.setAttribute('font-weight','900');
        sym.textContent = p[2];
        svg.appendChild(bg); svg.appendChild(sym); svg.appendChild(hit);
      }
    },
    _showTooltip(planetKey, ring) {
      this.state.selected = planetKey;
      this.render();
      const chart = (ring === 'B' && this.state.chartB) ? this.state.chartB : this.state.chartA;
      const pl = chart.planets[planetKey]; if (!pl) return;
      const aspects = this.state.aspects.filter(a => a.p1 === planetKey || a.p2 === planetKey).slice(0, 5);
      const aspectsHtml = aspects.length
        ? aspects.map(a => `<li>${esc(a.p1)} <span style="color:${a.color}">${esc(a.aspect)}(${a.angle}°)</span> ${esc(a.p2)} オーブ${a.orb}°</li>`).join('')
        : '<li class="muted small">主要アスペクトなし</li>';
      const meaning = PLANET_MEANINGS[planetKey] || '';
      const ringLabel = ring === 'B' ? '外側（トランジット/相手）' : 'ネイタル';
      const symIdx = SIGNS.indexOf(pl.sign);
      const signSym = symIdx >= 0 ? SIGN_SYMBOLS[symIdx] : '';
      const html = `
        <div class="tooltip-card">
          <div class="between"><div><b style="font-size:18px">${esc(pl.symbol)} ${esc(pl.jp)}</b> <span class="small muted">(${esc(planetKey)})</span></div>
            <button class="btn small" id="ttClose">×</button></div>
          <p class="small muted">${signSym} ${esc(pl.sign)} ${pl.degree}° / 第${pl.house}ハウス / ${esc(ringLabel)}</p>
          <p class="small"><b>意味：</b>${esc(meaning)}</p>
          <p class="small"><b>サイン解説：</b>${esc(pl.sign)}に位置する${esc(pl.jp)}は、${esc(pl.jp)}の力を${esc(pl.sign)}的な色で表現します。</p>
          <p class="small"><b>ハウス解説：</b>第${pl.house}ハウス（${esc(HOUSE_MEANINGS[pl.house]||'')}）の領域でこの天体のテーマが発揮されます。</p>
          <p class="small"><b>主要アスペクトと影響：</b></p>
          <ul class="bullet-list small">${aspectsHtml}</ul>
        </div>`;
      let el = $('tooltipHost');
      if (!el) { el = document.createElement('div'); el.id = 'tooltipHost'; el.className = 'tooltip-host'; document.body.appendChild(el); }
      el.innerHTML = html;
      el.classList.add('show');
      $('ttClose').onclick = () => this._hideTooltip();
    },
    _hideTooltip() {
      this.state.selected = null; this.render();
      const el = $('tooltipHost'); if (el) el.classList.remove('show');
    }
  };

  // ============================================================
  // models / prompts ユーティリティ
  // ============================================================
  function getProviderKey(provider) {
    const bag = store.get('provider_api_keys', {});
    const storageKey = provider.apiKeyStorageKey || ('provider_' + provider.id + '_api_key');
    const byBag = bag?.[provider.id] || '';
    const byStorageKey = store.get(storageKey, '');
    return byBag || byStorageKey || '';
  }
  function setProviderKey(provider, value) {
    const storageKey = provider.apiKeyStorageKey || ('provider_' + provider.id + '_api_key');
    const bag = store.get('provider_api_keys', {});
    if (value) bag[provider.id] = value; else delete bag[provider.id];
    store.set('provider_api_keys', bag);
    if (value) store.set(storageKey, value); else store.remove(storageKey);
  }
  function getPromptForKey(key) {
    const userBag = pStore.get('user_prompts', {}) || {};
    if (userBag[key] && userBag[key].trim()) return userBag[key];
    const def = state.prompts.prompts?.[key];
    return def?.system || def?.default || '';
  }

  async function loadJson(path, fallback, overrideKey) {
    const saved = store.get(overrideKey);
    if (saved) return saved;
    try {
      const res = await fetch(path, { cache: 'no-store' });
      if (!res.ok) throw new Error(path);
      return await res.json();
    } catch {
      return fallback;
    }
  }

  // プロフィールハッシュ（§19 キャッシュキー）
  function profileHash(profile) {
    const p = profile || state.profile || {};
    const s = `${p.name||''}|${p.birth||''}|${p.time||''}|${p.place||''}`;
    let h = 0;
    for (let i=0; i<s.length; i++) { h = ((h<<5)-h) + s.charCodeAt(i); h |= 0; }
    return Math.abs(h).toString(36);
  }

  // ============================================================
  // boot
  // ============================================================
  async function boot() {
    await hydrateFromIndexedDb();
    state.appConfig = await loadJson('config/app-config.json', FALLBACK_APP_CONFIG, 'admin_app_config');
    state.modelConfig = await loadJson('config/models.json', FALLBACK_MODELS, 'admin_models_config');
    state.prompts = await loadJson('config/prompts.json', FALLBACK_PROMPTS, 'admin_prompts_config');
    await auth.init();          // §2
    await proxy.init();         // §5
    state.profile = pStore.get('profile') || store.get('profile'); // 互換
    if (state.profile && !pStore.get('profile')) pStore.set('profile', state.profile);
    state.forecastGranularity = state.appConfig.forecast?.defaultGranularity || 'daily';
    state.chats = pStore.get('chat_history', []) || [];
    state.friends = await friendsDb.list();
    state.natalCache = (await cacheDb.get('natal_' + profileHash()))?.text || null;

    $('appTitle').textContent = state.appConfig.app?.name || 'AstroInsight';
    updateAuthStatus();
    bindGlobalEvents();
    registerServiceWorker();
    if (location.hash === '#admin') openAdmin();
    if (!state.profile) openOnboarding(); // §9
    render();
  }

  function bindGlobalEvents() {
    document.querySelectorAll('.tab').forEach(btn => btn.addEventListener('click', () => {
      state.tab = btn.dataset.tab;
      document.querySelectorAll('.tab').forEach(b => b.classList.toggle('active', b === btn));
      render();
    }));
    $('refreshBtn').addEventListener('click', () => {
      // §18 表示中の画面のデータのみ強制再生成
      if (state.tab === 'forecast') { state.forecastData = null; render(); toast('予報を再生成中…'); regenerateForecast(); }
      else if (state.tab === 'today') { regenerateToday(); }
      else if (state.tab === 'compat') { render(); toast('相性タブを更新しました'); }
      else if (state.tab === 'chat') { render(); }
    });
    $('settingsBtn').addEventListener('click', openSettings);
    let pressTimer = null;
    $('settingsBtn').addEventListener('pointerdown', () => { pressTimer = setTimeout(openAdmin, 700); });
    ['pointerup','pointerleave','pointercancel'].forEach(ev => $('settingsBtn').addEventListener(ev, () => clearTimeout(pressTimer)));
    window.addEventListener('hashchange', () => { if (location.hash === '#admin') openAdmin(); });
    document.addEventListener('click', (e) => {
      const tt = $('tooltipHost');
      if (tt && tt.classList.contains('show') && !tt.contains(e.target) && !e.target.closest('#horoscopeSvg')) {
        horoscope._hideTooltip();
      }
    });
  }

  function registerServiceWorker() {
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('assets/sw.js').catch(() => {});
  }

  function render() {
    if (state.tab === 'today') renderToday();
    if (state.tab === 'forecast') renderForecast();
    if (state.tab === 'compat') renderCompat();
    if (state.tab === 'chat') renderChat();
  }

  // ============================================================
  // オンボーディング 4ステップ（§9）
  // ============================================================
  function openOnboarding() {
    state.onboardingStep = 0;
    renderOnboardingStep();
    openSlide('onboarding');
  }
  function renderOnboardingStep() {
    const s = $('onboarding');
    const step = state.onboardingStep;
    if (step === 0) {
      s.innerHTML = `<div style="min-height:80vh;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;padding:24px">
        <div style="font-size:60px;margin-bottom:14px">🔮</div>
        <h1 class="title" style="font-size:26px">AstroInsight へようこそ</h1>
        <p class="muted" style="max-width:320px;line-height:1.7">星の波を読み、気分・行動・仕事・恋愛・人間関係・決断・注意点・チャンスに翻訳するAI占星アシスタントです。</p>
        <button id="onbNext" class="btn primary" style="margin-top:24px;padding:14px 32px">はじめる →</button>
      </div>`;
      $('onbNext').onclick = () => { state.onboardingStep = 1; renderOnboardingStep(); };
    } else if (step === 1) {
      s.innerHTML = `<div class="between"><h2 class="title">プロフィール入力</h2></div>
        <div class="card">
          <p class="muted small">出生図の計算に使います。未ログインでもこの端末に保存されます。</p>
          <label class="label">名前 *</label><input id="obName" class="input" placeholder="例：Aiko" value="${esc(state.profile?.name || '')}">
          <label class="label">生年月日 *</label><input id="obBirth" type="date" class="input" value="${esc(state.profile?.birth || '')}">
          <label class="label">出生時間（任意・ハウス精度向上）</label><input id="obTime" type="time" class="input" value="${esc(state.profile?.time || '')}">
          <label class="label">出生地（任意）</label><input id="obPlace" class="input" placeholder="例：東京" value="${esc(state.profile?.place || '')}">
          <button id="onbSave" class="btn primary block" style="margin-top:16px">次へ</button>
        </div>`;
      $('onbSave').onclick = () => {
        const p = { name: $('obName').value.trim(), birth: $('obBirth').value, time: $('obTime').value, place: $('obPlace').value.trim() };
        if (!p.name || !p.birth) return toast('名前と生年月日は必須です');
        state.profile = p; pStore.set('profile', p); store.set('profile', p);
        updateAuthStatus();
        state.onboardingStep = 2;
        renderOnboardingStep();
        // バックグラウンドで生成（§9 §17）
        generateNatal();
      };
    } else if (step === 2) {
      s.innerHTML = `<div class="between"><h2 class="title">ネイタル分析を生成中…</h2></div>
        <div class="card">
          <p class="muted small">あなたの出生図をAIが読み解いています。スキップして後で再生成もできます。</p>
          <div id="onbNatal" class="markdown-body small" style="margin-top:10px;max-height:50vh;overflow:auto"></div>
          <div class="grid2" style="margin-top:14px">
            <button id="onbSkip" class="btn">スキップ</button>
            <button id="onbDone" class="btn primary">次へ</button>
          </div>
        </div>`;
      // 既にキャッシュがあれば即表示
      if (state.natalCache) $('onbNatal').innerHTML = md(state.natalCache);
      $('onbSkip').onclick = () => { state.onboardingStep = 3; renderOnboardingStep(); };
      $('onbDone').onclick = () => { state.onboardingStep = 3; renderOnboardingStep(); };
    } else if (step === 3) {
      s.innerHTML = `<div style="min-height:80vh;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;padding:24px">
        <div style="font-size:60px;margin-bottom:14px">✨</div>
        <h1 class="title" style="font-size:26px">準備ができました</h1>
        <p class="muted" style="max-width:320px;line-height:1.7">下のタブから「今日」「予報」「相性」「チャット」をお楽しみください。</p>
        <button id="onbFinish" class="btn primary" style="margin-top:24px;padding:14px 32px">メインへ →</button>
      </div>`;
      $('onbFinish').onclick = () => { closeSlide('onboarding'); render(); };
    }
  }

  function openSlide(id) { $(id).classList.add('open'); }
  function closeSlide(id) { $(id).classList.remove('open'); }
  function adBlock() { return `<div class="ad ${ADS_ENABLED(auth.currentUid()) ? 'show' : ''}">広告枠</div>`; }

  // ============================================================
  // ネイタル分析（§7 §9）
  // ============================================================
  async function generateNatal() {
    if (!state.profile) return;
    const sysPrompt = getPromptForKey('prompt_natal');
    const profStr = `名前:${state.profile.name}, 生年月日:${state.profile.birth}, 出生時間:${state.profile.time||'不明'}, 出生地:${state.profile.place||'不明'}`;
    const prompt = `${sysPrompt}\n\n${CORE_CONSTRAINT}\n\n以下のプロフィールから、ネイタルチャートに基づく本質・感情・仕事・恋愛・人間関係・人生テーマを読み解いてください。\nプロフィール: ${profStr}`;
    const taskId = 'natal-' + Date.now();
    await startGeneration({
      taskId, taskLabel: 'ネイタル分析を生成中',
      prompt, isJson: false,
      onProgress: (text) => {
        state.natalCache = text;
        const onb = $('onbNatal'); if (onb) onb.innerHTML = md(text + ' ▍');
        const setN = $('settingsNatal'); if (setN) setN.innerHTML = md(text + ' ▍');
      },
      onDone: async (text) => {
        state.natalCache = text;
        await cacheDb.set('natal_' + profileHash(), { text, ts: Date.now() });
        const onb = $('onbNatal'); if (onb) onb.innerHTML = md(text);
        const setN = $('settingsNatal'); if (setN) setN.innerHTML = md(text);
      },
      onError: (msg) => {
        const onb = $('onbNatal'); if (onb) onb.innerHTML = `<p class="muted">生成失敗: ${esc(msg)}</p>`;
      }
    });
  }

  // ============================================================
  // 「今日」タブ（§11）
  // 既存のハードコード版に「再生成」ボタンを追加（実AI呼び出し）
  // ============================================================
  function renderToday() {
    const data = buildTodayData(state.todayMode);
    $('main').innerHTML = `<section class="screen">
      <div class="seg"><button data-mode="today" class="${state.todayMode==='today'?'active':''}">今日</button><button data-mode="week" class="${state.todayMode==='week'?'active':''}">今週</button><button data-mode="month" class="${state.todayMode==='month'?'active':''}">今月</button></div>
      ${adBlock()}
      <article class="card forecast-card">
        <span class="score">影響度 ${data.score}/100</span><span class="wave-type">${esc(data.wave.type)}</span>
        <h3>${esc(data.label)}</h3>
        <p class="muted">${esc(data.theme)}</p>
        ${renderWave(data.wave)}
        ${renderAstroReason(data.astroReason)}
        ${renderSections(data.sections)}
        ${data.plutoLayer?.active ? renderPluto(data.plutoLayer) : ''}
        <div class="grid2" style="margin-top:12px">
          <button id="todayDetailBtn" class="btn primary">詳しく見る</button>
          <button id="todayRegenBtn" class="btn">AIで再生成</button>
        </div>
      </article>
    </section>`;
    document.querySelectorAll('[data-mode]').forEach(b => b.onclick = () => { state.todayMode = b.dataset.mode; renderToday(); });
    $('todayDetailBtn').onclick = () => openDetail(data, state.todayMode);
    $('todayRegenBtn').onclick = () => regenerateToday();
  }

  function buildTodayData(mode) {
    const labels = { today:'今日の波', week:'今週の波', month:'今月の波' };
    const item = makeForecastItem(mode, new Date(), 0);
    return { ...item, label: labels[mode], theme: item.theme };
  }

  async function regenerateToday() {
    if (!state.profile) return toast('プロフィールを設定してください');
    const sysPrompt = getPromptForKey('prompt_today');
    const profStr = `${state.profile.name} / ${state.profile.birth} / ${state.profile.time||''} / ${state.profile.place||''}`;
    const periodLabel = state.todayMode === 'today' ? '今日1日' : state.todayMode === 'week' ? '今週1週間' : '今月1ヶ月';
    const prompt = `${sysPrompt}\n\n${CORE_CONSTRAINT}\n\n【ネイタル】${profStr}\n【期間】${periodLabel}\n\nこの期間のトランジット影響を、テーマ・占星術的な理由（天体・ハウス・アスペクト）・気分・行動・仕事・恋愛・人間関係・決断・注意点・チャンスの観点で具体的に解説してください。冥王星が関わる場合は深層変容として扱ってください。`;
    const taskId = 'today-' + Date.now();
    let regenSection = '';
    await startGeneration({
      taskId, taskLabel: `${periodLabel}の波を生成中`,
      prompt, isJson: false,
      onProgress: (text) => {
        const card = document.querySelector('.forecast-card');
        if (!card.querySelector('#todayAi')) card.insertAdjacentHTML('beforeend', '<section class="forecast-section" id="todayAi"></section>');
        $('todayAi').innerHTML = `<h4>AI生成（${esc(periodLabel)}）</h4>` + md(text + ' ▍');
      },
      onDone: (text) => {
        if ($('todayAi')) $('todayAi').innerHTML = `<h4>AI生成（${esc(periodLabel)}）</h4>` + md(text);
      },
      onError: (msg) => toast('生成失敗: ' + msg)
    });
  }

  // ============================================================
  // 「予報」タブ（§12 ユーザー版仕様尊重）
  // ============================================================
  function renderForecast() {
    if (!state.forecastData || state.forecastData.granularity !== state.forecastGranularity) {
      state.forecastData = makeForecastData(state.forecastGranularity);
      state.selectedForecastIndex = Math.min(state.selectedForecastIndex, state.forecastData.items.length - 1);
    }
    const item = state.forecastData.items[state.selectedForecastIndex];
    $('main').innerHTML = `<section class="screen">
      <div class="seg four">
        ${['monthly','weekly','daily','hourly'].map(g => `<button data-gran="${g}" class="${state.forecastGranularity===g?'active':''}">${granLabel(g)}</button>`).join('')}
      </div>
      ${adBlock()}
      <div class="card"><div class="between"><div><b>波のチャート</b><div class="small muted">点をタップすると、その時点だけを詳しく表示します。一覧は表示しません。</div></div><button id="forecastRegen" class="btn small">AIで再生成</button></div><div class="chart-wrap"><canvas id="forecastChart"></canvas></div></div>
      <article id="selectedForecast" class="card forecast-card">${renderForecastItem(item)}</article>
    </section>`;
    document.querySelectorAll('[data-gran]').forEach(b => b.onclick = () => { state.forecastGranularity = b.dataset.gran; state.selectedForecastIndex = 0; state.forecastData = null; renderForecast(); });
    renderForecastChart();
    bindForecastActions(item);
    const rg = $('forecastRegen'); if (rg) rg.onclick = () => regenerateForecast();
  }

  function granLabel(g) { return ({monthly:'月次', weekly:'週次', daily:'日次', hourly:'時間'})[g] || g; }

  function makeForecastData(granularity) {
    const counts = { monthly: 20, weekly: 22, daily: 75, hourly: 30 };
    const count = counts[granularity] || 30;
    const items = [];
    const now = new Date();
    for (let i = 0; i < count; i++) {
      const d = new Date(now);
      if (granularity === 'monthly') d.setMonth(now.getMonth() - 2 + i);
      if (granularity === 'weekly') d.setDate(now.getDate() - 56 + i * 7);
      if (granularity === 'daily') d.setDate(now.getDate() - 60 + i);
      if (granularity === 'hourly') d.setHours(now.getHours() - 48 + i * 4);
      items.push(makeForecastItem(granularity, d, i));
    }
    return { granularity, generatedAt: new Date().toISOString(), items };
  }

  function makeForecastItem(granularity, date, index) {
    const score = Math.max(18, Math.min(96, Math.round(62 + 22 * Math.sin(index / 2.4) + 9 * Math.cos(index / 5))));
    const heavy = score < 50;
    const plutoActive = index % 5 === 0 || heavy;
    const label = formatLabel(granularity, date);
    const theme = plutoActive ? '深い変容を越えて、主導権を取り戻す波' : (score > 75 ? '追い風を現実に変える波' : '整えながら流れをつかむ波');
    return {
      id: `${granularity}_${date.toISOString()}`,
      start: date.toISOString(),
      end: date.toISOString(),
      label,
      score,
      scoreReason: plutoActive ? '冥王星の深層テーマが表面化し、月や水星がそれを日常の出来事として感じさせるためです。' : '月・水星・金星の短期的な動きが生活リズムと対人関係に追い風を作るためです。',
      theme,
      wave: buildWave(granularity, label, heavy, plutoActive),
      astroReason: buildAstroReason(plutoActive),
      sections: buildSections(granularity, plutoActive, heavy),
      focus: { houses: plutoActive ? ['第8ハウス','第10ハウス','第12ハウス'] : ['第3ハウス','第5ハウス','第11ハウス'], planets: plutoActive ? ['冥王星','月','水星'] : ['月','金星','木星'], aspects: plutoActive ? ['冥王星と金星のスクエア','月と冥王星の接触','水星と土星の緊張'] : ['金星と木星の調和','月と水星の調和'] },
      plutoLayer: plutoActive ? buildPlutoLayer(granularity) : { active:false },
      // 真の天体位置（§8 astronomy-engine）
      chart: state.profile ? astrology.computeChart(state.profile, date) : null,
      natalChart: state.profile ? astrology.computeChart(state.profile, null) : null
    };
  }

  function formatLabel(granularity, d) {
    const y = d.getFullYear(); const m = d.getMonth()+1; const day = d.getDate();
    if (granularity === 'monthly') return `${y}年${m}月`;
    if (granularity === 'weekly') { const end = new Date(d); end.setDate(d.getDate()+6); return `${m}/${day}〜${end.getMonth()+1}/${end.getDate()}`; }
    if (granularity === 'hourly') return `${m}/${day} ${String(d.getHours()).padStart(2,'0')}:00`;
    return `${y}年${m}月${day}日`;
  }

  function buildWave(granularity, label, heavy, plutoActive) {
    const time = timelineFor(granularity, label, heavy);
    return {
      type: plutoActive ? '冥王星が絡む深層変容の波' : (heavy ? '停滞から回復へ向かう波' : '追い風を形にする波'),
      status: heavy ? 'ピークを越える準備段階' : '伸び始めた流れを使う段階',
      identity: plutoActive
        ? 'この波は、表面的なラッキー/アンラッキーではなく、古い関係性・自己価値・仕事上の立ち位置を作り替える深い波です。今感じる重さは、終わらせるべきものと本当に残したいものを分けるために表面化しています。焦って結論を出すより、どこで自分の主導権を手放していたのかを見ることが大切です。'
        : 'この波は、日常の中に小さな追い風が入り、止まっていた連絡・予定・気持ちが少しずつ動き出す波です。勢いだけで大きく変えるより、今ある流れを丁寧につないでいくことで成果が出やすくなります。',
      timeline: time,
      astroBasis: plutoActive
        ? '冥王星が第8ハウス的な深い結びつきと手放しのテーマを強め、月がその感情を短期的に表面化させています。さらに水星が土星と緊張するため、考えが重くなりやすい一方、現実的な整理には向いています。'
        : '月が第3ハウスを通り、会話・連絡・短い移動が流れを作ります。金星と木星の調和は、人とのやわらかな関わりや楽しみを通じてチャンスが広がる配置です。',
      howToOvercome: '乗り越えるポイントは、今すぐ白黒をつけないことです。不安・事実・願望を紙に分けて書き、返事や判断は一晩置いてください。冥王星的な波では、相手を変えようとするより、自分が何を恐れているのかを見た方が早く抜け道が見つかります。',
      goodWaveUsage: '良い波が来ている場合は、終わる前に「話を出す」「候補を広げる」「信頼できる人に相談する」ところまで進めてください。結果を急ぐより、次につながる接点を増やすことが追い風の活かし方です。',
      changeSigns: '波が変わる予兆は、止まっていた連絡が戻ること、朝の重さが少し軽くなること、同じテーマを別々の人から聞くことです。冥王星が絡む場合は、急に人間関係を整理したくなる、執着していた相手への見方が変わる、という形でも現れます。',
      smallSigns: ['返信しようと思っていた相手から先に連絡が来る','一度諦めた予定に別ルートが出てくる','急に部屋やスマホ内を整理したくなる','同じキーワードを別々の人から聞く','眠気が強くなり、無理がきかなくなる','苦手だった人との会話が少し楽になる','迷っていたことに対して「これは違う」と感じる'],
      avoid: ['疲れている状態で大きな決断をする','勢いだけで相手に連絡する','相手を試すような言い方をする','曖昧な情報だけで判断する','全部一人で抱え込む'],
      recommendedActions: ['不安をメモに書いて、事実と想像を分ける','予定を1つ減らして余白を作る','信頼できる人に状況を話す','返信や判断を急がず、一晩置く','部屋・バッグ・スマホの中を整理する']
    };
  }

  function timelineFor(g, label, heavy) {
    if (g === 'monthly') return { start:'上旬', peak:'中旬', end:'下旬', afterglow:'翌月上旬まで余韻が残りやすいです。', nextWave:'翌月中旬から対人関係や仕事の動きが軽くなります。' };
    if (g === 'weekly') return { start:'週明け', peak:'週中', end:'週末', afterglow:'翌週前半は整理期間として残りやすいです。', nextWave:'翌週中盤から連絡や予定が動きやすくなります。' };
    if (g === 'hourly') return { start:'この時間帯の前半', peak:'中盤', end:'後半', afterglow:'次の時間帯まで少し余韻があります。', nextWave:'次の時間帯は気分が切り替わりやすいです。' };
    return { start:'朝', peak:'昼〜夕方', end:'夜', afterglow:'翌朝まで気持ちの整理として残りやすいです。', nextWave:'翌日から会話や予定を通じて流れが変わり始めます。' };
  }

  function buildAstroReason(plutoActive) {
    return {
      summary: plutoActive
        ? '冥王星が深い関係性・自己価値・主導権のテーマを刺激しています。月がその配置に触れることで、普段は奥にしまっている感情や違和感が表面化しやすい時です。水星と土星の緊張もあるため、考えすぎや悲観に傾きやすい一方、現実的な整理には強い配置です。これは短期の気分だけでなく、数ヶ月〜数年単位の深い変容の一部として読む必要があります。'
        : '月が会話や学びを表すハウスを刺激し、金星と木星の調和が対人関係や楽しみを広げます。小さな連絡、相談、発信が次の流れを作りやすい配置です。大きく賭けるより、軽く開いてみる行動がチャンスにつながります。',
      factors: plutoActive
        ? [
          { type:'planet', label:'冥王星が重要天体に接触', meaning:'執着・恐れ・主導権を見直し、深い再生を促す' },
          { type:'house', label:'第8ハウス/第12ハウスの強調', meaning:'深い感情、手放し、見えない疲れが表面化しやすい' },
          { type:'aspect', label:'水星と土星の緊張', meaning:'考えが重くなるが、条件整理や現実的な判断には向く' }
        ]
        : [
          { type:'house', label:'月が第3ハウス', meaning:'連絡・会話・学びが流れを変える' },
          { type:'aspect', label:'金星と木星の調和', meaning:'人との関わりからチャンスが広がる' },
          { type:'planet', label:'水星の活性化', meaning:'考えを言葉にすると状況が整理される' }
        ]
    };
  }

  function buildSections(granularity, plutoActive, heavy) {
    const reason = plutoActive ? '冥王星が深い感情と主導権のテーマを刺激しているため、表面的な出来事の奥にある本音が見えやすくなります。' : '月と水星が日常の動きを軽くし、金星が人との距離をやわらかくしています。';
    const long = (body) => body + (plutoActive ? ' ここで大切なのは、相手や状況を無理にコントロールしようとせず、自分が本当に守りたい価値を確認することです。' : ' 小さく動くほど、次の展開につながるヒントが見つかりやすいでしょう。');
    const sections = {
      mood: { title:'気分', astroReason: reason, body: long('気分は少し深いところに潜りやすく、普段なら流せる言葉にも反応しやすいかもしれません。ただ、それは弱さではなく、自分が本当は何を求めているのかに気づくサインです。') },
      action: { title:'行動', astroReason: '火星と水星の動きから、焦って大きく進めるより、短い作業や連絡の整理に向く配置です。', body: long('今は一気に突破するより、滞っていたものを一つずつ動かす方が波に乗れます。返信、予約、書類、メモ、部屋の整理など、すぐ終わる行動から始めてください。') },
      work: { title:'仕事', astroReason: '第10ハウスと土星のテーマが強まり、評価・責任・現実的な積み上げが重要になります。', body: long('仕事では派手な成果より、信頼の回復や条件整理が効きます。曖昧な約束を確認し、期限・役割・優先順位をはっきりさせると、重い流れが実務の強さに変わります。') },
      love: { title:'恋愛', astroReason: '金星と冥王星が関わる時は、ときめきだけでなく執着・不安・深い結びつきのテーマが出やすくなります。', body: long('恋愛では、相手の反応を深読みしすぎないことが鍵です。試す言葉ではなく、自分の本音を軽く、具体的に伝える方が関係は安定します。') },
      relationships: { title:'人間関係', astroReason: '水星と金星の状態から、会話の質が関係の流れを左右します。', body: long('人間関係では、合わせすぎて疲れる関係と、自然に話せる関係の差が見えやすくなります。距離を取ることは拒絶ではなく、関係を長く続けるための調整です。') },
      decision: { title:'決断', astroReason: '水星が土星と関わるため、勢いよりも条件確認・長期的な現実性を見る判断に向きます。', body: long('大きな決断は焦らなくて大丈夫です。今すぐ答えを出すより、何が怖くて迷っているのか、何が本音なのかを分けると、数日後に判断が軽くなります。') },
      caution: { title:'注意点', astroReason: '火星や冥王星が強い時は、反射的な言葉や支配したくなる気持ちが出やすくなります。', body: long('注意点は、疲れている時に強い言葉で結論を出してしまうことです。眠い、焦る、相手を試したいと感じる時ほど、返事を遅らせる勇気が流れを守ります。') },
      chance: { title:'チャンス', astroReason: '木星や金星の調和があるため、信頼できる人との会話から可能性が広がります。', body: long('チャンスは、ひとりで抱えていたことを誰かに話すところにあります。完璧な計画でなくても、今の状態を言葉にすると、紹介・助言・別ルートが見えてきます。') }
    };
    if (granularity === 'weekly') {
      sections.firstHalf = { title:'週前半の流れ', astroReason:'月の動きが内面整理を促すため、始まりは少し慎重です。', body:'週前半は無理に飛ばさず、予定や気持ちの棚卸しに向いています。何を進めるかより、何を減らすかが流れを軽くします。' };
      sections.secondHalf = { title:'週後半の流れ', astroReason:'水星と金星の働きが強まり、会話や調整が進みやすくなります。', body:'週後半は連絡、相談、提案に向きます。前半に整理したことを、やわらかく人に伝えると状況が動きます。' };
    }
    if (granularity === 'monthly') {
      sections.lifeDirection = { title:'人生・方向性', astroReason:'冥王星と土星の長期配置が、短期の出来事ではなく生き方の組み替えを促します。', body:'この月は、何を続けるかだけでなく、何をもう終わらせるかが大切です。古い役割や人に合わせる癖を見直すほど、次の方向性がはっきりします。' };
      sections.nextFlow = { title:'次の月への流れ', astroReason:'月末に向けて水星と金星の動きが軽くなり、対話から次の展開が生まれます。', body:'次の月は、今月整理したテーマを人に話すことで動きます。まだ完成していなくても、信頼できる相手に共有しておくと流れがつながります。' };
    }
    if (granularity === 'hourly') {
      sections.workTask = { title:'仕事・作業', astroReason:'月と水星が短時間の集中と確認作業に向く配置です。', body:'この時間は、新規の大勝負より、確認・返信・短い集中作業に向いています。気になることを一つだけ終わらせると波が整います。' };
      sections.loveContact = { title:'恋愛・連絡', astroReason:'金星の影響で、重い話より軽い一言が届きやすい時間です。', body:'長文で気持ちをぶつけるより、短くやさしい連絡が合っています。相手の反応を待つ余白も大切です。' };
      sections.bestAction = { title:'この時間にするとよいこと', astroReason:'月の短期的な流れが整える行動を後押しします。', body:'スマホの通知整理、短い返信、飲み物を用意して一息つく、次の予定を確認する。この小さな整え方が次の時間帯を軽くします。' };
    }
    return sections;
  }

  function buildPlutoLayer(granularity) {
    return {
      active: true,
      theme: '古い関係性の手放しと、自分の主導権を取り戻す変容',
      intensity: 88,
      timeScale: '数ヶ月〜数年単位',
      currentPhase: '表面化',
      astroBasis: 'トランジット冥王星がネイタル金星・太陽・MCなどの重要ポイントに触れる時期は、恋愛・自己価値・仕事上の立ち位置に深い変容が起きます。短期的には月や水星が触れた日に出来事として表面化します。',
      whatIsBeingTransformed: '相手に合わせすぎる関係、失うことへの恐れ、愛されるために自分を抑える癖、仕事で本音を飲み込む癖が変容の対象です。',
      shadow: '執着、嫉妬、相手を試す行動、状況をコントロールしたくなる気持ちが出やすくなります。',
      rebirthPoint: '自分の価値を相手の反応で測らず、自分で選び直すことが再生の入口になります。',
      signs: ['特定の人への執着が強くなる','昔の関係や未練が再浮上する','表面的には終わったはずの感情が戻ってくる','急に人間関係を整理したくなる','相手に合わせることへの違和感が強くなる'],
      howToWorkWithIt: ['感情をすぐ相手にぶつけず、まず何に反応しているかを見る','失う怖さと、本当に欲しい関係性を分ける','支配・依存・我慢で続いている関係を見直す','終わらせることを敗北ではなく再生の準備として捉える'],
      whenItEases: '短期的には月が冥王星から離れる2〜3日後に感情のピークは落ち着きます。ただし根本テーマは数ヶ月単位で続きます。',
      nextTrigger: '次に月・金星・火星が冥王星へ強く触れるタイミングで、同じテーマが再び表面化しやすいです。'
    };
  }

  function renderForecastChart() {
    const canvas = $('forecastChart');
    if (!canvas || !window.Chart) return;
    if (state.forecastChart) state.forecastChart.destroy();
    const items = state.forecastData.items;
    const nowIndex = Math.max(0, Math.min(items.length-1, Math.round(items.length * 0.55)));
    const ctx = canvas.getContext('2d');
    // 過去/未来色分け（§12）
    const segPlugin = {
      id:'nowLine',
      afterDraw(chart){
        const x = chart.scales.x.getPixelForValue(nowIndex);
        const {top,bottom} = chart.chartArea;
        ctx.save();
        ctx.strokeStyle='rgba(251,191,36,.9)';
        ctx.setLineDash([4,4]);
        ctx.beginPath(); ctx.moveTo(x,top); ctx.lineTo(x,bottom); ctx.stroke();
        ctx.restore();
      }
    };
    state.forecastChart = new Chart(ctx, {
      type:'line',
      data:{ labels: items.map(x => x.label),
        datasets:[{
          label:'影響度',
          data: items.map(x => x.score),
          tension:.35, pointRadius:4, pointHoverRadius:7,
          segment: { borderColor: (c) => c.p0DataIndex < nowIndex ? 'rgba(203,213,225,0.55)' : '#8b5cf6' },
          borderColor:'#8b5cf6'
        }]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        scales: { y:{ min:0, max:100, ticks:{ color:'#cbd5e1' } }, x:{ ticks:{ color:'#cbd5e1', maxTicksLimit:6 } } },
        plugins: { legend:{ display:false } },
        onClick: (evt, els) => {
          if (!els || !els.length) return;
          state.selectedForecastIndex = els[0].index;
          $('selectedForecast').innerHTML = renderForecastItem(state.forecastData.items[state.selectedForecastIndex]);
          bindForecastActions(state.forecastData.items[state.selectedForecastIndex]);
        }
      },
      plugins: [segPlugin]
    });
  }

  function renderForecastItem(item) {
    return `<span class="score">影響度 ${item.score}/100</span><span class="wave-type">${esc(item.wave.type)}</span>
      <h3>${esc(item.label)}</h3>
      <p><b>テーマ：</b>${esc(item.theme)}</p>
      <p class="muted"><b>なぜこのスコア？</b> ${esc(item.scoreReason)}</p>
      ${renderWave(item.wave)}
      ${renderAstroReason(item.astroReason)}
      ${item.plutoLayer?.active ? renderPluto(item.plutoLayer) : ''}
      ${renderSections(item.sections)}
      <div class="grid2" style="margin-top:12px"><button id="detailBtn" class="btn primary">この時点を詳しく見る</button><button id="askBtn" class="btn">AIに質問</button></div>`;
  }

  function bindForecastActions(item) {
    const detail = $('detailBtn'); if (detail) detail.onclick = () => openDetail(item, state.forecastGranularity);
    const ask = $('askBtn'); if (ask) ask.onclick = () => {
      state.chatContext = item; state.tab='chat';
      document.querySelectorAll('.tab').forEach(b => b.classList.toggle('active', b.dataset.tab==='chat'));
      renderChat();
    };
  }

  async function regenerateForecast() {
    if (!state.profile) return toast('プロフィールを設定してください');
    const sysPrompt = getPromptForKey('prompt_forecast');
    const profStr = `${state.profile.name} / ${state.profile.birth} / ${state.profile.time||''} / ${state.profile.place||''}`;
    const item = state.forecastData?.items[state.selectedForecastIndex] || {};
    const prompt = `${sysPrompt}\n\n${CORE_CONSTRAINT}\n\n【ネイタル】${profStr}\n【粒度】${state.forecastGranularity}\n【選択時点】${item.label||''}\n\nこの時点のトランジットの詳細を、波の正体・開始/ピーク/抜け/余韻・占星術的な理由・乗り越えるポイント・良い波の活かし方・波が変わる予兆・細かなサイン・やってはいけないこと・今やるとよいこと・気分・行動・仕事・恋愛・人間関係・決断・注意点・チャンスの観点で具体的に説明してください。冥王星が関わる場合は深層変容として最重要レイヤーで扱ってください。`;
    const taskId = 'forecast-' + Date.now();
    await startGeneration({
      taskId, taskLabel: '予報を生成中',
      prompt, isJson: false,
      onProgress: (text) => {
        const sel = $('selectedForecast');
        if (!sel.querySelector('#forecastAi')) sel.insertAdjacentHTML('beforeend', '<section class="forecast-section" id="forecastAi"></section>');
        $('forecastAi').innerHTML = `<h4>AI生成（${esc(item.label||'')}）</h4>` + md(text + ' ▍');
      },
      onDone: (text) => { if ($('forecastAi')) $('forecastAi').innerHTML = `<h4>AI生成（${esc(item.label||'')}）</h4>` + md(text); },
      onError: (msg) => toast('生成失敗: ' + msg)
    });
  }

  // ============================================================
  // 詳細画面（§8 §11 §12 §13共通）
  // ============================================================
  function openDetail(item, mode) {
    state.horoscopeMode = 'dual';
    const natalChart = item.natalChart || (state.profile ? astrology.computeChart(state.profile, null) : null);
    const transitChart = item.chart || (state.profile ? astrology.computeChart(state.profile, new Date(item.start || Date.now())) : null);
    const houseGroups = transitChart ? groupByHouse(Object.values(transitChart.planets)) : {};
    $('detailSlide').innerHTML = `
      <div class="between"><h2 class="title">詳細：${esc(item.label)}</h2>
        <div class="header-actions">
          <button id="detailRefresh" class="btn small">↻</button>
          <button id="closeDetail" class="btn small">閉じる</button>
        </div>
      </div>
      <div class="card">
        <div class="between">
          <h3 class="section-title" style="margin:0">ホロスコープ</h3>
          <button id="detailModeToggle" class="btn small">🪐 二重円</button>
        </div>
        <svg id="horoscopeSvg" class="horo" role="img" aria-label="ホロスコープ図"></svg>
        <p class="small muted">天体タップで詳細表示。内側=ネイタル / 外側=トランジット。</p>
      </div>
      <button id="detailAskAi" class="btn primary block">この結果についてAIに質問</button>
      <div class="card">
        <h3 class="section-title">この読み解きの根拠</h3>
        ${item.plutoLayer?.active ? `<div class="forecast-section pluto"><h4>最重要：冥王星の影響</h4><p>${esc(item.plutoLayer.astroBasis)}</p><p>${esc(item.plutoLayer.whatIsBeingTransformed)}</p></div>` : ''}
        ${item.astroReason ? renderAstroReason(item.astroReason) : ''}
        ${transitChart ? `<div class="forecast-section"><h4>ハウス分布</h4>${Object.keys(houseGroups).sort((a,b)=>a-b).map(h => `<p><b>第${h}ハウス</b>：${houseGroups[h].map(p=>p.jp).join('、')} / ${esc(HOUSE_MEANINGS[h]||'')}</p>`).join('')}</div>` : ''}
      </div>
      <div class="card"><h3 class="section-title">全体解説</h3>${item.wave ? renderWave(item.wave) : ''}${item.sections ? renderSections(item.sections) : ''}</div>
      ${transitChart ? `<details class="details"><summary>天体位置の詳細を見る</summary>${renderPlanetTable(natalChart, transitChart)}</details>` : ''}`;
    $('closeDetail').onclick = () => { horoscope._hideTooltip(); closeSlide('detailSlide'); };
    $('detailRefresh').onclick = () => { regenerateForecastDetail(item, mode); };
    $('detailAskAi').onclick = () => {
      state.chatContext = { label: item.label, wave: item.wave };
      closeSlide('detailSlide');
      state.tab = 'chat';
      document.querySelectorAll('.tab').forEach(b => b.classList.toggle('active', b.dataset.tab==='chat'));
      renderChat();
    };
    $('detailModeToggle').onclick = () => {
      const next = horoscope.state.mode === 'dual' ? 'natal' : 'dual';
      horoscope.setMode(next);
      $('detailModeToggle').textContent = next === 'dual' ? '🪐 二重円' : '◯ ネイタルのみ';
    };
    if (natalChart && transitChart) horoscope.setCharts(natalChart, transitChart, 'dual');
    openSlide('detailSlide');
  }

  async function regenerateForecastDetail(item, mode) {
    if (!state.profile) return;
    const sysPrompt = getPromptForKey('prompt_detail');
    const profStr = `${state.profile.name} / ${state.profile.birth} / ${state.profile.time||''} / ${state.profile.place||''}`;
    const prompt = `${sysPrompt}\n\n${CORE_CONSTRAINT}\n\n【ネイタル】${profStr}\n【対象期間】${item.label||''}\nホロスコープ図・ハウス分布・重要アスペクト・冥王星レイヤーから、なぜその読みになるのかを3〜5点に絞って説明してください。`;
    const taskId = 'detail-' + Date.now();
    await startGeneration({
      taskId, taskLabel: '詳細解説を生成中',
      prompt, isJson: false,
      onProgress: (text) => {
        let aiBox = document.getElementById('detailAi');
        if (!aiBox) {
          const card = document.querySelector('#detailSlide .card');
          card.insertAdjacentHTML('beforeend', '<section class="forecast-section" id="detailAi"></section>');
          aiBox = document.getElementById('detailAi');
        }
        aiBox.innerHTML = '<h4>AI解説</h4>' + md(text + ' ▍');
      },
      onDone: (text) => { const aiBox = document.getElementById('detailAi'); if (aiBox) aiBox.innerHTML = '<h4>AI解説</h4>' + md(text); },
      onError: (msg) => toast('生成失敗: ' + msg)
    });
  }

  function groupByHouse(planets) { return planets.reduce((a,p) => ((a[p.house] ||= []).push(p), a), {}); }

  function renderPlanetTable(natalChart, transitChart) {
    const list = (chart) => Object.values(chart.planets).map(p => `<p class="small">${p.symbol} ${p.jp}：${p.sign} ${p.degree}° / 第${p.house}ハウス</p>`).join('');
    return `<div class="grid2"><div><h4>ネイタル</h4>${list(natalChart)}</div><div><h4>トランジット/相手</h4>${list(transitChart)}</div></div>`;
  }

  function renderWave(w) {
    return `<section class="forecast-section"><h4>この波の正体</h4><p>${esc(w.identity)}</p></section>
      <section class="forecast-section"><h4>この波はいつまで？</h4><ul class="bullet-list"><li>開始：${esc(w.timeline.start)}</li><li>ピーク：${esc(w.timeline.peak)}</li><li>抜ける時期：${esc(w.timeline.end)}</li><li>余韻：${esc(w.timeline.afterglow)}</li><li>次の波：${esc(w.timeline.nextWave)}</li></ul></section>
      <section class="forecast-section"><h4>乗り越えるポイント</h4><p>${esc(w.howToOvercome)}</p></section>
      <section class="forecast-section"><h4>良い波の活かし方</h4><p>${esc(w.goodWaveUsage)}</p></section>
      <section class="forecast-section"><h4>波が変わる予兆</h4><p>${esc(w.changeSigns)}</p></section>
      <section class="forecast-section"><h4>細かなサイン</h4><ul class="bullet-list">${w.smallSigns.map(x => `<li>${esc(x)}</li>`).join('')}</ul></section>
      <section class="forecast-section"><h4>やってはいけないこと</h4><ul class="bullet-list">${w.avoid.map(x => `<li>${esc(x)}</li>`).join('')}</ul></section>
      <section class="forecast-section"><h4>今やるとよいこと</h4><ul class="bullet-list">${w.recommendedActions.map(x => `<li>${esc(x)}</li>`).join('')}</ul></section>`;
  }

  function renderAstroReason(a) {
    return `<section class="forecast-section"><h4>占星術的な理由</h4><p>${esc(a.summary)}</p><ul class="factor-list">${a.factors.map(f => `<li><b>${esc(f.label)}</b>：${esc(f.meaning)}</li>`).join('')}</ul></section>`;
  }
  function renderPluto(p) {
    return `<section class="forecast-section pluto"><h4>冥王星の深いテーマ</h4><p><b>テーマ：</b>${esc(p.theme)}</p><p><b>時間軸：</b>${esc(p.timeScale)} / ${esc(p.currentPhase)}</p><p>${esc(p.astroBasis)}</p><p><b>何が変容している？</b><br>${esc(p.whatIsBeingTransformed)}</p><p><b>影として出やすいこと：</b><br>${esc(p.shadow)}</p><p><b>再生のポイント：</b><br>${esc(p.rebirthPoint)}</p><h4>予兆</h4><ul class="bullet-list">${p.signs.map(x => `<li>${esc(x)}</li>`).join('')}</ul><h4>どう向き合う？</h4><ul class="bullet-list">${p.howToWorkWithIt.map(x => `<li>${esc(x)}</li>`).join('')}</ul><p><b>いつ軽くなる？</b><br>${esc(p.whenItEases)}</p><p><b>次の表面化：</b><br>${esc(p.nextTrigger)}</p></section>`;
  }
  function renderSections(sections) {
    const order = ['lifeDirection','firstHalf','secondHalf','mood','action','work','workTask','love','loveContact','relationships','decision','caution','chance','bestAction','nextFlow'];
    return order.filter(k => sections[k]).map(k => {
      const s = sections[k];
      return `<section class="forecast-section"><h4>${esc(s.title)}</h4><div class="astro-note">占星術的には：${esc(s.astroReason || '')}</div><p>${esc(s.body || '')}</p></section>`;
    }).join('');
  }

  // ============================================================
  // 「相性」タブ（§13 完全実装）
  // ============================================================
  function renderCompat() {
    const list = state.friends || [];
    const cards = list.length === 0
      ? `<div class="card" style="text-align:center;padding:40px 16px"><p style="font-size:50px;margin:0">👥</p><p class="muted">友達が登録されていません。</p><p class="small muted">右下の＋から追加できます。</p></div>`
      : list.map(f => {
        const total = f.compat?.scores?.total ?? '?';
        return `<article class="card" data-friend-id="${esc(f.id)}" style="cursor:pointer">
          <div class="between">
            <div>
              <b>${esc(f.name)}</b>
              <p class="small muted" style="margin:4px 0 0">${esc(f.birth)} ${esc(f.time||'')} ${esc(f.place||'')}</p>
            </div>
            <div style="text-align:center">
              <div style="font-size:26px;font-weight:900;color:#fde68a">${total}</div>
              <div class="small muted">総合相性</div>
            </div>
          </div>
        </article>`;
      }).join('');
    $('main').innerHTML = `<section class="screen">
      ${adBlock()}
      <div class="card"><h2 class="title">相性</h2><p class="muted small">相手との関わり方を読みます。冥王星が絡む場合は強い引力・執着・関係性の再編も慎重に読みます。タップで詳細・長押しで編集/削除。</p></div>
      ${cards}
      <button class="fab" id="addFriendBtn" aria-label="友達を追加">＋</button>
    </section>`;
    $('addFriendBtn').onclick = () => openCompatForm();
    document.querySelectorAll('[data-friend-id]').forEach(card => {
      const id = card.dataset.friendId;
      const friend = list.find(f => f.id === id);
      let pressTimer = null;
      let longPressed = false;
      card.addEventListener('click', (e) => {
        if (longPressed) { longPressed = false; return; }
        openCompatDetail(friend);
      });
      const startPress = () => { longPressed = false; pressTimer = setTimeout(() => { longPressed = true; showFriendMenu(friend); }, 600); };
      const cancelPress = () => { if (pressTimer) clearTimeout(pressTimer); };
      card.addEventListener('pointerdown', startPress);
      card.addEventListener('pointerup', cancelPress);
      card.addEventListener('pointerleave', cancelPress);
      card.addEventListener('contextmenu', (e) => { e.preventDefault(); showFriendMenu(friend); });
    });
  }

  function showFriendMenu(friend) {
    if (!friend) return;
    const choice = prompt(`${friend.name} さん：\n  1) 編集\n  2) 削除\n  キャンセル：何もしない\n番号を入力:`, '');
    if (choice === '1') openCompatForm(friend);
    else if (choice === '2') {
      if (confirm(`${friend.name} さんを削除しますか？`)) {
        friendsDb.remove(friend.id).then(async () => {
          state.friends = await friendsDb.list();
          renderCompat();
          toast('削除しました');
        });
      }
    }
  }

  let editingFriendId = null;
  function openCompatForm(friend = null) {
    editingFriendId = friend ? friend.id : null;
    const slide = $('detailSlide');
    slide.innerHTML = `<div class="between"><h2 class="title">${friend ? '友達を編集' : '友達を追加'}</h2><button id="closeCompatForm" class="btn small">閉じる</button></div>
      <div class="card">
        <label class="label">お名前 *</label><input id="cfName" class="input" value="${esc(friend?.name || '')}">
        <label class="label">生年月日 *</label><input id="cfBirth" type="date" class="input" value="${esc(friend?.birth || '')}">
        <label class="label">出生時間（任意）</label><input id="cfTime" type="time" class="input" value="${esc(friend?.time || '')}">
        <label class="label">出生地（任意）</label><input id="cfPlace" class="input" placeholder="例：大阪" value="${esc(friend?.place || '')}">
        <button id="cfSubmit" class="btn primary block" style="margin-top:14px">${friend ? '保存して相性を再生成' : '登録して相性を分析'}</button>
        <p class="small muted" style="margin-top:8px">登録後、相性分析がバックグラウンドで自動生成されます。</p>
      </div>`;
    $('closeCompatForm').onclick = () => closeSlide('detailSlide');
    $('cfSubmit').onclick = submitCompatForm;
    openSlide('detailSlide');
  }

  async function submitCompatForm() {
    const name = $('cfName').value.trim();
    const birth = $('cfBirth').value;
    const time = $('cfTime').value;
    const place = $('cfPlace').value.trim();
    if (!name) return toast('お名前は必須です');
    if (!birth) return toast('生年月日は必須です');
    const id = editingFriendId || ('f' + Date.now());
    const friend = { id, name, birth, time, place, compat: null, ts: Date.now() };
    // 既存編集なら相性結果は維持（再生成は別途）
    if (editingFriendId) {
      const old = state.friends.find(f => f.id === id);
      if (old?.compat) friend.compat = old.compat;
    }
    await friendsDb.put(id, friend);
    state.friends = await friendsDb.list();
    closeSlide('detailSlide');
    renderCompat();
    toast(editingFriendId ? '保存しました' : '登録しました。相性を生成します…');
    // 自動生成（§13 §17）
    generateCompatibility(friend);
  }

  function friendHash(f) {
    const s = `${f.name||''}|${f.birth||''}|${f.time||''}|${f.place||''}`;
    let h = 0;
    for (let i=0; i<s.length; i++) { h = ((h<<5)-h) + s.charCodeAt(i); h |= 0; }
    return Math.abs(h).toString(36);
  }

  async function generateCompatibility(friend) {
    if (!state.profile) return toast('まず自分のプロフィールを設定してください');
    const sysPrompt = getPromptForKey('prompt_compat');
    const meStr = `${state.profile.name} / ${state.profile.birth} / ${state.profile.time||''} / ${state.profile.place||''}`;
    const youStr = `${friend.name} / ${friend.birth} / ${friend.time||''} / ${friend.place||''}`;
    const prompt = `${sysPrompt}\n\n${CORE_CONSTRAINT}\n\n2人のシナストリー（相性分析）。出力は厳密に下記のJSONオブジェクトのみで（Markdown修飾不要）：
{
 "scores": { "romance": 0-100, "friendship": 0-100, "work": 0-100, "communication": 0-100, "total": 0-100 },
 "comments": { "romance":"...", "friendship":"...", "work":"...", "communication":"..." },
 "summary": "総合的な相性の読み解き（400字以内）"
}
冥王星が絡む場合は執着・支配・深い変容・運命的な引力の側面を必ず慎重に含めてください。
【自分(ネイタル)】${meStr}
【相手】${youStr}`;
    const cacheKey = `compat_${profileHash()}_${friendHash(friend)}`;
    const taskId = 'compat-' + friend.id;
    await startGeneration({
      taskId, taskLabel: `${friend.name} さんとの相性を生成中`,
      prompt, isJson: true,
      onDone: async (text) => {
        const obj = parseJsonObject(text);
        if (!obj) { snackbar.fail(taskId, '相性JSON解析失敗', () => generateCompatibility(friend)); return; }
        friend.compat = obj;
        await friendsDb.put(friend.id, friend);
        await cacheDb.set(cacheKey, { obj, ts: Date.now() });
        state.friends = await friendsDb.list();
        if (state.tab === 'compat') renderCompat();
        // 開いている詳細を更新
        if (state.currentFriend && state.currentFriend.id === friend.id) openCompatDetail(friend);
      },
      onError: (msg) => toast('相性生成失敗: ' + msg)
    });
  }

  function parseJsonObject(text) {
    try {
      let clean = text.replace(/```json/gi, '').replace(/```/g, '').trim();
      const s = clean.indexOf('{'); const e = clean.lastIndexOf('}');
      if (s >= 0 && e >= 0) clean = clean.substring(s, e+1);
      return JSON.parse(clean);
    } catch { return null; }
  }

  function openCompatDetail(friend) {
    if (!friend) return;
    state.currentFriend = friend;
    const me = state.profile ? astrology.computeChart(state.profile, null) : null;
    const them = astrology.computeChart({ name:friend.name, birth:friend.birth, time:friend.time, place:friend.place }, null);
    const compat = friend.compat;
    const renderRow = (label, key, emoji) => {
      const score = compat?.scores?.[key] ?? 0;
      const comment = compat?.comments?.[key] || '';
      return `<div style="margin:10px 0">
        <div class="between"><div><b>${emoji} ${label}</b></div><div><b style="color:#fde68a">${score}</b><span class="small muted">/100</span></div></div>
        <div style="height:6px;background:rgba(255,255,255,0.1);border-radius:999px;overflow:hidden;margin:6px 0"><div style="height:100%;width:${Math.max(0,Math.min(100,score))}%;background:linear-gradient(90deg,var(--brand),var(--brand2))"></div></div>
        <p class="small muted">${esc(comment)}</p>
      </div>`;
    };
    const total = compat?.scores?.total ?? 0;
    $('detailSlide').innerHTML = `
      <div class="between"><h2 class="title">${esc(friend.name)} さんとの相性</h2>
        <div class="header-actions">
          <button id="compatRefresh" class="btn small">↻</button>
          <button id="compatClose" class="btn small">閉じる</button>
        </div>
      </div>
      <div class="card">
        <div class="between">
          <h3 class="section-title" style="margin:0">ホロスコープ</h3>
          <button id="detailModeToggle" class="btn small">🪐 二重円</button>
        </div>
        <svg id="horoscopeSvg" class="horo" role="img" aria-label="ホロスコープ図"></svg>
        <p class="small muted">天体タップで詳細表示。内側=自分 / 外側=${esc(friend.name)} さん。</p>
      </div>
      <div class="card">
        <div style="text-align:center;margin-bottom:14px">
          <div class="small muted">総合相性スコア</div>
          <div style="font-size:48px;font-weight:900;color:#fde68a">${total}</div>
          <div class="small muted">/ 100</div>
        </div>
        ${renderRow('恋愛', 'romance', '💗')}
        ${renderRow('友情', 'friendship', '🤝')}
        ${renderRow('仕事', 'work', '💼')}
        ${renderRow('コミュニケーション', 'communication', '💬')}
      </div>
      ${compat?.summary ? `<div class="card"><h3 class="section-title">総合的な相性の読み解き</h3><div class="markdown-body">${md(compat.summary)}</div></div>` : `<div class="card"><p class="muted">相性分析を生成中…</p></div>`}
      <button id="compatAskAi" class="btn primary block">この相性についてAIに質問</button>`;
    $('compatClose').onclick = () => { horoscope._hideTooltip(); state.currentFriend = null; closeSlide('detailSlide'); };
    $('compatRefresh').onclick = () => generateCompatibility(friend);
    $('detailModeToggle').onclick = () => {
      const next = horoscope.state.mode === 'dual' ? 'natal' : 'dual';
      horoscope.setMode(next);
      $('detailModeToggle').textContent = next === 'dual' ? '🪐 二重円' : '◯ 自分のみ';
    };
    $('compatAskAi').onclick = () => {
      state.chatContext = { label: friend.name + 'さんとの相性', wave: { type: '相性' } };
      closeSlide('detailSlide');
      state.tab = 'chat';
      document.querySelectorAll('.tab').forEach(b => b.classList.toggle('active', b.dataset.tab==='chat'));
      renderChat();
    };
    if (me) horoscope.setCharts(me, them, 'dual');
    openSlide('detailSlide');
    if (!compat) generateCompatibility(friend);
  }

  // ============================================================
  // 「チャット」タブ（§14 文脈・ストリーミング・永続化・Markdown）
  // ============================================================
  function renderChat() {
    const badge = state.chatContext
      ? `<div class="card"><div class="between"><b>${esc(state.chatContext.label)}について質問中</b><button id="clearCtx" class="btn small">解除 ×</button></div></div>`
      : '';
    $('main').innerHTML = `<section class="screen">${adBlock()}${badge}
      <div class="card"><div class="between"><h2 class="title" style="margin:0">チャット</h2><button id="clearChatBtn" class="btn small">履歴クリア</button></div></div>
      <div class="chat-log" id="chatLog">${state.chats.map(m => `<div class="bubble ${m.role}">${m.role==='ai' ? md(m.text) : esc(m.text)}</div>`).join('')}</div>
      <div class="card">
        <textarea id="chatInput" class="textarea" placeholder="この波はいつ抜ける？ 冥王星はどう関係している？"></textarea>
        <button id="sendChat" class="btn primary block" style="margin-top:8px">送信</button>
      </div>
    </section>`;
    const cc = $('clearCtx'); if (cc) cc.onclick = () => { state.chatContext = null; renderChat(); };
    $('clearChatBtn').onclick = async () => {
      if (!confirm('チャット履歴を消去しますか？')) return;
      state.chats = []; pStore.set('chat_history', []); renderChat();
    };
    $('sendChat').onclick = sendChatMessage;
  }

  async function sendChatMessage() {
    const text = $('chatInput').value.trim();
    if (!text) return;
    state.chats.push({ role:'user', text });
    pStore.set('chat_history', state.chats);
    $('chatInput').value = '';
    // ストリーミング用 AIバブルを先置き
    const log = $('chatLog');
    const aiDiv = document.createElement('div');
    aiDiv.className = 'bubble ai';
    aiDiv.innerHTML = '<span class="muted">生成中…</span>';
    log.appendChild(document.createElement('div')).outerHTML = `<div class="bubble user">${esc(text)}</div>`;
    log.appendChild(aiDiv);
    log.scrollTop = log.scrollHeight;

    const sysPrompt = getPromptForKey('prompt_chat');
    const profStr = state.profile ? `${state.profile.name} / ${state.profile.birth} / ${state.profile.time||''} / ${state.profile.place||''}` : '未設定';
    const natalSummary = state.natalCache ? state.natalCache.substring(0, 300) : 'なし';
    const hist = state.chats.slice(-7, -1).map(c => `${c.role}: ${c.text}`).join('\n');
    const ctxBlock = state.chatContext ? `【現在の質問文脈】${state.chatContext.label}（${state.chatContext.wave?.type||''}）\n` : '';
    const prompt = `${sysPrompt}\n\n${CORE_CONSTRAINT}\n\n【プロフィール】${profStr}\n【ネイタル要約】${natalSummary}\n${ctxBlock}【会話履歴】${hist}\n\n最新の質問: ${text}\n\n回答:`;

    const taskId = 'chat-' + Date.now();
    await startGeneration({
      taskId, taskLabel: 'チャット応答を生成中',
      prompt, isJson: false,
      onProgress: (t) => { aiDiv.innerHTML = md(t + ' ▍'); log.scrollTop = log.scrollHeight; },
      onDone: (t) => {
        aiDiv.innerHTML = md(t);
        state.chats.push({ role:'ai', text: t });
        pStore.set('chat_history', state.chats);
      },
      onError: (msg) => { aiDiv.innerHTML = `<span class="muted">エラー: ${esc(msg)}</span>`; }
    });
  }

  // ============================================================
  // 通常設定（§15 アカウント・プロフィール・データ管理を本体に）
  // ============================================================
  async function openSettings() {
    const remain = await auth.remainingTrials();
    const u = state.user;
    const accountHtml = u
      ? `<div class="row" style="gap:12px">
           ${u.photoURL ? `<img src="${esc(u.photoURL)}" style="width:48px;height:48px;border-radius:50%">` : '<div style="width:48px;height:48px;border-radius:50%;background:rgba(255,255,255,0.15);display:flex;align-items:center;justify-content:center;font-size:22px">👤</div>'}
           <div style="flex:1"><b>${esc(u.name || u.email || 'ユーザー')}</b><br><span class="small muted">${esc(u.email||'')}</span>${u.isAdmin ? ' <span class="admin-badge">管理者</span>' : ''}</div>
         </div>
         <button id="btnLogout" class="btn block" style="margin-top:12px">ログアウト</button>
         <button id="btnMigrate" class="btn block" style="margin-top:8px">ゲストデータをこのアカウントに移行</button>`
      : `<p class="muted">未ログインです（ローカル保存モード）。</p>
         <p class="small muted">無料試用 残り <b style="color:#fde68a">${remain === Infinity ? '∞' : remain}</b> 回 / 上限${state.appConfig.limits?.guestTrialLimit ?? 3}回</p>
         <button id="btnLogin" class="btn primary block" style="margin-top:8px">Googleでログイン</button>`;

    $('settingsSlide').innerHTML = `<div class="between"><h2 class="title">通常設定</h2><button id="closeSettings" class="btn small">閉じる</button></div>
      <div class="card"><h3 class="section-title">アカウント</h3>${accountHtml}</div>
      <div class="card"><h3 class="section-title">プロフィール</h3>
        <label class="label">名前</label><input id="setName" class="input" value="${esc(state.profile?.name || '')}">
        <label class="label">生年月日</label><input id="setBirth" type="date" class="input" value="${esc(state.profile?.birth || '')}">
        <label class="label">出生時間</label><input id="setTime" type="time" class="input" value="${esc(state.profile?.time || '')}">
        <label class="label">出生地</label><input id="setPlace" class="input" value="${esc(state.profile?.place || '')}">
        <div class="grid2" style="margin-top:14px">
          <button id="saveSetProfile" class="btn primary">保存</button>
          <button id="regenNatal" class="btn">ネイタル再生成</button>
        </div>
        <details class="details" style="margin-top:10px"><summary>ネイタル分析を表示</summary><div id="settingsNatal" class="markdown-body small">${state.natalCache ? md(state.natalCache) : '<p class="muted">未生成</p>'}</div></details>
      </div>
      <div class="card"><h3 class="section-title">システムプロンプト（個別編集）</h3>
        <p class="small muted">空欄なら配布デフォルトを使用。各機能ごとにユーザー設定を上書きできます。</p>
        <div id="userPrompts"></div>
      </div>
      <div class="card"><h3 class="section-title">データ管理</h3>
        <div class="grid2"><button id="exportSettings" class="btn">バックアップDL</button><button id="clearSettings" class="btn danger">全データ消去</button></div>
        <label class="label" style="margin-top:10px">JSONインポート</label>
        <input id="restoreFile" type="file" accept="application/json">
      </div>
      <div class="card"><p class="muted small">モデル・プロバイダー・APIキー・JSON配布は管理用設定に集約しています。</p>
        <button id="adminShortcut" class="btn block">管理用設定を開く</button>
        <p class="small muted">現在はパスワードなし。#admin または歯車長押しでも開けます。</p>
      </div>`;
    $('closeSettings').onclick = () => closeSlide('settingsSlide');
    $('saveSetProfile').onclick = () => {
      const p = { name:$('setName').value.trim(), birth:$('setBirth').value, time:$('setTime').value, place:$('setPlace').value.trim() };
      if (!p.name || !p.birth) return toast('名前と生年月日は必須です');
      state.profile = p; pStore.set('profile', p); store.set('profile', p);
      updateAuthStatus(); toast('プロフィールを保存しました'); render();
    };
    $('regenNatal').onclick = async () => {
      if (!confirm('ネイタル分析を再生成しますか？')) return;
      await cacheDb.del('natal_' + profileHash());
      generateNatal();
    };
    $('adminShortcut').onclick = openAdmin;
    if (u) {
      $('btnLogout').onclick = async () => { await auth.signOut(); location.reload(); };
      $('btnMigrate').onclick = async () => { await auth.migrateGuestData(); location.reload(); };
    } else {
      $('btnLogin').onclick = () => auth.signInGoogle();
    }
    $('exportSettings').onclick = exportData;
    $('clearSettings').onclick = clearAllData;
    $('restoreFile').onchange = (e) => { if (e.target.files[0]) restoreData(e.target.files[0]); };

    // ユーザープロンプト編集UI
    const userBag = pStore.get('user_prompts', {}) || {};
    const allPrompts = state.prompts.prompts || {};
    const upHtml = Object.keys(allPrompts).map(k => {
      const def = allPrompts[k];
      const userVal = userBag[k] || '';
      return `<div style="margin:10px 0">
        <label class="label">${esc(def.name || k)}</label>
        <textarea data-prompt-key="${esc(k)}" class="textarea" style="min-height:90px" placeholder="${esc(def.system || def.default || '')}">${esc(userVal)}</textarea>
        <button data-reset-prompt="${esc(k)}" class="btn small" style="margin-top:6px">デフォルトに戻す</button>
      </div>`;
    }).join('');
    $('userPrompts').innerHTML = upHtml;
    $('userPrompts').querySelectorAll('[data-prompt-key]').forEach(ta => {
      ta.addEventListener('blur', () => {
        const bag = pStore.get('user_prompts', {}) || {};
        const k = ta.dataset.promptKey;
        const v = ta.value.trim();
        if (v) bag[k] = v; else delete bag[k];
        pStore.set('user_prompts', bag);
      });
    });
    $('userPrompts').querySelectorAll('[data-reset-prompt]').forEach(btn => {
      btn.onclick = () => {
        const bag = pStore.get('user_prompts', {}) || {};
        delete bag[btn.dataset.resetPrompt];
        pStore.set('user_prompts', bag);
        toast('デフォルトに戻しました');
        openSettings();
      };
    });

    openSlide('settingsSlide');
  }

  function exportData() {
    const data = {};
    Object.keys(localStorage).filter(k => k.startsWith(STORE_PREFIX)).forEach(k => data[k] = localStorage.getItem(k));
    downloadText('astroinsight-backup.json', JSON.stringify({ exportedAt: new Date().toISOString(), data }, null, 2));
  }

  async function restoreData(file) {
    try {
      const txt = await file.text();
      const json = JSON.parse(txt);
      const data = json.data || json;
      Object.entries(data).forEach(([k, v]) => { try { localStorage.setItem(k, v); } catch {} });
      toast('復元しました。リロードします');
      setTimeout(() => location.reload(), 1000);
    } catch (e) { toast('復元失敗: ' + e.message); }
  }

  function clearAllData() {
    if (!confirm('全データを消去しますか？\nバックアップを取っていない場合は復元できません')) return;
    Object.keys(localStorage).filter(k => k.startsWith(STORE_PREFIX)).forEach(k => localStorage.removeItem(k));
    toast('全データを消去しました');
    setTimeout(() => location.reload(), 800);
  }

  // ============================================================
  // 管理用設定（§16 + ユーザー版維持）
  // ============================================================
  async function openAdmin() {
    state.adminOpen = true;
    const modelsText = JSON.stringify(state.modelConfig, null, 2);
    const promptsText = JSON.stringify(state.prompts, null, 2);
    const appText = JSON.stringify(state.appConfig, null, 2);
    const fb = (await authDb.get('firebase_config')) || {};
    const px = (await authDb.get('admin_proxy')) || {};
    $('settingsSlide').innerHTML = `<div class="between"><h2 class="title">管理用設定 <span class="admin-badge">NO PIN</span></h2><button id="closeAdmin" class="btn small">閉じる</button></div>
      <div class="card"><p class="muted">モデル・プロバイダー・APIキー・プロンプト・変数・データ管理はここに集約しています。現在はアドミンパスワードを削除済みです。本番ではCloudflare Worker/Firebase custom claimsで認可してください。</p></div>

      <div class="card"><h3 class="section-title">フィーチャーフラグ（§16）</h3>
        <div class="grid2">
          <label class="label">guest_trial_max<input id="ffTrial" type="number" class="input" value="${state.appConfig.limits?.guestTrialLimit ?? 3}"></label>
          <label class="label">max_tokens<input id="ffMaxTok" type="number" class="input" value="${state.appConfig.ai?.maxTokens ?? 4500}"></label>
          <label class="label">temperature<input id="ffTemp" type="number" step="0.05" class="input" value="${state.appConfig.ai?.temperature ?? 0.85}"></label>
          <label class="label">top_p<input id="ffTopP" type="number" step="0.05" class="input" value="${state.appConfig.ai?.topP ?? 0.9}"></label>
        </div>
        <label class="row small" style="margin-top:8px"><input id="ffAds" type="checkbox" ${state.appConfig.ads?.enabled ? 'checked' : ''}> ADS_ENABLED</label>
        <label class="row small"><input id="ffPremium" type="checkbox" ${state.appConfig.premium?.enabled !== false ? 'checked' : ''}> PREMIUM_ENABLED（スタブ・常にtrue推奨）</label>
        <button id="saveFlags" class="btn primary block" style="margin-top:10px">フラグを保存</button>
      </div>

      <div class="card"><h3 class="section-title">プロバイダー別APIキー</h3>${renderProviderKeys()}</div>

      <div class="card"><h3 class="section-title">モデル追加フォーム</h3>${renderModelForm()}<button id="addModelBtn" class="btn primary block" style="margin-top:10px">モデルを追加</button></div>

      <div class="card"><h3 class="section-title">Cloudflareプロキシ設定（§5）</h3>
        <label class="label">ベースURL</label><input id="proxyUrl" class="input" placeholder="https://your-worker.example.workers.dev" value="${esc(px.baseUrl || '')}">
        <p class="small muted">設定するとログイン後にUIDトークンを自動取得し、対応モデルでプロキシ経由になります。</p>
        <button id="saveProxy" class="btn primary block" style="margin-top:8px">プロキシURLを保存</button>
      </div>

      <div class="card"><h3 class="section-title">Firebase認証設定（§16）</h3>
        <label class="label">apiKey</label><input id="fbApiKey" class="input" value="${esc(fb.apiKey || '')}">
        <label class="label">authDomain</label><input id="fbDomain" class="input" value="${esc(fb.authDomain || '')}">
        <label class="label">projectId</label><input id="fbProject" class="input" value="${esc(fb.projectId || '')}">
        <button id="saveFb" class="btn primary block" style="margin-top:8px">Firebase設定を保存（リロードで反映）</button>
      </div>

      <div class="card"><h3 class="section-title">models.json</h3><textarea id="modelsJson" class="textarea json-editor">${esc(modelsText)}</textarea><button data-save-json="models" class="btn primary block">models.jsonを保存</button></div>
      <div class="card"><h3 class="section-title">prompts.json</h3><textarea id="promptsJson" class="textarea json-editor">${esc(promptsText)}</textarea><button data-save-json="prompts" class="btn primary block">prompts.jsonを保存</button></div>
      <div class="card"><h3 class="section-title">app-config.json</h3><textarea id="appJson" class="textarea json-editor">${esc(appText)}</textarea><button data-save-json="app" class="btn primary block">app-config.jsonを保存</button></div>
      <div class="card"><h3 class="section-title">データ管理</h3><div class="grid2"><button id="exportData" class="btn">バックアップDL</button><button id="clearData" class="btn danger">全データ消去</button></div></div>`;
    $('closeAdmin').onclick = () => closeSlide('settingsSlide');
    bindAdminEvents();
    openSlide('settingsSlide');
  }

  function renderProviderKeys() {
    const providers = state.modelConfig.providers || [];
    return providers.map(p => {
      const savedValue = getProviderKey(p);
      const saved = savedValue ? '保存済み' : '未保存';
      const providerId = esc(p.id);
      const storageKey = p.apiKeyStorageKey || ('provider_' + p.id + '_api_key');
      return `<div class="provider-card">
        <div class="between"><b>${esc(p.name)}</b><span id="status_${providerId}" class="small ${savedValue ? 'ok' : 'muted'}">${esc(saved)}</span></div>
        <p class="small muted">Provider ID: <code>${providerId}</code> / Auth: ${esc(p.authType || '')}</p>
        <label class="label">API Key</label>
        <input id="key_${providerId}" class="input" type="password" value="${esc(savedValue)}" placeholder="${esc(storageKey)}" autocomplete="off">
        <div class="grid2" style="margin-top:8px"><button data-save-key="${providerId}" class="btn small">保存</button><button data-toggle-key="${providerId}" class="btn small">表示/非表示</button></div>
        <p class="small muted">保存後に管理画面を開き直しても値が復元されます。プロキシ利用時は通常不要です。</p>
      </div>`;
    }).join('') || '<p class="muted">プロバイダーが未登録です。models.json の providers を追加・保存してください。</p>';
  }

  function renderModelForm() {
    const providers = state.modelConfig.providers || [];
    return `<label class="label">プリセット</label><select id="presetSelect" class="select"><option value="">選択しない</option>${(state.modelConfig.presets||[]).map((p,i)=>`<option value="${i}">${esc(p.name)}</option>`).join('')}</select><label class="label">モデル名</label><input id="newModelName" class="input" placeholder="例：GPT-4.1 Mini"><label class="label">モデルID</label><input id="newModelId" class="input" placeholder="例：gpt-4.1-mini"><label class="label">プロバイダー</label><select id="newProviderId" class="select">${providers.map(p=>`<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('')}</select><label class="label">エンドポイントパス</label><input id="newModelPath" class="input" placeholder="/chat/completions"><div class="grid2"><label class="row small"><input id="newStreaming" type="checkbox" checked> Streaming</label><label class="row small"><input id="newProxy" type="checkbox" checked> Proxy対応</label><label class="row small"><input id="newRecommended" type="checkbox"> 推奨</label><label class="row small"><input id="newEnabled" type="checkbox" checked> 有効</label></div>`;
  }

  function bindAdminEvents() {
    document.querySelectorAll('[data-save-key]').forEach(btn => btn.onclick = () => {
      const p = (state.modelConfig.providers||[]).find(x => x.id === btn.dataset.saveKey);
      if (!p) return toast('プロバイダーが見つかりません');
      const input = $(`key_${p.id}`);
      const v = input ? input.value.trim() : '';
      if (!v) return toast('APIキーが空です。削除したい場合はデータ管理から消去してください');
      setProviderKey(p, v);
      const status = $(`status_${p.id}`); if (status) { status.textContent = '保存済み'; status.classList.remove('muted'); status.classList.add('ok'); }
      toast(`${p.name}のAPIキーを保存しました`);
    });
    document.querySelectorAll('[data-toggle-key]').forEach(btn => btn.onclick = () => { const input = $(`key_${btn.dataset.toggleKey}`); if (input) input.type = input.type === 'password' ? 'text' : 'password'; });
    const preset = $('presetSelect'); if (preset) preset.onchange = () => { const p = state.modelConfig.presets?.[Number(preset.value)]; if (!p) return; $('newModelName').value=p.name; $('newModelId').value=p.id; $('newProviderId').value=p.providerId; $('newModelPath').value=p.path; };
    $('addModelBtn').onclick = () => { const m = { id:$('newModelId').value.trim(), name:$('newModelName').value.trim(), providerId:$('newProviderId').value, path:$('newModelPath').value.trim(), streaming:$('newStreaming').checked, recommended:$('newRecommended').checked, proxySupported:$('newProxy').checked, enabled:$('newEnabled').checked }; if (!m.id || !m.name || !m.providerId || !m.path) return toast('モデル名・ID・プロバイダー・パスは必須です'); state.modelConfig.models ||= []; state.modelConfig.models.push(m); store.set('admin_models_config', state.modelConfig); $('modelsJson').value = JSON.stringify(state.modelConfig, null, 2); toast('モデルを追加しました'); };
    document.querySelectorAll('[data-save-json]').forEach(btn => btn.onclick = () => {
      try {
        if (btn.dataset.saveJson === 'models') {
          const parsed = JSON.parse($('modelsJson').value);
          if (!Array.isArray(parsed.providers) || !Array.isArray(parsed.models)) throw new Error('models.json には providers と models の配列が必要です');
          state.modelConfig = parsed;
          store.set('admin_models_config', state.modelConfig);
          toast('models.jsonを保存しました');
          openAdmin();
          return;
        }
        if (btn.dataset.saveJson === 'prompts') {
          const parsed = JSON.parse($('promptsJson').value);
          if (!parsed.prompts || typeof parsed.prompts !== 'object') throw new Error('prompts.json には prompts オブジェクトが必要です');
          state.prompts = parsed;
          store.set('admin_prompts_config', state.prompts);
          toast('prompts.jsonを保存しました');
          return;
        }
        if (btn.dataset.saveJson === 'app') {
          const parsed = JSON.parse($('appJson').value);
          state.appConfig = parsed;
          store.set('admin_app_config', state.appConfig);
          toast('app-config.jsonを保存しました');
          return;
        }
      } catch (e) { toast('JSON形式が不正です: ' + e.message); }
    });
    // フィーチャーフラグ
    const sf = $('saveFlags');
    if (sf) sf.onclick = () => {
      state.appConfig.limits = state.appConfig.limits || {};
      state.appConfig.ai = state.appConfig.ai || {};
      state.appConfig.ads = state.appConfig.ads || {};
      state.appConfig.premium = state.appConfig.premium || {};
      state.appConfig.limits.guestTrialLimit = parseInt($('ffTrial').value) || 3;
      state.appConfig.ai.maxTokens = parseInt($('ffMaxTok').value) || 4500;
      state.appConfig.ai.temperature = parseFloat($('ffTemp').value) || 0.85;
      state.appConfig.ai.topP = parseFloat($('ffTopP').value) || 0.9;
      state.appConfig.ads.enabled = $('ffAds').checked;
      state.appConfig.premium.enabled = $('ffPremium').checked;
      store.set('admin_app_config', state.appConfig);
      toast('フィーチャーフラグを保存しました');
    };
    // プロキシ
    const sp = $('saveProxy');
    if (sp) sp.onclick = async () => {
      const url = $('proxyUrl').value.trim();
      await proxy.setBaseUrl(url);
      toast('プロキシURLを保存しました');
    };
    // Firebase
    const sb = $('saveFb');
    if (sb) sb.onclick = async () => {
      const cfg = { apiKey: $('fbApiKey').value.trim(), authDomain: $('fbDomain').value.trim(), projectId: $('fbProject').value.trim() };
      await authDb.set('firebase_config', cfg);
      toast('Firebase設定を保存しました（リロードで反映）');
    };
    $('exportData').onclick = exportData;
    $('clearData').onclick = clearAllData;
  }

  function downloadText(name, text) { const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([text],{type:'application/json'})); a.download=name; a.click(); URL.revokeObjectURL(a.href); }

  // ============================================================
  // 起動
  // ============================================================
  boot();
})();
