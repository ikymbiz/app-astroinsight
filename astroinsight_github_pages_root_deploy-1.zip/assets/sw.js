/* AstroInsight Service Worker
 * 注: SW を assets/sw.js に置くと scope は /assets/ になるため、
 * ルートの index.html はキャッシュ制御の対象外。アセット類のみキャッシュする。
 */
const CACHE_NAME = 'astroinsight-v2';
const ASSETS = [
  './styles.css',
  './app.js',
  './worker.js',
  './manifest.webmanifest'
];
self.addEventListener('install', event => event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS)).catch(()=>{})));
self.addEventListener('activate', event => event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))))));
self.addEventListener('fetch', event => {
  // Worker は同一オリジン以外もあるため fetch のみで処理
  event.respondWith(caches.match(event.request).then(cached => cached || fetch(event.request).catch(() => cached)));
});
