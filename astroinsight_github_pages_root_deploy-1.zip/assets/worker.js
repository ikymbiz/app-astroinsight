/* ============================================================
 * AstroInsight - AI Generation Web Worker
 * 要件§17: 全AI生成はWeb Worker、UIスレッドをブロックしない
 * 要件§20: SSEストリーミング、Google/OpenAI/Anthropic/xAI、
 *          プロキシ経由とAPIキー直接の両ルーティング対応
 *
 * payload:
 * {
 *   action: 'generate',
 *   model:    'gpt-4o-mini',
 *   provider: { id, baseUrl, authType, ... },  // models.json provider
 *   modelDef: { id, name, providerId, path, ... },
 *   prompt:   '...',
 *   isJson:   false,
 *   apiKey:   '...',                  // 直接呼び出し用
 *   proxy:    { url, token } | null   // ログイン+プロキシ対応モデル時のみ
 * }
 * ============================================================ */

self.onmessage = async function (e) {
    const data = e.data || {};
    if (data.action !== 'generate') return;

    const { provider, modelDef, prompt, isJson, apiKey, proxy } = data;
    if (!provider || !modelDef) {
        return self.postMessage({ type: 'error', message: 'provider/modelDef が未指定です' });
    }

    let url, headers, body;

    try {
        if (proxy && proxy.url) {
            // ---- Cloudflareプロキシ経由（要件§5） ----
            url = proxy.url.replace(/\/$/, '') + '/v1/' + provider.id + '/generate';
            headers = {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + (proxy.token || '')
            };
            body = JSON.stringify({
                provider: provider.id,
                model: modelDef.id,
                path: modelDef.path,
                prompt,
                stream: !!modelDef.streaming
            });
        } else {
            // ---- 直接API ----
            const base = provider.baseUrl.replace(/\/$/, '');
            const path = modelDef.path || '';
            if (provider.id === 'google') {
                const sep = path.includes('?') ? '&' : '?';
                url = base + path + sep + 'alt=sse&key=' + encodeURIComponent(apiKey || '');
                headers = { 'Content-Type': 'application/json' };
                body = JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] });
            } else if (provider.id === 'openai' || provider.id === 'xai') {
                url = base + path;
                headers = {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + (apiKey || '')
                };
                body = JSON.stringify({
                    model: modelDef.id,
                    messages: [{ role: 'user', content: prompt }],
                    stream: true
                });
            } else if (provider.id === 'anthropic') {
                url = base + path;
                headers = {
                    'Content-Type': 'application/json',
                    'x-api-key': apiKey || '',
                    'anthropic-version': '2023-06-01',
                    'anthropic-dangerously-allow-browser': 'true'
                };
                body = JSON.stringify({
                    model: modelDef.id,
                    max_tokens: 4500,
                    messages: [{ role: 'user', content: prompt }],
                    stream: true
                });
            } else {
                throw new Error('未対応プロバイダー: ' + provider.id);
            }
        }

        const res = await fetch(url, { method: 'POST', headers, body });
        if (!res.ok) {
            const errBody = await res.text().catch(() => '');
            throw new Error('API ' + res.status + ' ' + errBody.slice(0, 240));
        }

        const reader = res.body.getReader();
        const decoder = new TextDecoder('utf-8');
        let fullText = '';
        let buffer = '';

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split(/\r?\n/);
            buffer = lines.pop();
            for (let line of lines) {
                line = line.trim();
                if (!line.startsWith('data: ')) continue;
                if (line === 'data: [DONE]') continue;
                const payload = line.substring(6).trim();
                try {
                    const obj = JSON.parse(payload);
                    let chunk = '';
                    if (provider.id === 'google' && obj.candidates?.[0]?.content?.parts?.[0]?.text) {
                        chunk = obj.candidates[0].content.parts[0].text;
                    } else if ((provider.id === 'openai' || provider.id === 'xai') &&
                                obj.choices?.[0]?.delta?.content) {
                        chunk = obj.choices[0].delta.content;
                    } else if (provider.id === 'anthropic' &&
                                obj.type === 'content_block_delta' && obj.delta?.text) {
                        chunk = obj.delta.text;
                    } else if (obj.text) {
                        chunk = obj.text; // プロキシ統一形式
                    } else if (obj.delta && typeof obj.delta === 'string') {
                        chunk = obj.delta;
                    }
                    if (chunk) {
                        fullText += chunk;
                        if (!isJson) self.postMessage({ type: 'chunk', text: fullText });
                    }
                } catch (_) {
                    // JSONパース失敗は無視
                }
            }
        }
        if (!fullText) throw new Error('応答が空でした');
        self.postMessage({ type: 'done', text: fullText });
    } catch (err) {
        self.postMessage({ type: 'error', message: err.message || String(err) });
    }
};
