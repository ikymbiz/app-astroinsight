/* ============================================================
 * AstroInsight - Main App（v6）
 * 全体オーケストレーション。要件§1 §2 §5 §17 §20 §22 を統合。
 *
 * 起動順:
 *   1) DB init → guest_temp クリア
 *   2) Auth init（GIS or ゲストセッション復元）
 *   3) Config loadDefaults (app-config / models / prompts)
 *   4) FeatureFlags load（app-configを反映）
 *   5) Proxy init（管理者設定の baseUrl を反映）
 *   6) 各コンポーネントのload
 *   7) UIController setupEventListeners + #admin監視 + 歯車長押し監視
 *   8) Onboarding maybeShow / 保存済みなら今日タブへ
 * ============================================================ */

class AstroApp {
    constructor() {
        this.db = new AstroDB();
        this.auth = new AuthService(this.db);
        this.proxy = new ProxyService(this.db);
        this.config = new ConfigLoader(this.db);
        this.flags = new FeatureFlags(this.db, this.auth, this.config);
        this.snackbar = new Snackbar();
        this.workerMgr = new AIWorkerManager('./js/workers/ai-worker.js', 4);

        this.ui = new UIController(this);
        this.profile = new ProfileComponent(this);
        this.natal = new NatalComponent(this);
        this.today = new TodayComponent(this);
        this.forecast = new ForecastComponent(this);
        this.compat = new CompatComponent(this);
        this.chat = new ChatComponent(this);
        this.detail = new DetailComponent(this);
        this.settings = new SettingsComponent(this);
        this.onboarding = new OnboardingComponent(this);
        this.ads = new AdsComponent(this);

        this.chartInstance = null;
        this._wakeLock = null;
    }

    async init() {
        await this.db.init();
        // GIS のクライアントIDなどを auth に渡す必要があるため、
        // config を先にロードしてから auth.init する
        await this.config.loadDefaults();
        this.auth.setConfig(this.config);
        await this.auth.init();
        await this.flags.load();
        await this.proxy.init();
        // app-config の app.name でタイトル更新
        const appName = this.flags.get('app_name');
        if (appName) {
            const t = document.querySelector('title');
            if (t) t.textContent = appName;
            const h = document.getElementById('appTitle');
            if (h) h.textContent = appName;
        }
        // 認証状態が変わったらUI更新
        this.auth.onChange(() => {
            if (this.settings._renderAccountSection) this.settings._renderAccountSection();
            this.ads.refresh();
        });
        // 初期データロード
        await this.settings.load();
        await this.profile.load();
        await this.natal.load();
        await this.today.load();
        await this.forecast.load();
        await this.compat.load();
        await this.chat.load();
        // UIイベント
        this.ui.setupEventListeners();
        this.ui.bindAdminTriggers(); // #admin / 歯車長押し / 設定内ボタン
        // 広告
        this.ads.refresh();
        // オンボーディング判定（要件§9）
        const showed = await this.onboarding.maybeShow();
        if (!showed) this.ui.switchTab('today');
        // 起動時に #admin が付いていれば管理画面を直接開く
        if (location.hash === '#admin' && this.auth.isAdmin()) {
            this.ui.openSettings();
            setTimeout(() => this.settings.openAdminPanel(), 200);
        }
    }

    // ==========================================================
    // 統合: AI生成エントリーポイント（要件§20 ルーティング）
    // プロバイダー単位APIキー対応（v6 ユーザー版仕様）
    // ==========================================================
    /**
     * @param {Object} opts - {
     *   taskId, taskLabel, prompt, isJson,
     *   onProgress(text), onDone(text), onError(msg)
     * }
     */
    async startGeneration(opts) {
        const { taskId, taskLabel, prompt, isJson } = opts;
        const modelId = (await this.db.get('selected_model')) || this.config.defaultModelsConfig?.defaultModelId || 'gemini-2.5-flash';
        const modelMeta = await this.config.getModelById(modelId);
        if (!modelMeta) {
            opts.onError && opts.onError('モデルが見つかりません: ' + modelId);
            return;
        }
        // プロバイダー判定（v6: providerId 優先、provider フォールバック）
        const providerId = modelMeta.providerId || modelMeta.provider;
        // ルーティング判定
        const loggedIn = this.auth.isLoggedIn();
        const useProxy = this.proxy.canUseProxy(modelMeta, loggedIn);
        const proxyReq = useProxy ? this.proxy.buildProxyRequest(modelMeta) : null;
        // プロバイダー単位APIキー（要件§4 v6改）
        const apiKey = await this.config.getProviderApiKey(providerId);
        if (!useProxy && !apiKey) {
            const provName = this.config.getProviderById(providerId)?.name || providerId;
            opts.onError && opts.onError(`APIキーが未設定です。設定→AIモデルで「${provName}」のAPIキーを入力してください。`);
            return;
        }
        // スナックバー開始（要件§17）
        this.snackbar.start(taskId, taskLabel || '生成中…');
        // Wake Lock（要件§20 生成中スリープ防止）
        this._acquireWakeLock();

        // AIパラメータ（要件§16）
        const aiOpts = {
            maxTokens: this.flags.get('ai_max_tokens'),
            temperature: this.flags.get('ai_temperature'),
            topP: this.flags.get('ai_top_p'),
            streaming: this.flags.get('ai_streaming')
        };

        this.workerMgr.submit(taskId, {
            apiKey, model: modelId, modelMeta, prompt, isJson, proxy: proxyReq, ai: aiOpts
        }, {
            onChunk: (msg) => {
                if (typeof opts.onProgress === 'function') opts.onProgress(msg.text);
                this.snackbar.update(taskId, taskLabel + '…');
            },
            onDone: (msg) => {
                opts.onDone && opts.onDone(msg.text);
                if (this.workerMgr.active.size === 0) this._releaseWakeLock();
            },
            onError: (msg) => {
                opts.onError && opts.onError(msg.message);
                if (this.workerMgr.active.size === 0) this._releaseWakeLock();
            }
        });
    }

    async _acquireWakeLock() {
        if (this._wakeLock || !('wakeLock' in navigator)) return;
        try {
            this._wakeLock = await navigator.wakeLock.request('screen');
        } catch (e) {}
    }
    _releaseWakeLock() {
        if (this._wakeLock) {
            try { this._wakeLock.release(); } catch (e) {}
            this._wakeLock = null;
        }
    }

    handleChatSubmit(e) {
        return this.chat.handleSubmit(e);
    }
}

// 起動
window.addEventListener('DOMContentLoaded', async () => {
    window.app = new AstroApp();
    await window.app.init();
    // PWA（要件§1）
    if ('serviceWorker' in navigator) {
        try { await navigator.serviceWorker.register('./sw.js'); } catch (e) {}
    }
});
