# AstroInsight JSON分離版

## 構成

```text
astroinsight/
  index.html
  README.md
  config/
    app-config.json
    models.json
    prompts.json
  assets/
    app.js
    styles.css
    sw.js
    manifest.webmanifest
```

## 今回の反映内容

- モデル・プロバイダー設定を `config/models.json` に分離
- プロンプトを `config/prompts.json` に分離
- 変数・管理設定を `config/app-config.json` に分離
- 管理用設定画面のパスワード/PINを削除
- 管理画面は `#admin` または歯車長押しで開く
- APIキーはモデル単位ではなくプロバイダー単位で保存
- モデル追加フォームを管理画面に実装
- 予報一覧カードを廃止し、グラフで選択した時点のみ表示
- 予報の各時点に以下を追加
  - 波の正体
  - いつ始まり、いつピークで、いつ抜けるか
  - 占星術的な理由
  - 乗り越えるポイント
  - 良い波の活かし方
  - 波が変わる予兆
  - 細かなサイン
  - やってはいけないこと
  - 今やるとよいこと
  - 気分 / 行動 / 仕事 / 恋愛 / 人間関係 / 決断 / 注意点 / チャンス
- 冥王星が関わる場合の `plutoLayer` を追加
- 詳細画面でホロスコープ、ハウス分布、重要根拠、天体位置補助情報を表示

## 管理画面の開き方

現在はパスワードなしです。

- URL末尾に `#admin` を付ける
- 歯車アイコンを長押しする
- 通常設定内の「管理用設定を開く」を押す

本番デプロイ時は、フロント側のPINではなく以下で認可してください。

- Firebase Authentication custom claims
- Cloudflare Worker側の管理API認可
- Cloudflare KV / Firestoreへの管理JSON保存

## JSON読み込み優先順位

アプリ起動時は以下の順で読みます。

1. 管理画面で保存されたローカル設定
2. `config/*.json`
3. `assets/app.js` 内の最小フォールバック

## 注意

静的HTML/JSでは、管理画面やJSONを完全に秘匿・暗号化することはできません。APIキーや本番管理権限はフロントに置かず、必ずサーバー/Worker側に置いてください。
