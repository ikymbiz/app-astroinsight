# GitHub Pages デプロイ手順

このZIPは、GitHub Pages 用に **index.html がZIP直下にある構成**です。

## 正しい配置

リポジトリ `app-astrc` の公開ブランチ/公開フォルダ直下に、以下が見える状態にしてください。

```text
index.html
404.html
.nojekyll
assets/
config/
README.md
```

## よくある404原因

前回のZIPは中に `astroinsight_complete_no_omission/` フォルダがありました。
そのフォルダごとアップロードすると、GitHub Pages の公開ルート直下に `index.html` が存在しないため、
`https://ikymbiz.github.io/app-astrc/` が 404 になります。

## GitHub画面でアップロードする場合

1. このZIPを展開する
2. 展開後の中身をすべて選択する
3. `app-astrc` リポジトリの公開対象ブランチにアップロードする
4. `index.html` がリポジトリ直下にあることを確認する
5. GitHub Pages の Source がそのブランチ/root になっていることを確認する

## URL確認

- リポジトリ名が `app-astrc` なら `https://ikymbiz.github.io/app-astrc/`
- リポジトリ名が `app-astro` なら `https://ikymbiz.github.io/app-astro/`

URLのリポジトリ名と実際のリポジトリ名が1文字でも違うと404になります。
