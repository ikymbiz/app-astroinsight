# GitHub Pages へのデプロイ手順

このプロジェクトは GitHub Pages の **root deploy** 構造になっています。`docs/` や `dist/` のようなサブディレクトリは使いません。

## 手順

### 1. リポジトリを作成

```bash
git init
git add .
git commit -m "AstroInsight v6 initial deploy"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

### 2. GitHub Pages を有効化

1. リポジトリの **Settings → Pages** を開く
2. **Source** を `Deploy from a branch` に
3. **Branch** を `main` / `/ (root)` に設定して **Save**

数分後、`https://<your-username>.github.io/<your-repo>/` で公開されます。

> リポジトリ名を `<your-username>.github.io` にすると、ルートドメイン `https://<your-username>.github.io/` で公開されます。

### 3. Service Worker のスコープを確認

ブラウザの DevTools → Application → Service Workers を開き、登録されている SW のスコープがリポジトリのパスを含んでいることを確認してください。`./sw.js` で登録しているので、自動的に正しいスコープになります。

### 4. （任意）Firebase 認証を有効化

1. Firebase Console でプロジェクトを作成し、Web アプリを追加
2. **Authentication → Sign-in method** で Google 認証を有効化
3. **Authentication → Settings → Authorized domains** に `<your-username>.github.io` を追加
4. アプリを開き、`#admin` で管理画面を開いて Firebase 設定（apiKey / authDomain / projectId）を保存
5. リロードして Google ログインボタンが動作することを確認

### 5. （任意）Cloudflare Worker プロキシを有効化

1. Cloudflare Workers でプロキシ Worker をデプロイ（要件§5・§20 仕様に準拠した SSE 中継実装）
2. 管理画面でベース URL を保存
3. ログイン済みかつプロキシ対応モデルを選択した状態で生成すると、プロキシ経由になります

## トラブルシューティング

- **アイコンが反映されない / アプリ名が違う**：`#admin` から `app-config.json` の `app.name` と `manifest.webmanifest` を更新してください。
- **APIキーがブラウザに保存されているのが心配**：本番では必ず Cloudflare Worker プロキシを有効化し、フロントには APIキーを置かないでください。
- **Service Worker が古いまま**：DevTools → Application → Service Workers で **Unregister** し、ハードリロードしてください。`sw.js` の `CACHE_NAME` も更新できます。

## 既知の制約

- フロント側のみで動作するため、最大限の機能を使うには Firebase + Cloudflare Worker の組み合わせが必要
- GitHub Pages 単体では SSE プロキシは提供できない（直接 API を叩く構成のみ動作）
