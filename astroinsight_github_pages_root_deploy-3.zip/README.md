# AstroInsight v6（GitHub Pages root deploy）

星の波を「気分・行動・仕事・恋愛・人間関係・決断・注意点・チャンス」に翻訳する、AI占星術アプリ。

## このリリースの位置づけ

要件定義書 v5 の23セクション全てをカバーしつつ、以下のユーザー意図的変更点を反映した v6 です。

### ユーザー版から引き継いだ意図的変更点

- **モデル・プロバイダー・プロンプトを `js/config/*.json` に分離**（`models.json` / `prompts.json` / `app-config.json`）
- **管理用設定のパスワード/PIN削除**：`#admin` ハッシュ・歯車アイコン長押し（700ms）・通常設定内ボタンのいずれでも開ける
- **APIキーをモデル単位 → プロバイダー単位に変更**：`provider_{providerId}_api_key` 形式で保存。同じプロバイダーを使う他のモデルでも再利用できる
- **モデル追加フォームを管理画面に配置**（プリセット選択あり）
- **予報一覧カードを廃止 → グラフで選択時点のみ表示**：折れ線グラフの点をタップした時点だけが詳細展開される
- **予報の各時点に追加項目**：波の正体／開始・ピーク・抜ける時期／占星術的な理由／乗り越えるポイント／良い波の活かし方／波が変わる予兆／細かなサイン／やってはいけないこと／今やるとよいこと／気分・行動・仕事・恋愛・人間関係・決断・注意点・チャンス／冥王星レイヤー
- **GitHub Pages root deploy 構造**：`/` 直下に `index.html` を配置

## 主な機能（要件 v5 全23§）

- §1 SPA / PWA / Wake Lock / オフラインキャッシュ
- §2 Firebase認証（ゲスト3回試用→ログイン誘導、Google認証、custom claimsで管理者）
- §3 広告（`ADS_ENABLED(uid)`／管理者非表示）と `PREMIUM_ENABLED(uid)` スタブ
- §4 §6 §16 AIモデル・プロンプト・アプリ設定をJSON管理。管理画面から編集可
- §5 Cloudflareプロキシ（ログイン済+対応モデルでのみ経由）
- §7 IndexedDB（`{uid}_*` プレフィックスでマルチアカウント対応・要件§19）
- §8 ホロスコープSVG（`astronomy-engine` + 簡易プラシダス）／天体タップツールチップ／ネイタル単独↔二重円トグル
- §9 オンボーディング4ステップ（ようこそ→プロフィール→ネイタル生成→完了）
- §10 §21 4タブ構成＋設定スライドイン＋詳細スライドイン（フェード・スライドアニメ）
- §11 今日タブ（今日／今週／今月セグメント）
- §12 予報タブ（月次／週次／日次／時間粒度。一覧廃止・選択時点のみ表示）
- §13 相性タブ（友達カード／+追加／長押しメニュー／自動相性生成／4カテゴリスコア＋総合）
- §14 チャット（SSEストリーミング・履歴永続化・文脈引き継ぎバッジ）
- §15 設定（アカウント／プロフ／AIモデル／プロンプト／データ管理／管理者ボタン）
- §16 管理者設定（フィーチャーフラグ／プロキシ／プロバイダーAPIキー／Firebase設定／JSON個別保存／プリセットモデル追加）
- §17 バックグラウンド処理（スナックバー進捗・並列タスク・プリフェッチ）
- §18 🔄更新ボタンで強制再生成
- §19 キャッシュキー `{uid}_*`
- §20 リクエストルーティング（プロキシ↔直接APIの自動切替）
- §22 将来拡張用フラグ（`PREMIUM_ENABLED` 等）
- §23 CDNライブラリ（Tailwind / Font Awesome 6.5.1 / marked / Chart.js / astronomy-engine / Noto Sans JP / Firebase SDK は管理画面で apiKey 設定後ロード）

## Google ログイン (GIS) 設定

このアプリは **Google Identity Services (GIS)** を使った Google ログインに対応しています（Firebase は任意・代替手段）。

### 必要なもの

- Google Cloud Console の **OAuth 2.0 クライアント ID**（Web アプリケーション）

### 設定手順

1. [Google Cloud Console](https://console.cloud.google.com/) でプロジェクトを開くか作成する
2. **API とサービス → 認証情報 → 認証情報を作成 → OAuth クライアント ID** を選択
3. アプリケーションの種類: **ウェブ アプリケーション**
4. **承認済みの JavaScript 生成元** にこのアプリのオリジンを追加：
   - 例: `https://<your-username>.github.io`
   - ローカル動作確認なら `http://localhost:8000` 等
5. （リダイレクト URI は GIS では不要）
6. 作成された **クライアント ID**（末尾が `.apps.googleusercontent.com`）をコピー
7. アプリ側 `js/config/app-config.json` の `auth.googleClientId` に貼り付ける（または `#admin` から管理画面で保存）
8. `auth.adminEmails` に管理者にしたい Google アカウントのメールアドレスを追加（カンマ区切り or 配列）
9. リロードすると設定セクションに Google 公式のサインインボタンが表示される

### 動作

- ログイン成功時：JWT (ID Token) を取得し、payload から `sub`(uid) / `email` / `name` / `picture` を読み取る
- `auth.adminEmails` に email が含まれていれば自動的に管理者ロールを付与
- IndexedDB は `{uid}_*` プレフィックスで分離

### Firebase は使わない場合

`auth.googleClientId` だけ設定すれば GIS で動きます。Firebase 設定は空のままで OK です。

## 管理画面の開き方

1. URL末尾に `#admin` を付ける（例: `https://example.com/#admin`）
2. ヘッダーの ⚙ アイコンを **700ms 長押し**
3. 設定画面下部の「管理用設定を開く」ボタン

いずれも管理者ロール保有者のみ実行可能（フロント側はUX用ガード。本番は Firebase custom claims か Cloudflare Worker で認可）。

## デプロイ

GitHub Pages へのデプロイ手順は `DEPLOY_GITHUB_PAGES.md` を参照。

## ファイル構成

```
/
├── .nojekyll            ← GitHub Pages 用（_ で始まるディレクトリも配信）
├── 404.html             ← SPA フォールバック
├── index.html
├── manifest.webmanifest
├── sw.js                ← Service Worker（root scope）
├── README.md
├── DEPLOY_GITHUB_PAGES.md
├── css/
│   └── styles.css
└── js/
    ├── app.js
    ├── config/
    │   ├── app-config.json
    │   ├── models.json
    │   └── prompts.json
    ├── core/
    │   ├── ai-worker-manager.js
    │   ├── astrology.js
    │   ├── auth.js
    │   ├── config-loader.js
    │   ├── db.js
    │   ├── feature-flags.js
    │   ├── horoscope-renderer.js
    │   ├── proxy.js
    │   └── snackbar.js
    ├── components/
    │   ├── ads.js
    │   ├── chat.js
    │   ├── compat.js
    │   ├── detail.js
    │   ├── forecast.js
    │   ├── natal.js
    │   ├── onboarding.js
    │   ├── profile.js
    │   ├── settings.js
    │   ├── today.js
    │   └── ui-controller.js
    └── workers/
        └── ai-worker.js
```

## ライセンス

Private. © 2026
