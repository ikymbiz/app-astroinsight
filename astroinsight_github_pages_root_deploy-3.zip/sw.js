/* ============================================================
 * AstroInsight - Service Worker (v6 / GitHub Pages root deploy)
 * 要件§1 PWA：シェル＋全JSをキャッシュし、オフライン起動を可能にする。
 * ============================================================ */

const CACHE_NAME = 'astroinsight-v6-2026-04-28';
const ASSETS = [
    './',
    './index.html',
    './manifest.webmanifest',
    './css/styles.css',
    './js/app.js',
    './js/config/app-config.json',
    './js/config/models.json',
    './js/config/prompts.json',
    './js/core/db.js',
    './js/core/config-loader.js',
    './js/core/ai-worker-manager.js',
    './js/core/auth.js',
    './js/core/proxy.js',
    './js/core/feature-flags.js',
    './js/core/snackbar.js',
    './js/core/astrology.js',
    './js/core/horoscope-renderer.js',
    './js/components/ui-controller.js',
    './js/components/onboarding.js',
    './js/components/profile.js',
    './js/components/natal.js',
    './js/components/today.js',
    './js/components/forecast.js',
    './js/components/compat.js',
    './js/components/chat.js',
    './js/components/detail.js',
    './js/components/ads.js',
    './js/components/settings.js',
    './js/workers/ai-worker.js'
];

self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS).catch(() => null))
    );
    self.skipWaiting();
});

self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then((keys) => Promise.all(
            keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))
        ))
    );
    self.clients.claim();
});

self.addEventListener('fetch', (event) => {
    if (event.request.method !== 'GET') return;
    const url = new URL(event.request.url);
    // APIエンドポイントはキャッシュしない
    if (
        url.host.includes('googleapis.com') ||
        url.host.includes('openai.com') ||
        url.host.includes('anthropic.com') ||
        url.host.includes('x.ai') ||
        url.host.includes('workers.dev') ||
        url.host.includes('cdn.jsdelivr.net') ||
        url.host.includes('cdnjs.cloudflare.com') ||
        url.host.includes('cdn.tailwindcss.com') ||
        url.host.includes('fonts.googleapis.com') ||
        url.host.includes('fonts.gstatic.com')
    ) return;
    event.respondWith(
        caches.match(event.request).then((res) => res || fetch(event.request).catch(() => caches.match('./index.html')))
    );
});
