/* ============================================================
 * AstroInsight - Ads Component（v5）
 * 要件§3 を実装する：
 *   - Google AdSense想定のバナー広告枠をプレースホルダーで実装
 *   - ADS_ENABLED(uid) で一括ON/OFF
 *   - 管理者・ADS_ENABLED=false のときは非表示
 *   - 各タブのコンテンツ上部または下部に固定バナー枠（高さ固定）
 *   - 広告タグはプレースホルダー、後付けでスクリプト差し込み可能な設計
 * ============================================================ */

class AdsComponent {
    constructor(app) {
        this.app = app;
    }

    /** 各タブの広告枠に対し、表示/非表示を更新 */
    refresh() {
        const enabled = this.app.flags.ADS_ENABLED(this.app.auth.currentUid());
        document.querySelectorAll('.ad-slot').forEach((el) => {
            if (!enabled) {
                el.classList.add('hidden');
                el.innerHTML = '';
            } else {
                el.classList.remove('hidden');
                if (!el.dataset.rendered) {
                    el.innerHTML = `
                        <div class="bg-slate-50 border border-dashed border-slate-300 rounded-xl text-center text-xs text-slate-400 py-3 px-2">
                            <i class="fa-solid fa-rectangle-ad mr-1"></i>
                            広告枠 (Google AdSense placeholder)
                        </div>`;
                    el.dataset.rendered = '1';
                }
            }
        });
    }
}

window.AdsComponent = AdsComponent;
