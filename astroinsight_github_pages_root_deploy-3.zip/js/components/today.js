/* ============================================================
 * AstroInsight - Today Component（v5）
 * 要件§11：
 *   - セグメント切替: 今日 / 今週 / 今月
 *   - 表示: 広告枠 / サマリーカード(テーマ・影響度・概要) / 「詳細を見る」ボタン
 *   - キャッシュキー: {uid}_today_{day|week|month}_{基準日付}
 *   - 🔄更新ボタンで強制再生成
 * ============================================================ */

class TodayComponent {
    constructor(app) {
        this.app = app;
        this.db = app.db;
        this.segment = 'day'; // day | week | month
    }

    _baseDate() {
        const d = new Date();
        if (this.segment === 'day') return d.toISOString().slice(0, 10);
        if (this.segment === 'week') {
            // ISO週: 月曜起点
            const day = d.getDay() || 7;
            const monday = new Date(d);
            monday.setDate(d.getDate() - (day - 1));
            return monday.toISOString().slice(0, 10);
        }
        return d.toISOString().slice(0, 7); // YYYY-MM
    }

    cacheKey() {
        return `today_${this.segment}_${this._baseDate()}`;
    }

    async load() {
        const cached = await this.db.cacheGet(this.cacheKey());
        if (cached) {
            this._render(cached);
        } else {
            this._renderEmpty();
        }
    }

    async refresh() {
        await this.db.cacheDelete(this.cacheKey());
        this.generate();
    }

    /** 生成 */
    async generate() {
        const p = await this.app.profile.getProfileString();
        if (!p) return alert('プロフィールを設定してください。');
        if (!await this.app.auth.consumeTrial()) {
            return alert('ログインしてください。\n（無料試用は3回までです）');
        }
        const periodLabel = this.segment === 'day' ? '今日1日' : this.segment === 'week' ? '今週1週間' : '今月1ヶ月';
        const sysPrompt = await this.app.config.getPrompt('prompt_today');
        const prompt = `${sysPrompt}\n\nネイタル: ${p}\nに対する【${periodLabel}】のトランジット影響を、以下のJSON形式のみで返してください。Markdown修飾不要。
[{"theme": "テーマ", "impact": 0〜100の整数, "summary": "200字以内の概要", "advice": "具体的アドバイス"}]
（1要素のみの配列でもOK。複数あれば最大3つ）`;
        const taskId = `today-${this.segment}`;
        await this.app.startGeneration({
            taskId,
            taskLabel: `${periodLabel}の運勢を生成中…`,
            prompt,
            isJson: true,
            onDone: async (text) => {
                const data = this._parseJsonArray(text);
                if (!data) {
                    this.app.snackbar.fail(taskId, '解析失敗', () => this.generate());
                    return;
                }
                const payload = { items: data, ts: Date.now(), segment: this.segment };
                await this.db.cacheSet(this.cacheKey(), payload);
                this._render(payload);
                this.app.snackbar.succeed(taskId, '✓ 更新しました');
            },
            onError: (msg) => this.app.snackbar.fail(taskId, msg, () => this.generate())
        });
    }

    _parseJsonArray(text) {
        try {
            let clean = text.replace(/```json/gi, '').replace(/```/g, '').trim();
            const s = clean.indexOf('[');
            const e = clean.lastIndexOf(']');
            if (s !== -1 && e !== -1) clean = clean.substring(s, e + 1);
            const arr = JSON.parse(clean);
            if (Array.isArray(arr) && arr.length > 0) return arr;
            return null;
        } catch (e) { return null; }
    }

    _renderEmpty() {
        const el = document.getElementById('today-cards');
        if (!el) return;
        el.innerHTML = `
            <div class="text-center text-slate-400 py-10">
                <i class="fa-solid fa-cloud-sun text-4xl mb-3 opacity-50"></i>
                <p class="text-sm">「占う」を押して最新の星の動きを確認しましょう。</p>
            </div>`;
    }

    _render(payload) {
        const el = document.getElementById('today-cards');
        if (!el) return;
        el.innerHTML = '';
        for (const it of payload.items) {
            const card = document.createElement('div');
            card.className = 'bg-white rounded-2xl shadow-sm border border-slate-100 p-5 mb-3 border-l-4 border-l-astro';
            const impact = Math.max(0, Math.min(100, parseInt(it.impact || 50)));
            card.innerHTML = `
                <div class="flex justify-between items-start mb-2">
                    <h3 class="font-bold text-slate-800 text-base">${this._esc(it.theme || 'テーマ')}</h3>
                    <span class="text-xs font-bold px-2 py-1 rounded-full bg-astro-light text-astro border border-indigo-200 shrink-0">影響度: ${impact}</span>
                </div>
                <p class="text-sm text-slate-600 leading-relaxed mb-3">${this._esc(it.summary || '')}</p>
                <button class="w-full bg-slate-50 hover:bg-slate-100 text-astro border border-slate-200 font-bold py-2 rounded-xl text-sm transition active:scale-95">
                    <i class="fa-solid fa-arrow-right-long mr-1"></i> 詳細を見る
                </button>
            `;
            const detailBtn = card.querySelector('button');
            detailBtn.addEventListener('click', () => {
                this.app.detail.openForToday({
                    theme: it.theme, summary: it.summary, advice: it.advice, impact, segment: this.segment
                });
            });
            el.appendChild(card);
        }
    }

    _esc(s) {
        return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }
}

window.TodayComponent = TodayComponent;
