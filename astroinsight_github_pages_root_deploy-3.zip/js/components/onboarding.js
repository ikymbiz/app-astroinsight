/* ============================================================
 * AstroInsight - Onboarding（v5）
 * 要件§9：
 *   - ログイン後、IndexedDBに {uid}_profile が存在しない場合のみ全画面表示
 *   - 2回目以降スキップ
 *   - ステップ:
 *     1) ようこそ画面 — コンセプト説明、「はじめる」
 *     2) プロフィール入力 — 名前(必須)・生年月日(必須)・出生時間(任意)・出生地(任意)
 *     3) ネイタル分析生成 — バックグラウンドAI生成、プログレス、スキップ可
 *     4) 完了画面 — 「メインへ」でアプリ本体へ
 * ============================================================ */

class OnboardingComponent {
    constructor(app) {
        this.app = app;
        this.db = app.db;
        this.step = 0;
    }

    /** 表示判定（要件§9）。プロフィール未保存の場合のみ表示 */
    async maybeShow() {
        const profile = await this.db.get('profile');
        if (!profile || !profile.name || !profile.date) {
            this.app.ui.showOnboarding();
            this.show(0);
            return true;
        }
        return false;
    }

    show(step) {
        this.step = step;
        for (let i = 0; i < 4; i++) {
            const el = document.getElementById(`onb-step-${i}`);
            if (el) el.classList.toggle('hidden', i !== step);
        }
    }

    next() {
        this.show(Math.min(this.step + 1, 3));
    }

    /** ステップ2 「次へ」: プロフィール保存 → ステップ3 (生成) */
    async submitProfile() {
        const name = document.getElementById('onb-name').value.trim();
        const date = document.getElementById('onb-date').value;
        const time = document.getElementById('onb-time').value;
        const place = document.getElementById('onb-place').value.trim();
        if (!name) return alert('お名前は必須です。');
        if (!date) return alert('生年月日は必須です。');
        await this.app.profile.save({ name, date, time, place }, true);
        this.show(2);
        // バックグラウンドでネイタル分析を生成（要件§9 §17）
        this.app.natal.generate({ onComplete: () => this.show(3) });
    }

    skipNatal() {
        // ネイタル分析をスキップ → 完了画面へ
        this.show(3);
    }

    finish() {
        this.app.ui.hideOnboarding();
        this.app.ui.switchTab('today');
    }
}

window.OnboardingComponent = OnboardingComponent;
