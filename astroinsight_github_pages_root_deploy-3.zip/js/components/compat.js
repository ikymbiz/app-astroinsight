/* ============================================================
 * AstroInsight - Compatibility (相性) Component（v5）
 * 要件§13 を完全実装：
 *   - 友達リスト: カード形式で一覧（名前・生年月日・相性総合スコア）
 *   - 「＋ 追加」で友達登録（名前必須・生年月日必須・出生時間任意・出生地任意）
 *   - 登録後すぐにバックグラウンドで相性分析を自動生成（要件§17 友達登録完了トリガー）
 *   - IndexedDBに複数人を管理（friendsストア）
 *   - 友達カードタップで相性詳細画面へスライドイン
 *   - 長押し or スワイプで編集・削除メニュー（実装：長押し）
 *   - キャッシュキー: {uid}_compat_{自分プロフハッシュ}_{友達プロフハッシュ}
 *   - 🔄更新ボタンで強制再生成
 * ============================================================ */

class CompatComponent {
    constructor(app) {
        this.app = app;
        this.db = app.db;
        this.editingId = null;
    }

    async load() {
        await this.renderList();
    }

    async renderList() {
        const friends = await this.db.friendList();
        const cont = document.getElementById('compat-list');
        if (!cont) return;
        if (!friends.length) {
            cont.innerHTML = `
                <div class="text-center text-slate-400 py-10">
                    <i class="fa-solid fa-user-group text-4xl mb-3 opacity-50"></i>
                    <p class="text-sm">まだ友達が登録されていません。</p>
                    <p class="text-xs mt-1">右下の「＋」から追加できます。</p>
                </div>`;
            return;
        }
        cont.innerHTML = '';
        for (const f of friends) {
            const card = document.createElement('div');
            card.className = 'bg-white rounded-2xl shadow-sm border border-slate-100 p-4 mb-3 active:bg-slate-50 transition cursor-pointer';
            const score = (f.compat && f.compat.scores && f.compat.scores.total) ? f.compat.scores.total : '?';
            card.innerHTML = `
                <div class="flex justify-between items-start">
                    <div class="flex-1">
                        <div class="flex items-center gap-2">
                            <i class="fa-solid fa-user-circle text-xl text-astro"></i>
                            <h3 class="font-bold text-slate-800 text-base">${this._esc(f.name)}</h3>
                        </div>
                        <p class="text-xs text-slate-500 mt-1 ml-7">生年月日: ${this._esc(f.date || '?')}</p>
                    </div>
                    <div class="text-right">
                        <div class="text-2xl font-bold text-astro">${score}</div>
                        <div class="text-[10px] text-slate-400">相性スコア</div>
                    </div>
                </div>`;
            // タップ → 詳細
            let pressTimer = null;
            card.addEventListener('click', (e) => {
                if (this._longPressed) { this._longPressed = false; return; }
                this.app.detail.openForCompat(f);
            });
            // 長押し → 編集/削除メニュー（要件§13）
            card.addEventListener('touchstart', () => {
                pressTimer = setTimeout(() => {
                    this._longPressed = true;
                    this._showFriendMenu(f);
                }, 600);
            });
            card.addEventListener('touchend', () => {
                if (pressTimer) clearTimeout(pressTimer);
            });
            card.addEventListener('contextmenu', (e) => {
                e.preventDefault();
                this._showFriendMenu(f);
            });
            cont.appendChild(card);
        }
    }

    _showFriendMenu(friend) {
        const choice = prompt(`${friend.name} さん:\n  1) 編集\n  2) 削除\n  キャンセル: 何もしない\n番号を入力:`, '');
        if (choice === '1') {
            this.openAddForm(friend);
        } else if (choice === '2') {
            if (confirm(`${friend.name} さんを削除しますか？`)) {
                this.db.friendDelete(friend.id).then(() => this.renderList());
            }
        }
    }

    /** ＋追加 / 編集フォーム表示（要件§13） */
    openAddForm(friend = null) {
        this.editingId = friend ? friend.id : null;
        const set = (id, val) => { const e = document.getElementById(id); if (e) e.value = val || ''; };
        set('compat-form-name',  friend?.name);
        set('compat-form-date',  friend?.date);
        set('compat-form-time',  friend?.time);
        set('compat-form-place', friend?.place);
        document.getElementById('compat-form-screen').classList.remove('hidden');
        requestAnimationFrame(() => document.getElementById('compat-form-screen').classList.add('slide-in-active'));
    }

    closeAddForm() {
        const el = document.getElementById('compat-form-screen');
        if (!el) return;
        el.classList.remove('slide-in-active');
        setTimeout(() => el.classList.add('hidden'), 250);
    }

    async submitForm() {
        const name = document.getElementById('compat-form-name').value.trim();
        const date = document.getElementById('compat-form-date').value;
        const time = document.getElementById('compat-form-time').value;
        const place = document.getElementById('compat-form-place').value.trim();
        if (!name) return alert('お名前は必須です。');
        if (!date) return alert('生年月日は必須です。');
        const id = this.editingId || `f${Date.now()}`;
        const friend = { id, name, date, time, place, compat: null, ts: Date.now() };
        await this.db.friendPut(id, friend);
        this.closeAddForm();
        await this.renderList();
        // 登録後すぐに相性分析を自動生成（要件§17 トリガー）
        this.generateCompatibility(friend);
    }

    /** 相性分析の生成 + 保存（要件§13 §17） */
    async generateCompatibility(friend) {
        const me = await this.app.profile.getProfileString();
        if (!me) return alert('まず自分のプロフィールを設定してください。');
        if (!await this.app.auth.consumeTrial()) {
            return alert('ログインしてください。\n（無料試用は3回までです）');
        }
        const meHash = await this.app.profile.getProfileHash();
        const friendHash = this._friendHash(friend);
        const cacheKey = `compat_${meHash}_${friendHash}`;
        const sysPrompt = await this.app.config.getPrompt('prompt_compat');
        const friendStr = `名前: ${friend.name}, 生年月日: ${friend.date}, 出生時間: ${friend.time || '不明'}, 出生地: ${friend.place || '不明'}`;
        const prompt = `${sysPrompt}\n\n2人のシナストリー（相性分析）。出力は以下のJSONのみ。Markdown修飾不要。
{"scores":{"romance":0-100,"friendship":0-100,"work":0-100,"communication":0-100,"total":0-100},
"comments":{"romance":"...","friendship":"...","work":"...","communication":"..."},
"summary":"総合的な相性の読み解き(400字以内)"}
【自分(ネイタル)】${me}
【相手】${friendStr}`;
        const taskId = `compat-${friend.id}`;
        await this.app.startGeneration({
            taskId,
            taskLabel: `${friend.name} さんとの相性を生成中…`,
            prompt,
            isJson: true,
            onDone: async (text) => {
                const obj = this._parseJsonObject(text);
                if (!obj) {
                    this.app.snackbar.fail(taskId, '相性データの解析失敗', () => this.generateCompatibility(friend));
                    return;
                }
                friend.compat = obj;
                await this.db.friendPut(friend.id, friend);
                await this.db.cacheSet(cacheKey, { obj, ts: Date.now() });
                await this.renderList();
                this.app.snackbar.succeed(taskId, '✓ 相性分析を更新しました');
                // 詳細画面表示中ならその場で更新
                if (this.app.detail.currentMode === 'compat' && this.app.detail.currentFriend?.id === friend.id) {
                    this.app.detail.openForCompat(friend);
                }
            },
            onError: (msg) => this.app.snackbar.fail(taskId, msg, () => this.generateCompatibility(friend))
        });
    }

    _friendHash(f) {
        const s = `${f.name}|${f.date}|${f.time}|${f.place}`;
        let h = 0;
        for (let i = 0; i < s.length; i++) { h = ((h << 5) - h) + s.charCodeAt(i); h |= 0; }
        return Math.abs(h).toString(36);
    }

    _parseJsonObject(text) {
        try {
            let clean = text.replace(/```json/gi, '').replace(/```/g, '').trim();
            const s = clean.indexOf('{');
            const e = clean.lastIndexOf('}');
            if (s !== -1 && e !== -1) clean = clean.substring(s, e + 1);
            return JSON.parse(clean);
        } catch (e) { return null; }
    }

    _esc(s) {
        return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }
}

window.CompatComponent = CompatComponent;
