/* ============================================================
 * AstroInsight - Profile Component（v5）
 * 要件§9 §15：プロフィール（名前・生年月日・出生時間・出生地）の永続化。
 * ログインユーザーは {uid}::profile に保存。未ログインは guest_temp::profile（起動時クリア）。
 * ============================================================ */

class ProfileComponent {
    constructor(app) {
        this.app = app;
        this.db = app.db;
    }

    async load() {
        const p = await this.db.get('profile');
        // 設定画面のフィールドに反映
        if (p) {
            const ids = { name: 'set-prof-name', date: 'set-prof-date', time: 'set-prof-time', place: 'set-prof-place' };
            for (const k of Object.keys(ids)) {
                const el = document.getElementById(ids[k]);
                if (el) el.value = p[k] || '';
            }
        }
    }

    async save(p, silent = false) {
        // 入力もしくは引数からプロフ取得
        const profile = p || {
            name: (document.getElementById('set-prof-name')?.value || '').trim(),
            date: document.getElementById('set-prof-date')?.value || '',
            time: document.getElementById('set-prof-time')?.value || '',
            place: (document.getElementById('set-prof-place')?.value || '').trim()
        };
        if (!silent && !profile.name) return alert('お名前は必須です。');
        if (!silent && !profile.date) return alert('生年月日は必須です。');
        await this.db.set('profile', profile);
        if (!silent) {
            this.app.snackbar.start('save-prof', 'プロフィールを保存…');
            this.app.snackbar.succeed('save-prof', '✓ プロフィールを保存しました');
        }
    }

    getProfile() {
        const sp = document.getElementById('set-prof-name');
        if (sp) {
            return {
                name: (sp.value || '').trim(),
                date: document.getElementById('set-prof-date').value,
                time: document.getElementById('set-prof-time').value,
                place: (document.getElementById('set-prof-place').value || '').trim()
            };
        }
        return null;
    }

    /** プロフィール文字列。AIプロンプトに渡す形式 */
    async getProfileString() {
        const p = (await this.db.get('profile')) || this.getProfile();
        if (!p || !p.name || !p.date) return null;
        return `名前: ${p.name}, 生年月日: ${p.date}, 出生時間: ${p.time || '不明'}, 出生地: ${p.place || '不明'}`;
    }

    /** プロフィールハッシュ（要件§19 キャッシュキーに使用） */
    async getProfileHash() {
        const p = (await this.db.get('profile')) || {};
        const s = `${p.name}|${p.date}|${p.time}|${p.place}`;
        // 簡易ハッシュ
        let h = 0;
        for (let i = 0; i < s.length; i++) {
            h = ((h << 5) - h) + s.charCodeAt(i);
            h |= 0;
        }
        return Math.abs(h).toString(36);
    }
}

window.ProfileComponent = ProfileComponent;
