/* ============================================================
 * AstroInsight - Forecast Component（v6）
 * 要件§12 + README追加要件：
 *   - 粒度: 月次/週次/日次/時間
 *   - 期間: 月次=2ヶ月前→1.5年後 / 週次=2ヶ月前→3ヶ月後 /
 *           日次=2ヶ月前→2週間後 / 時間=2日前→3日後
 *   - Chart.js 折れ線（現在地マーカー、過去グレーアウト、未来カラー）
 *   - 【v6改】予報一覧カードを廃止し、グラフで選択した時点のみ表示
 *   - 各時点に以下を含む（プロンプト§prompt_forecast の出力）:
 *     wave: 波の正体・タイムライン(開始/ピーク/終わり/余韻/次の波)・占星術的な理由・
 *           乗り越えるポイント・良い波の活かし方・波が変わる予兆・細かなサイン・
 *           やってはいけないこと・今やるとよいこと
 *     astroReason: 占星術的根拠 + factors
 *     sections: 気分/行動/仕事/恋愛/人間関係/決断/注意点/チャンス
 *     plutoLayer: 冥王星が関わる場合のみ active:true で深層変容を解説
 *   - キャッシュキー: {uid}_forecast_{粒度}_{基準日}
 *   - 🔄更新ボタンで強制再生成
 * ============================================================ */

class ForecastComponent {
    constructor(app) {
        this.app = app;
        this.db = app.db;
        this.forecastType = 'daily'; // app-config.forecast.defaultGranularity
        this.selectedIndex = 0;
        this._lastData = null;
    }

    async load() {
        // 起動時に app-config の defaultGranularity を反映
        const ac = this.app.config?.getAppConfig?.() || {};
        if (ac.forecast?.defaultGranularity) this.forecastType = ac.forecast.defaultGranularity;
        const c = await this.db.cacheGet(this._cacheKey());
        if (c) this._render(c.data);
        else this._renderEmpty();
    }

    _baseDate() {
        return new Date().toISOString().slice(0, 10);
    }
    _cacheKey() {
        return `forecast_${this.forecastType}_${this._baseDate()}`;
    }

    async refresh() {
        await this.db.cacheDelete(this._cacheKey());
        this.generate();
    }

    async generate() {
        const p = await this.app.profile.getProfileString();
        if (!p) return alert('プロフィールを設定してください。');
        if (!await this.app.auth.consumeTrial()) {
            return alert('ログインしてください。\n（無料試用は3回までです）');
        }
        const info = {
            monthly: { desc: '2ヶ月前から1.5年後（月次、合計約20ヶ月）', fmt: 'YYYY-MM', count: 20 },
            weekly:  { desc: '2ヶ月前から3ヶ月後（週次、合計約20週）', fmt: 'YYYY年M月第W週', count: 20 },
            daily:   { desc: '2ヶ月前から2週間後（日次、合計約75日）', fmt: 'MM/DD', count: 30 },
            hourly:  { desc: '2日前から3日後（時間粒度、合計約30区間）', fmt: 'MM/DD HH:00', count: 30 }
        }[this.forecastType];
        const sysPrompt = await this.app.config.getPrompt('prompt_forecast');
        const prompt = `${sysPrompt}\n\nプロフィール: ${p}\n【期間】${info.desc}\n【出力】上記のJSON配列構造のみ。要素数: ${info.count}個程度。`;
        const taskId = `forecast-${this.forecastType}`;
        await this.app.startGeneration({
            taskId,
            taskLabel: `予報（${this._granLabel(this.forecastType)}）を生成中…`,
            prompt,
            isJson: true,
            onDone: async (text) => {
                const data = this._parseJsonArray(text);
                if (!data) {
                    this.app.snackbar.fail(taskId, '解析失敗', () => this.generate());
                    return;
                }
                await this.db.cacheSet(this._cacheKey(), { data, ts: Date.now() });
                this.selectedIndex = Math.floor(data.length / 3); // 現在に近い位置をデフォルト選択
                this._render(data);
                this.app.snackbar.succeed(taskId, '✓ 更新しました');
            },
            onError: (msg) => this.app.snackbar.fail(taskId, msg, () => this.generate())
        });
    }

    /** 「今日」タブを開いたときに裏で月次を生成（要件§17 プリフェッチ） */
    async prefetchMonthlyInBackground() {
        if (this._prefetched) return;
        this._prefetched = true;
        const old = this.forecastType;
        this.forecastType = 'monthly';
        const has = await this.db.cacheGet(this._cacheKey());
        this.forecastType = old;
        if (!has) {
            const tmp = this.forecastType;
            this.forecastType = 'monthly';
            this.generate().catch(() => {});
            this.forecastType = tmp;
        }
    }

    _parseJsonArray(text) {
        try {
            let clean = text.replace(/```json/gi, '').replace(/```/g, '').trim();
            const s = clean.indexOf('[');
            const e = clean.lastIndexOf(']');
            if (s !== -1 && e !== -1) clean = clean.substring(s, e + 1);
            const arr = JSON.parse(clean);
            if (Array.isArray(arr)) return arr;
            return null;
        } catch (e) { return null; }
    }

    _granLabel(g) { return ({ monthly: '月次', weekly: '週次', daily: '日次', hourly: '時間' })[g] || g; }

    _renderEmpty() {
        const cont = document.getElementById('forecast-selected');
        if (cont) cont.innerHTML = `<div class="text-center text-slate-400 py-6"><p class="text-sm">「予測開始」を押すと予測データを生成します。</p></div>`;
        if (this.app.chartInstance) {
            this.app.chartInstance.destroy();
            this.app.chartInstance = null;
        }
    }

    _render(data) {
        if (!data || !data.length) return;
        this._lastData = data;
        if (this.selectedIndex >= data.length) this.selectedIndex = data.length - 1;
        // チャート描画（点クリックで selectedIndex 更新 → 選択時点表示更新）
        this._renderChart(data);
        // 選択時点1枚のみ表示（要件 README: 一覧カード廃止）
        const item = data[this.selectedIndex];
        const cont = document.getElementById('forecast-selected');
        if (cont) cont.innerHTML = this._renderItemHtml(item);
        this._bindItemActions(item);
    }

    _renderChart(data) {
        const cv = document.getElementById('forecastChart');
        if (!cv || typeof Chart === 'undefined') return;
        const ctx = cv.getContext('2d');
        const labels = data.map((d) => d.period || '');
        const impacts = data.map((d) => parseInt(d.impact) || 0);
        // 過去/未来判定: 1/3 を過去とみなす（生成期間が「2ヶ月前から」始まるため）
        const nowIdx = Math.floor(data.length / 3);
        const pointBg = data.map((_, i) => (i === this.selectedIndex ? '#ef4444' : (i === nowIdx ? '#fbbf24' : '#fff')));
        const pointRad = data.map((_, i) => (i === this.selectedIndex ? 8 : (i === nowIdx ? 6 : 4)));
        if (this.app.chartInstance) this.app.chartInstance.destroy();
        // 「過去はグレー、未来はカラー」を border segment で実現
        this.app.chartInstance = new Chart(ctx, {
            type: 'line',
            data: {
                labels,
                datasets: [{
                    label: '影響度',
                    data: impacts,
                    borderColor: '#4f46e5',
                    backgroundColor: 'rgba(79,70,229,0.18)',
                    segment: {
                        borderColor: (c) => c.p0DataIndex < nowIdx ? '#cbd5e1' : '#4f46e5',
                        backgroundColor: (c) => c.p0DataIndex < nowIdx ? 'rgba(203,213,225,0.18)' : 'rgba(79,70,229,0.18)'
                    },
                    tension: 0.4,
                    fill: true,
                    pointBackgroundColor: pointBg,
                    pointBorderColor: '#4f46e5',
                    pointBorderWidth: 2,
                    pointRadius: pointRad
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: { y: { min: 0, max: 100 }, x: { ticks: { maxTicksLimit: 6 } } },
                plugins: { legend: { display: false } },
                animation: { duration: 300 },
                onClick: (evt, els) => {
                    if (!els || !els.length) return;
                    this.selectedIndex = els[0].index;
                    this._render(this._lastData);
                }
            }
        });
    }

    /** 選択された時点の詳細表示（v6: 一覧の代わりに1枚だけ） */
    _renderItemHtml(it) {
        if (!it) return '';
        const wave = it.wave || {};
        const tl = wave.timeline || {};
        const ar = it.astroReason || {};
        const sections = it.sections || {};
        const pluto = it.plutoLayer || { active: false };
        const impact = Math.max(0, Math.min(100, parseInt(it.impact || 0)));
        const list = (arr) => Array.isArray(arr) && arr.length ? `<ul class="list-disc pl-5 text-xs text-slate-700 leading-relaxed">${arr.map((s) => `<li>${this._esc(s)}</li>`).join('')}</ul>` : '';
        const block = (title, content) => content ? `<section class="bg-slate-50 rounded-xl p-3 mt-2"><h4 class="text-xs font-bold text-astro mb-1">${this._esc(title)}</h4>${content}</section>` : '';
        const sectionOrder = ['mood', 'action', 'work', 'love', 'relationships', 'decision', 'caution', 'chance'];
        const sectionLabels = { mood: '気分', action: '行動', work: '仕事', love: '恋愛', relationships: '人間関係', decision: '決断', caution: '注意点', chance: 'チャンス' };
        const sectionsHtml = sectionOrder.filter((k) => sections[k]).map((k) => {
            const s = sections[k];
            return `<section class="bg-white rounded-xl p-3 mt-2 border border-slate-100">
                <h4 class="text-xs font-bold text-slate-700 mb-1">${this._esc(s.title || sectionLabels[k])}</h4>
                ${s.astroReason ? `<p class="text-[10px] text-slate-500 italic mb-1">占星術的には：${this._esc(s.astroReason)}</p>` : ''}
                <p class="text-xs text-slate-700 leading-relaxed">${this._esc(s.body || '')}</p>
            </section>`;
        }).join('');
        const factorsHtml = ar.factors ? `<ul class="list-disc pl-5 text-xs text-slate-700">${ar.factors.map((f) => `<li><b>${this._esc(f.label)}</b>：${this._esc(f.meaning)}</li>`).join('')}</ul>` : '';
        const plutoHtml = pluto.active ? `
            <section class="bg-gradient-to-br from-purple-100 to-pink-50 border border-purple-200 rounded-xl p-3 mt-3">
                <h4 class="text-sm font-bold text-purple-700 mb-1">♇ 冥王星の深いテーマ</h4>
                <p class="text-xs"><b>テーマ：</b>${this._esc(pluto.theme || '')}</p>
                ${pluto.timeScale ? `<p class="text-xs"><b>時間軸：</b>${this._esc(pluto.timeScale)}${pluto.currentPhase ? ' / ' + this._esc(pluto.currentPhase) : ''}</p>` : ''}
                ${pluto.astroBasis ? `<p class="text-xs text-slate-700 mt-1">${this._esc(pluto.astroBasis)}</p>` : ''}
                ${pluto.whatIsBeingTransformed ? `<p class="text-xs mt-1"><b>何が変容している？</b><br>${this._esc(pluto.whatIsBeingTransformed)}</p>` : ''}
                ${pluto.shadow ? `<p class="text-xs mt-1"><b>影として出やすいこと：</b><br>${this._esc(pluto.shadow)}</p>` : ''}
                ${pluto.rebirthPoint ? `<p class="text-xs mt-1"><b>再生のポイント：</b><br>${this._esc(pluto.rebirthPoint)}</p>` : ''}
                ${list(pluto.signs) ? `<h5 class="text-xs font-bold mt-2">予兆</h5>${list(pluto.signs)}` : ''}
                ${list(pluto.howToWorkWithIt) ? `<h5 class="text-xs font-bold mt-2">どう向き合う？</h5>${list(pluto.howToWorkWithIt)}` : ''}
                ${pluto.whenItEases ? `<p class="text-xs mt-2"><b>いつ軽くなる？</b><br>${this._esc(pluto.whenItEases)}</p>` : ''}
                ${pluto.nextTrigger ? `<p class="text-xs mt-1"><b>次の表面化：</b><br>${this._esc(pluto.nextTrigger)}</p>` : ''}
            </section>` : '';

        return `
            <article class="bg-white rounded-2xl shadow-sm border border-slate-100 p-4 mb-3 border-l-4 border-l-astro">
                <div class="flex justify-between items-start mb-2">
                    <h3 class="font-bold text-slate-800 text-base">${this._esc(it.period || '')}</h3>
                    <div class="flex gap-1 shrink-0">
                        <span class="text-xs font-bold px-2 py-1 rounded-full bg-astro-light text-astro border border-indigo-200">影響度: ${impact}</span>
                        ${wave.type ? `<span class="text-xs font-bold px-2 py-1 rounded-full bg-pink-100 text-pink-700">${this._esc(wave.type)}</span>` : ''}
                    </div>
                </div>
                <p class="text-sm text-slate-700 mb-2"><b>テーマ：</b>${this._esc(it.theme || '')}</p>
                ${it.description ? `<p class="text-xs text-slate-600 mb-2">${this._esc(it.description)}</p>` : ''}

                ${block('この波の正体', wave.identity ? `<p class="text-xs text-slate-700 leading-relaxed">${this._esc(wave.identity)}</p>` : '')}
                ${block('この波はいつまで？', tl ? `<ul class="text-xs text-slate-700 leading-relaxed">
                    ${tl.start ? `<li>開始：${this._esc(tl.start)}</li>` : ''}
                    ${tl.peak ? `<li>ピーク：${this._esc(tl.peak)}</li>` : ''}
                    ${tl.end ? `<li>抜ける時期：${this._esc(tl.end)}</li>` : ''}
                    ${tl.afterglow ? `<li>余韻：${this._esc(tl.afterglow)}</li>` : ''}
                    ${tl.nextWave ? `<li>次の波：${this._esc(tl.nextWave)}</li>` : ''}
                </ul>` : '')}
                ${block('占星術的な理由', ar.summary ? `<p class="text-xs text-slate-700">${this._esc(ar.summary)}</p>${factorsHtml}` : '')}
                ${block('乗り越えるポイント', wave.howToOvercome ? `<p class="text-xs text-slate-700">${this._esc(wave.howToOvercome)}</p>` : '')}
                ${block('良い波の活かし方', wave.goodWaveUsage ? `<p class="text-xs text-slate-700">${this._esc(wave.goodWaveUsage)}</p>` : '')}
                ${block('波が変わる予兆', wave.changeSigns ? `<p class="text-xs text-slate-700">${this._esc(wave.changeSigns)}</p>` : '')}
                ${block('細かなサイン', list(wave.smallSigns))}
                ${block('やってはいけないこと', list(wave.avoid))}
                ${block('今やるとよいこと', list(wave.recommendedActions))}

                ${sectionsHtml}
                ${plutoHtml}

                <div class="grid grid-cols-2 gap-2 mt-3">
                    <button data-detail class="bg-astro hover:bg-astro-dark text-white font-bold py-2 rounded-lg text-xs">
                        <i class="fa-solid fa-arrow-right-long mr-1"></i> 詳しく見る
                    </button>
                    <button data-ask class="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-2 rounded-lg text-xs">
                        <i class="fa-solid fa-comment-dots mr-1"></i> AIに質問
                    </button>
                </div>
            </article>`;
    }

    _bindItemActions(item) {
        const cont = document.getElementById('forecast-selected');
        if (!cont) return;
        const detail = cont.querySelector('[data-detail]');
        const ask = cont.querySelector('[data-ask]');
        if (detail) detail.addEventListener('click', () => this.app.detail.openForForecast({ ...item, forecastType: this.forecastType }));
        if (ask) ask.addEventListener('click', () => {
            this.app.chat.setContext(`予報「${item.period} - ${item.theme}」について`);
            this.app.ui.switchTab('chat');
        });
    }

    _esc(s) {
        return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }
}

window.ForecastComponent = ForecastComponent;
