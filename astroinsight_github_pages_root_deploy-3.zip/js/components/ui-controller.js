/* ============================================================
 * AstroInsight - UI Controller（v5）
 * 要件§10 §21 §11 §12 §13：
 *   - 4タブ構成: today / forecast / compat / chat
 *   - 右上⚙ で settings 画面を開閉（タブとは独立）
 *   - 詳細画面は「右からスライドイン」、戻るで「左にスライドアウト」
 *   - オンボーディング画面の表示制御
 * ============================================================ */

class UIController {
    constructor(app) {
        this.app = app;
        this.activeTab = 'today';
    }

    setupEventListeners() {
        // チャットフォーム
        const cf = document.getElementById('chat-form');
        if (cf) cf.addEventListener('submit', (e) => this.app.handleChatSubmit(e));
        // 詳細画面の閉じる
        const closeBtn = document.getElementById('detail-close');
        if (closeBtn) closeBtn.addEventListener('click', () => this.closeDetail());
        // 設定画面の閉じる
        const sclose = document.getElementById('settings-close');
        if (sclose) sclose.addEventListener('click', () => this.closeSettings());
        // 詳細→チャット引継ぎ
        const askBtn = document.getElementById('detail-ask-ai');
        if (askBtn) askBtn.addEventListener('click', () => this.app.detail.askInChat());
        // 詳細→更新
        const refresh = document.getElementById('detail-refresh');
        if (refresh) refresh.addEventListener('click', () => this.app.detail.refresh());
        // 詳細→ホロスコープ表示モード切替
        const modeBtn = document.getElementById('detail-mode-toggle');
        if (modeBtn) modeBtn.addEventListener('click', () => this.app.detail.toggleMode());
    }

    /**
     * 管理画面の3つの開き方（要件§16 + ユーザー版仕様）：
     *   1) URL末尾 #admin
     *   2) 歯車アイコンを長押し（700ms）
     *   3) 通常設定内の「管理用設定を開く」ボタン
     * いずれも管理者ロール保有者のみ実行可能。
     */
    bindAdminTriggers() {
        // hash 監視
        window.addEventListener('hashchange', () => {
            if (location.hash === '#admin' && this.app.auth.isAdmin()) {
                this.openSettings();
                setTimeout(() => this.app.settings.openAdminPanel(), 200);
            }
        });
        // 歯車長押し
        const gear = document.querySelector('[data-action="open-settings"]');
        if (gear) {
            let timer = null;
            const start = () => { timer = setTimeout(() => {
                if (this.app.auth.isAdmin()) {
                    this.openSettings();
                    setTimeout(() => this.app.settings.openAdminPanel(), 200);
                }
            }, 700); };
            const cancel = () => { if (timer) clearTimeout(timer); timer = null; };
            gear.addEventListener('pointerdown', start);
            ['pointerup', 'pointerleave', 'pointercancel'].forEach((ev) => gear.addEventListener(ev, cancel));
        }
    }

    /** タブ切替（要件§10 §21 フェードイン） */
    switchTab(id) {
        this.activeTab = id;
        document.querySelectorAll('.tab-content').forEach((el) => {
            el.classList.remove('active');
            el.classList.add('hidden');
        });
        const target = document.getElementById(`tab-${id}`);
        if (target) {
            target.classList.add('active');
            target.classList.remove('hidden');
        }
        document.querySelectorAll('.nav-btn').forEach((btn) => btn.classList.remove('active-nav'));
        const map = { today: 0, forecast: 1, compat: 2, chat: 3 };
        if (map[id] !== undefined) {
            const btns = document.querySelectorAll('.nav-btn');
            if (btns[map[id]]) btns[map[id]].classList.add('active-nav');
        }
        // タブ別にプリフェッチ（要件§17）
        if (id === 'today' && this.app.forecast) this.app.forecast.prefetchMonthlyInBackground();
    }

    // ---- 詳細画面（要件§11 §12 §13: 右からスライドイン） ----
    openDetail() {
        const el = document.getElementById('detail-screen');
        if (!el) return;
        el.classList.remove('hidden');
        requestAnimationFrame(() => el.classList.add('slide-in-active'));
    }
    closeDetail() {
        const el = document.getElementById('detail-screen');
        if (!el) return;
        el.classList.remove('slide-in-active');
        setTimeout(() => el.classList.add('hidden'), 250);
        if (this.app.detail) this.app.detail.onClose();
    }

    // ---- 設定画面（要件§15 ⚙アイコン） ----
    openSettings() {
        const el = document.getElementById('settings-screen');
        if (!el) return;
        el.classList.remove('hidden');
        requestAnimationFrame(() => el.classList.add('slide-in-active'));
    }
    closeSettings() {
        const el = document.getElementById('settings-screen');
        if (!el) return;
        el.classList.remove('slide-in-active');
        setTimeout(() => el.classList.add('hidden'), 250);
    }

    // ---- オンボーディング（要件§9 全画面） ----
    showOnboarding() {
        const el = document.getElementById('onboarding-screen');
        if (el) el.classList.remove('hidden');
    }
    hideOnboarding() {
        const el = document.getElementById('onboarding-screen');
        if (el) el.classList.add('hidden');
    }

    // ---- チャットバブル ----
    appendChatBubble(role, text) {
        const c = document.getElementById('chat-messages');
        if (!c) return;
        const div = document.createElement('div');
        div.className = `flex ${role === 'user' ? 'justify-end' : 'justify-start'}`;
        const b = document.createElement('div');
        b.className = `px-4 py-3 max-w-[85%] text-sm leading-relaxed ${
            role === 'user' ? 'chat-user' : 'chat-ai'
        }`;
        if (role === 'model') b.innerHTML = marked.parse(text);
        else b.textContent = text;
        div.appendChild(b);
        c.appendChild(div);
        c.scrollTop = c.scrollHeight;
    }

    /** 予報の粒度切替（要件§12） */
    setForecastTab(type) {
        this.app.forecast.forecastType = type;
        ['monthly', 'weekly', 'daily', 'hourly'].forEach((t) => {
            const btn = document.getElementById(`fc-btn-${t}`);
            if (!btn) return;
            if (t === type) {
                btn.classList.add('active', 'bg-astro', 'text-white');
                btn.classList.remove('bg-white', 'text-slate-600');
            } else {
                btn.classList.remove('active', 'bg-astro', 'text-white');
                btn.classList.add('bg-white', 'text-slate-600');
            }
        });
        this.app.forecast.load();
    }

    /** 今日のセグメント（要件§11） */
    setTodaySegment(type) {
        this.app.today.segment = type;
        ['day', 'week', 'month'].forEach((t) => {
            const btn = document.getElementById(`today-seg-${t}`);
            if (!btn) return;
            if (t === type) {
                btn.classList.add('active', 'bg-astro', 'text-white');
                btn.classList.remove('bg-white', 'text-slate-600');
            } else {
                btn.classList.remove('active', 'bg-astro', 'text-white');
                btn.classList.add('bg-white', 'text-slate-600');
            }
        });
        this.app.today.load();
    }
}

window.UIController = UIController;
