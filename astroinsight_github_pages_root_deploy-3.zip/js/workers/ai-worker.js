/* ============================================================
 * AstroInsight - AI Generation Web Worker（v6）
 * 要件§17 §20：
 *   - Web WorkerでSSEストリーミング
 *   - チャンクごとにリアルタイム描画
 *
 * 要件§20 リクエストルーティング:
 *   - ログイン済み + プロキシ対応モデル → Cloudflareプロキシ経由（トークン認証）
 *   - 未ログイン or プロキシ非対応モデル → 直接APIリクエスト（プロバイダー単位APIキー認証）
 *
 * payload:
 *   {
 *     action: 'generate',
 *     apiKey: '...',                  // プロバイダー単位のAPIキー
 *     model: 'gemini-2.5-flash',
 *     modelMeta: { provider, providerId, endpoint, proxySupported },
 *     prompt: '...',
 *     isJson: false,
 *     proxy: { url, headers, token } | null,
 *     ai: { maxTokens, temperature, topP, streaming }
 *   }
 *
 * SSEパース・チャンク送信ロジックは v5 を踏襲。
 * Anthropic / Google / OpenAI / xAI に対応。
 * ============================================================ */

self.onmessage = async function (e) {
    const { action, apiKey, model, modelMeta, prompt, isJson, proxy, ai } = e.data;
    if (action !== 'generate') return;

    const aiOpts = ai || {};
    const maxTokens = aiOpts.maxTokens || 4500;
    const temperature = (aiOpts.temperature != null) ? aiOpts.temperature : 0.85;
    const topP = (aiOpts.topP != null) ? aiOpts.topP : 0.9;

    try {
        let url, headers, body;
        // --- provider 決定 ---
        let provider = modelMeta && (modelMeta.provider || modelMeta.providerId) ? (modelMeta.provider || modelMeta.providerId) : null;
        if (!provider) {
            if (model.startsWith('gemini')) provider = 'google';
            else if (model.startsWith('claude')) provider = 'anthropic';
            else if (model.startsWith('gpt') || model.startsWith('o1') || model.startsWith('o3')) provider = 'openai';
            else if (model.startsWith('grok')) provider = 'xai';
            else provider = 'openai';
        }

        if (proxy && proxy.url) {
            // ---- Cloudflareプロキシ経由（要件§5） ----
            url = proxy.url;
            headers = Object.assign({ 'Content-Type': 'application/json' }, proxy.headers || {});
            body = JSON.stringify({
                provider, model, prompt,
                stream: true,
                max_tokens: maxTokens, temperature, top_p: topP
            });
        } else if (provider === 'google') {
            const baseEndpoint =
                (modelMeta && modelMeta.endpoint) ||
                'https://generativelanguage.googleapis.com/v1beta/models/' + model + ':streamGenerateContent';
            const sep = baseEndpoint.includes('?') ? '&' : '?';
            url = baseEndpoint + sep + 'alt=sse&key=' + apiKey;
            headers = { 'Content-Type': 'application/json' };
            body = JSON.stringify({
                contents: [{ parts: [{ text: prompt }] }],
                generationConfig: { maxOutputTokens: maxTokens, temperature, topP }
            });
        } else if (provider === 'openai') {
            url = (modelMeta && modelMeta.endpoint) || 'https://api.openai.com/v1/chat/completions';
            headers = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + apiKey };
            body = JSON.stringify({
                model, messages: [{ role: 'user', content: prompt }], stream: true,
                max_tokens: maxTokens, temperature, top_p: topP
            });
        } else if (provider === 'xai') {
            url = (modelMeta && modelMeta.endpoint) || 'https://api.x.ai/v1/chat/completions';
            headers = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + apiKey };
            body = JSON.stringify({
                model, messages: [{ role: 'user', content: prompt }], stream: true,
                max_tokens: maxTokens, temperature, top_p: topP
            });
        } else if (provider === 'anthropic') {
            url = (modelMeta && modelMeta.endpoint) || 'https://api.anthropic.com/v1/messages';
            headers = {
                'Content-Type': 'application/json',
                'x-api-key': apiKey,
                'anthropic-version': '2023-06-01',
                'anthropic-dangerously-allow-browser': 'true'
            };
            body = JSON.stringify({
                model, max_tokens: maxTokens, temperature, top_p: topP,
                messages: [{ role: 'user', content: prompt }], stream: true
            });
        } else {
            throw new Error('未対応のプロバイダー: ' + provider);
        }

        const response = await fetch(url, { method: 'POST', headers, body });
        if (!response.ok) {
            const errBody = await response.text().catch(() => '');
            throw new Error('API Error: ' + response.status + (errBody ? ' / ' + errBody.slice(0, 300) : ''));
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder('utf-8');
        let fullText = '';
        let buffer = '';

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split(/\r?\n/);
            buffer = lines.pop();
            for (let line of lines) {
                line = line.trim();
                if (line.startsWith('data: ') && line !== 'data: [DONE]') {
                    const dataStr = line.substring(6).trim();
                    try {
                        const data = JSON.parse(dataStr);
                        let chunk = '';
                        // プロキシ経由の場合は { chunk: "..." } 形式を想定（実装依存）
                        if (proxy && proxy.url && typeof data.chunk === 'string') {
                            chunk = data.chunk;
                        } else if (provider === 'google' && data.candidates?.[0]?.content?.parts?.[0]?.text) {
                            chunk = data.candidates[0].content.parts[0].text;
                        } else if ((provider === 'openai' || provider === 'xai') &&
                                   data.choices?.[0]?.delta?.content) {
                            chunk = data.choices[0].delta.content;
                        } else if (provider === 'anthropic' &&
                                   data.type === 'content_block_delta' && data.delta?.text) {
                            chunk = data.delta.text;
                        }
                        if (chunk) {
                            fullText += chunk;
                            if (!isJson) self.postMessage({ type: 'chunk', text: fullText });
                        }
                    } catch (err) { /* JSONパース失敗（ヘッダ行等）は無視 */ }
                }
            }
        }
        if (!fullText) throw new Error('応答データが空でした。');
        self.postMessage({ type: 'done', text: fullText });
    } catch (error) {
        self.postMessage({ type: 'error', message: error.message });
    }
};
