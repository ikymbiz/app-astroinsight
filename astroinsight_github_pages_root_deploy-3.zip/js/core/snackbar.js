/* ============================================================
 * AstroInsight - Snackbar（v5）
 * 要件§17：
 *   - タブバーの上部に表示。
 *   - 「今日の運勢を生成中…」などタスク名を表示。
 *   - 完了 → 「✓ 更新しました」（2秒で自動消去）
 *   - 失敗 → 「再試行」ボタン付きエラートースト
 *   - 全画面ブロックオーバーレイは廃止 → 操作はブロックしない
 *   - 複数タスク同時並列に対応。
 * ============================================================ */

class Snackbar {
    constructor(containerId = 'snackbar-host') {
        this.containerId = containerId;
        this.tasks = new Map();
    }

    _host() {
        let el = document.getElementById(this.containerId);
        if (!el) {
            el = document.createElement('div');
            el.id = this.containerId;
            // タブバー(高さ約64px)の上に配置
            el.className =
                'fixed left-0 right-0 z-30 flex flex-col gap-2 px-3 pointer-events-none';
            el.style.bottom = 'calc(64px + env(safe-area-inset-bottom))';
            document.body.appendChild(el);
        }
        return el;
    }

    /** タスク開始 → タスクID返却 */
    start(taskId, label) {
        const host = this._host();
        const node = document.createElement('div');
        node.className =
            'pointer-events-auto bg-slate-800/95 text-white text-sm rounded-xl px-4 py-3 shadow-lg flex items-center gap-3';
        node.innerHTML = `
            <i class="fa-solid fa-circle-notch animate-spin text-astro-light"></i>
            <span class="flex-1">${this._esc(label)}</span>
        `;
        host.appendChild(node);
        this.tasks.set(taskId, { node, label });
        return taskId;
    }

    /** ラベルだけ更新 */
    update(taskId, label) {
        const t = this.tasks.get(taskId);
        if (!t) return;
        const span = t.node.querySelector('span');
        if (span) span.textContent = label;
        t.label = label;
    }

    /** 成功完了。2秒で消す */
    succeed(taskId, label) {
        const t = this.tasks.get(taskId);
        if (!t) return;
        t.node.className =
            'pointer-events-auto bg-emerald-600 text-white text-sm rounded-xl px-4 py-3 shadow-lg flex items-center gap-3';
        t.node.innerHTML = `<i class="fa-solid fa-circle-check"></i><span class="flex-1">${this._esc(
            label || '更新しました'
        )}</span>`;
        setTimeout(() => this._remove(taskId), 2000);
    }

    /** 失敗。再試行ボタン付き */
    fail(taskId, message, retryFn) {
        const t = this.tasks.get(taskId);
        if (!t) return;
        t.node.className =
            'pointer-events-auto bg-red-600 text-white text-sm rounded-xl px-4 py-3 shadow-lg flex items-center gap-3';
        const escMsg = this._esc(message || 'エラーが発生しました');
        t.node.innerHTML = `
            <i class="fa-solid fa-triangle-exclamation"></i>
            <span class="flex-1">${escMsg}</span>
            <button class="bg-white/20 hover:bg-white/30 px-3 py-1 rounded-lg text-xs font-bold">再試行</button>
            <button class="text-white/80 hover:text-white text-lg leading-none">×</button>
        `;
        const [retryBtn, closeBtn] = t.node.querySelectorAll('button');
        retryBtn.addEventListener('click', () => {
            this._remove(taskId);
            if (typeof retryFn === 'function') retryFn();
        });
        closeBtn.addEventListener('click', () => this._remove(taskId));
    }

    /** 即時消去 */
    _remove(taskId) {
        const t = this.tasks.get(taskId);
        if (!t) return;
        t.node.remove();
        this.tasks.delete(taskId);
    }

    _esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }
}

window.Snackbar = Snackbar;
