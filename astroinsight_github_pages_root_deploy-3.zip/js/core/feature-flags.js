/* ============================================================
 * AstroInsight - Feature Flags（v6）
 * 要件§3 §16 §22 を実装：
 *   - ADS_ENABLED(uid): 広告表示の一括ON/OFF。管理者は常にfalse。
 *   - PREMIUM_ENABLED(uid): スタブ。app-config.premium.enabled を返す。
 *   - app-config.json から値を読み、管理画面で上書き可能。
 *
 * 管理可能な変数（要件§16）:
 *   - ai.maxTokens, ai.temperature, ai.topP
 *   - limits.guestTrialLimit
 *   - ads.enabled
 *   - premium.enabled
 *   - app.name, app.description, ui.themeColor
 *   - cache.ttlSeconds
 *   - proxy.baseUrl
 *   - firebase.{apiKey,authDomain,projectId}
 * ============================================================ */

class FeatureFlags {
    constructor(db, auth, config) {
        this.db = db;
        this.auth = auth;
        this.config = config;
        this.flags = this._defaults();
    }

    _defaults() {
        return {
            ads_enabled: true,
            premium_enabled: true,
            guest_trial_max: 3,
            ai_max_tokens: 4500,
            ai_temperature: 0.85,
            ai_top_p: 0.9,
            ai_streaming: true,
            app_name: 'AstroInsight',
            app_description: '星の波を読むAI占星術アプリ',
            theme_color: '#7c3aed',
            cache_ttl_seconds: 60 * 60 * 24 * 7,
            cache_enabled: true
        };
    }

    /** app-config.json + 管理者上書きを反映（要件§16） */
    async load() {
        const ac = (this.config && this.config.getAppConfig && this.config.getAppConfig()) || {};
        // app-config.json の値を flag に展開
        const loaded = {
            ads_enabled: ac.ads?.enabled ?? true,
            premium_enabled: ac.premium?.enabled ?? true,
            guest_trial_max: ac.limits?.guestTrialLimit ?? 3,
            ai_max_tokens: ac.ai?.maxTokens ?? 4500,
            ai_temperature: ac.ai?.temperature ?? 0.85,
            ai_top_p: ac.ai?.topP ?? 0.9,
            ai_streaming: ac.ai?.streaming ?? true,
            app_name: ac.app?.name ?? 'AstroInsight',
            app_description: ac.app?.description ?? '',
            theme_color: ac.ui?.themeColor ?? '#7c3aed',
            cache_ttl_seconds: ac.cache?.ttlSeconds ?? 60 * 60 * 24 * 7,
            cache_enabled: ac.cache?.enabled ?? true
        };
        // 個別上書きが auth/feature_flags にあれば優先（要件§16 即時反映）
        const adminOverride = (await this.db.getRaw('auth', 'feature_flags')) || {};
        this.flags = Object.assign(this._defaults(), loaded, adminOverride);
        // 試用回数上限を auth サービスからも参照できるように共有
        if (this.auth) await this.db.setRaw('auth', 'guest_trial_max', this.flags.guest_trial_max);
    }

    /** 管理者画面から保存（即時反映） */
    async save(partial) {
        const cur = (await this.db.getRaw('auth', 'feature_flags')) || {};
        const next = Object.assign({}, cur, partial);
        await this.db.setRaw('auth', 'feature_flags', next);
        await this.load();
    }

    get(key) { return this.flags[key]; }

    /** 要件§3 ADS_ENABLED(uid) - 管理者は常にfalse */
    ADS_ENABLED(uid) {
        if (this.auth?.isAdmin && this.auth.isAdmin()) return false;
        return !!this.flags.ads_enabled;
    }

    /** 要件§3 §22 PREMIUM_ENABLED(uid) スタブ。常にtrue（全機能を全ユーザーに開放） */
    PREMIUM_ENABLED(uid) {
        return !!this.flags.premium_enabled;
    }
}

window.FeatureFlags = FeatureFlags;
