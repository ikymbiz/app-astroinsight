/* ============================================================
 * AstroInsight - Proxy Service（v5）
 * 要件§5 を実装する：
 *   - ログイン後、Cloudflare Worker に UID を送信してトークンを取得 → IndexedDBに保存。
 *   - AIリクエスト時、プロキシ対応モデルでログイン済みなら、プロキシエンドポイントを使う。
 *   - プロキシ使用時は APIキー不要（トークンのみ送信）。
 *   - プロキシエンドポイントのベースURLは管理者設定画面で設定。
 *   - トークン失効時は自動再取得を試みる、失敗時はエラートースト。
 *
 * ※ 実Cloudflare Workerは管理者がベースURLを設定してから動作する。
 *   未設定時はスタブとしてプロキシ非経由（直接APIキー）で動作する（要件§2 未ログイン時と同じ）。
 * ============================================================ */

class ProxyService {
    /**
     * @param {AstroDB} db
     */
    constructor(db) {
        this.db = db;
        this.baseUrl = null; // 管理者設定で入る
        this.token = null;
    }

    async init() {
        const adminCfg = (await this.db.getRaw('auth', 'admin_config')) || {};
        this.baseUrl = adminCfg.proxy_base_url || null;
        // ログイン済みユーザーの保存トークンを復元
        const tk = await this.db.getRaw('auth', 'proxy_token');
        if (tk) this.token = tk;
    }

    /** 設定有無 */
    isConfigured() {
        return !!this.baseUrl;
    }

    /** ベースURLの動的更新（管理者設定画面から） */
    async setBaseUrl(url) {
        const adminCfg = (await this.db.getRaw('auth', 'admin_config')) || {};
        adminCfg.proxy_base_url = url;
        await this.db.setRaw('auth', 'admin_config', adminCfg);
        this.baseUrl = url;
    }

    /** UIDからトークン取得（要件§5） */
    async fetchToken(uid) {
        if (!this.baseUrl) return null;
        try {
            const res = await fetch(this.baseUrl.replace(/\/$/, '') + '/auth/token', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ uid })
            });
            if (!res.ok) throw new Error('proxy token: ' + res.status);
            const data = await res.json();
            this.token = data.token;
            await this.db.setRaw('auth', 'proxy_token', this.token);
            return this.token;
        } catch (e) {
            console.warn('[Proxy] トークン取得失敗:', e.message);
            return null;
        }
    }

    async clearToken() {
        this.token = null;
        await this.db.deleteRaw('auth', 'proxy_token');
    }

    /**
     * AIリクエストをプロキシ経由でルーティング可能かを判定（要件§20 ルーティング）。
     * @param {Object} modelMeta - { provider, proxySupported }
     * @param {boolean} loggedIn
     */
    canUseProxy(modelMeta, loggedIn) {
        return !!(loggedIn && this.baseUrl && this.token && modelMeta?.proxySupported);
    }

    /**
     * プロキシ用のエンドポイントとヘッダを返す。
     * @param {Object} modelMeta
     */
    buildProxyRequest(modelMeta) {
        if (!this.canUseProxy(modelMeta, true)) return null;
        return {
            url: this.baseUrl.replace(/\/$/, '') + '/v1/' + modelMeta.provider + '/generate',
            headers: {
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.token
            }
        };
    }
}

window.ProxyService = ProxyService;
