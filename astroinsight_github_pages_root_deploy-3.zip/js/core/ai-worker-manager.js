/* ============================================================
 * AstroInsight - AI Worker Manager（v5）
 * 要件§17：複数タスクを同時並列実行、キューで管理。
 *
 * 設計：
 *   - タスクIDごとに専用のWorkerインスタンスを生成し、終了時に破棄する。
 *     （全Workerに同じonmessage配信だと相互干渉するため、簡潔のためタスク=1Worker）
 *   - 上限を設定し、超えた分はキューイング。
 * ============================================================ */

class AIWorkerManager {
    constructor(workerPath = './js/workers/ai-worker.js', maxConcurrent = 4) {
        this.workerPath = workerPath;
        this.maxConcurrent = maxConcurrent;
        this.active = new Map(); // taskId -> { worker, handlers }
        this.queue = [];
    }

    /**
     * 並列タスクとして送信。
     * @param {string} taskId
     * @param {Object} payload  - { apiKey, model, modelMeta, prompt, isJson, proxy }
     * @param {Object} handlers - { onChunk, onDone, onError }
     */
    submit(taskId, payload, handlers = {}) {
        const task = { taskId, payload, handlers };
        if (this.active.size >= this.maxConcurrent) {
            this.queue.push(task);
            return;
        }
        this._run(task);
    }

    _run(task) {
        const { taskId, payload, handlers } = task;
        let worker;
        try {
            worker = new Worker(this.workerPath);
        } catch (e) {
            this._runFromBlob(task);
            return;
        }
        this.active.set(taskId, { worker, handlers });
        worker.onmessage = (e) => this._dispatch(taskId, e.data);
        worker.onerror = (e) => this._dispatch(taskId, { type: 'error', message: e.message || 'Worker error' });
        worker.postMessage({ action: 'generate', ...payload });
    }

    async _runFromBlob(task) {
        const { taskId, payload, handlers } = task;
        try {
            const res = await fetch(this.workerPath);
            const code = await res.text();
            const blob = new Blob([code], { type: 'application/javascript' });
            const worker = new Worker(URL.createObjectURL(blob));
            this.active.set(taskId, { worker, handlers });
            worker.onmessage = (e) => this._dispatch(taskId, e.data);
            worker.onerror = (e) => this._dispatch(taskId, { type: 'error', message: e.message || 'Worker error' });
            worker.postMessage({ action: 'generate', ...payload });
        } catch (e) {
            handlers.onError && handlers.onError({ type: 'error', message: 'Worker起動失敗: ' + e.message });
        }
    }

    _dispatch(taskId, msg) {
        const ent = this.active.get(taskId);
        if (!ent) return;
        if (msg.type === 'chunk') {
            ent.handlers.onChunk && ent.handlers.onChunk(msg);
        } else if (msg.type === 'done') {
            ent.handlers.onDone && ent.handlers.onDone(msg);
            this._terminate(taskId);
        } else if (msg.type === 'error') {
            ent.handlers.onError && ent.handlers.onError(msg);
            this._terminate(taskId);
        }
    }

    _terminate(taskId) {
        const ent = this.active.get(taskId);
        if (!ent) return;
        try { ent.worker.terminate(); } catch (e) {}
        this.active.delete(taskId);
        if (this.queue.length && this.active.size < this.maxConcurrent) {
            const next = this.queue.shift();
            this._run(next);
        }
    }
}

window.AIWorkerManager = AIWorkerManager;
