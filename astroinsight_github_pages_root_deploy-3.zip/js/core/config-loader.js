/* ============================================================
 * AstroInsight - Config Loader（v6）
 * 要件§4 §6 §16 を実装：
 *   - app-config.json / models.json / prompts.json を読み込み、
 *     IndexedDBに保存されたカスタム設定とマージしてアプリに提供。
 *   - models.json は providers + models + presets の3配列構造（v6）。
 *   - APIキーは「プロバイダー単位」で保存・取得する。
 *     キー名: provider_{providerId}_api_key
 *   - 管理画面で保存された設定（admin_models_config / admin_prompts_config /
 *     admin_app_config）が存在する場合はそれを優先（要件§16）。
 * ============================================================ */

class ConfigLoader {
    /**
     * @param {AstroDB} db
     * @param {Object} opts - { modelsPath, promptsPath, appConfigPath }
     */
    constructor(db, opts = {}) {
        this.db = db;
        this.modelsPath = opts.modelsPath || './js/config/models.json';
        this.promptsPath = opts.promptsPath || './js/config/prompts.json';
        this.appConfigPath = opts.appConfigPath || './js/config/app-config.json';
        this.defaultModelsConfig = { defaultModelId: '', providers: [], models: [], presets: [] };
        this.defaultPrompts = { prompts: {}, core_constraint: '' };
        this.defaultAppConfig = {};
        this.coreConstraint = '';
    }

    /** デフォルトJSONをfetch（要件§4 §6 §16） */
    async loadDefaults() {
        // 管理画面で保存された JSON があれば優先（要件§16「変数はFirestoreまたはCloudflare KVに保存」のローカル代替）
        const adminAppCfg = await this.db.getRaw('auth', 'admin_app_config');
        const adminModels = await this.db.getRaw('auth', 'admin_models_config');
        const adminPrompts = await this.db.getRaw('auth', 'admin_prompts_config');

        try {
            const tasks = [];
            if (!adminModels) tasks.push(fetch(this.modelsPath, { cache: 'no-cache' }).then((r) => r.ok ? r.json() : null).catch(() => null));
            else tasks.push(Promise.resolve(null));
            if (!adminPrompts) tasks.push(fetch(this.promptsPath, { cache: 'no-cache' }).then((r) => r.ok ? r.json() : null).catch(() => null));
            else tasks.push(Promise.resolve(null));
            if (!adminAppCfg) tasks.push(fetch(this.appConfigPath, { cache: 'no-cache' }).then((r) => r.ok ? r.json() : null).catch(() => null));
            else tasks.push(Promise.resolve(null));
            const [m, p, a] = await Promise.all(tasks);

            this.defaultModelsConfig = adminModels || m || this.defaultModelsConfig;
            this.defaultPrompts = adminPrompts || p || this.defaultPrompts;
            this.defaultAppConfig = adminAppCfg || a || this.defaultAppConfig;
            this.coreConstraint = this.defaultPrompts.core_constraint || '';
        } catch (e) {
            console.error('[ConfigLoader] デフォルト設定の読み込みに失敗:', e);
        }
    }

    /** プロバイダー一覧（要件§4 §16） */
    getProviders() {
        return this.defaultModelsConfig.providers || [];
    }

    /** プロバイダーをIDで検索 */
    getProviderById(id) {
        return this.getProviders().find((p) => p.id === id) || null;
    }

    /** プロバイダー単位のAPIキー取得（要件§4 ユーザー版仕様） */
    async getProviderApiKey(providerId) {
        const bag = (await this.db.getRaw('auth', 'provider_api_keys')) || {};
        if (bag[providerId]) return bag[providerId];
        const storageKey = `provider_${providerId}_api_key`;
        return (await this.db.getRaw('auth', storageKey)) || '';
    }

    /** プロバイダー単位のAPIキー保存（要件§4 ユーザー版仕様） */
    async setProviderApiKey(providerId, value) {
        const bag = (await this.db.getRaw('auth', 'provider_api_keys')) || {};
        if (value) bag[providerId] = value; else delete bag[providerId];
        await this.db.setRaw('auth', 'provider_api_keys', bag);
        const storageKey = `provider_${providerId}_api_key`;
        if (value) await this.db.setRaw('auth', storageKey, value);
        else await this.db.deleteRaw('auth', storageKey);
    }

    /** カスタムモデル＋デフォルトモデル＋非表示フラグを統合した一覧（要件§4 §15） */
    async getMergedModels() {
        const customModels = (await this.db.get('custom_models')) || [];
        const hiddenIds = (await this.db.get('hidden_default_models')) || [];
        const allDefaults = this.defaultModelsConfig.models || [];
        const visibleDefaults = allDefaults.filter((m) => !hiddenIds.includes(m.id) && m.enabled !== false);
        const customIds = new Set(customModels.map((m) => m.id));
        return [
            ...visibleDefaults.filter((m) => !customIds.has(m.id)),
            ...customModels
        ];
    }

    getAllDefaultModels() {
        return (this.defaultModelsConfig.models || []).slice();
    }

    getPresets() {
        return this.defaultModelsConfig.presets || [];
    }

    /** カスタムモデル追加（要件§4 §15） */
    async addCustomModel(model) {
        if (!model || !model.id || !model.name) throw new Error('モデルID・表示名は必須');
        const customModels = (await this.db.get('custom_models')) || [];
        const idx = customModels.findIndex((m) => m.id === model.id);
        if (idx >= 0) customModels[idx] = model;
        else customModels.push(model);
        await this.db.set('custom_models', customModels);
    }

    async removeCustomModel(id) {
        const customModels = (await this.db.get('custom_models')) || [];
        const filtered = customModels.filter((m) => m.id !== id);
        await this.db.set('custom_models', filtered);
    }

    async toggleDefaultHidden(id) {
        const hiddenIds = (await this.db.get('hidden_default_models')) || [];
        const i = hiddenIds.indexOf(id);
        if (i >= 0) hiddenIds.splice(i, 1);
        else hiddenIds.push(id);
        await this.db.set('hidden_default_models', hiddenIds);
        return hiddenIds.includes(id);
    }

    /** 機能キー指定でシステムプロンプトを取得（要件§6） */
    async getPrompt(key) {
        const userPrompts = (await this.db.get('user_prompts')) || {};
        if (userPrompts[key] && userPrompts[key].trim()) return this._appendCore(userPrompts[key]);
        const def = this.defaultPrompts.prompts?.[key];
        return this._appendCore(def?.default || def?.system || '');
    }

    _appendCore(text) {
        if (!this.coreConstraint) return text;
        if (!text) return this.coreConstraint;
        return `${text}\n\n${this.coreConstraint}`;
    }

    getAllPromptDefs() {
        return this.defaultPrompts.prompts || {};
    }

    async saveUserPrompt(key, value) {
        const userPrompts = (await this.db.get('user_prompts')) || {};
        userPrompts[key] = value;
        await this.db.set('user_prompts', userPrompts);
    }

    async resetUserPrompt(key) {
        const userPrompts = (await this.db.get('user_prompts')) || {};
        delete userPrompts[key];
        await this.db.set('user_prompts', userPrompts);
    }

    /** 全機能の現在のプロンプト */
    async getAllCurrentPrompts() {
        const result = {};
        const defs = this.getAllPromptDefs();
        const userPrompts = (await this.db.get('user_prompts')) || {};
        for (const k of Object.keys(defs)) {
            const userVal = userPrompts[k];
            const defVal = defs[k]?.default || defs[k]?.system || '';
            result[k] = {
                label: defs[k].label || defs[k].name || k,
                description: defs[k].description || '',
                value: userVal || defVal,
                isCustom: !!userVal
            };
        }
        return result;
    }

    /** モデルIDから完全な定義を取得 */
    async getModelById(id) {
        const merged = await this.getMergedModels();
        const m = merged.find((x) => x.id === id);
        if (!m) return null;
        // providerId → provider 名のフォールバック付与
        if (!m.provider && m.providerId) m.provider = m.providerId;
        // endpoint 未設定なら provider の baseUrl + path から組み立て
        if (!m.endpoint && m.path) {
            const prov = this.getProviderById(m.providerId || m.provider);
            if (prov) m.endpoint = prov.baseUrl.replace(/\/$/, '') + m.path;
        }
        return m;
    }

    getCoreConstraint() {
        return this.coreConstraint;
    }

    /** app-config.json 全体 */
    getAppConfig() {
        return this.defaultAppConfig || {};
    }

    /** 管理画面JSON保存（要件§16） */
    async saveAdminAppConfig(obj) { await this.db.setRaw('auth', 'admin_app_config', obj); this.defaultAppConfig = obj; }
    async saveAdminModelsConfig(obj) { await this.db.setRaw('auth', 'admin_models_config', obj); this.defaultModelsConfig = obj; }
    async saveAdminPromptsConfig(obj) { await this.db.setRaw('auth', 'admin_prompts_config', obj); this.defaultPrompts = obj; this.coreConstraint = obj.core_constraint || ''; }
}

window.ConfigLoader = ConfigLoader;
