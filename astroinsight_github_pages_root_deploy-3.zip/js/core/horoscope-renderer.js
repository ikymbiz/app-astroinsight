/* ============================================================
 * AstroInsight - Horoscope Renderer (SVG)（v5）
 * 要件§8 を実装する：
 *   - 円形12ハウス構造
 *   - 各天体をシンボル (☉☽☿♀♂♃♄♅♆♇) で配置
 *   - アスペクトライン（合0/対180/トライン120/スクエア90/セクスタイル60）を色分け
 *   - ネイタル単独 ↔ ネイタル＋トランジット二重円を切替
 *   - 天体タップでツールチップ：
 *       天体名(日本語+英語)+シンボル / 現在のサイン・度数 / 位置するハウス /
 *       天体の基本的な意味 / そのサイン・ハウスにある場合の解説 /
 *       主要アスペクトと影響
 * ============================================================ */

class HoroscopeRenderer {
    /**
     * @param {SVGElement} svgEl
     * @param {Object} opts - { size: number, onPlanetTap: (planetKey)=>void }
     */
    constructor(svgEl, opts = {}) {
        this.svg = svgEl;
        this.size = opts.size || 320;
        this.onPlanetTap = opts.onPlanetTap || (() => {});
        this.mode = 'natal'; // 'natal' | 'dual'
        this.chartA = null; // 内側（自分/ネイタル）
        this.chartB = null; // 外側（相手/トランジット）
        this.aspects = [];
        this.selected = null; // 選択中の天体キー
    }

    setCharts(chartA, chartB = null, mode = 'natal') {
        this.chartA = chartA;
        this.chartB = chartB;
        this.mode = mode;
        this._computeAspects();
        this.render();
    }

    setMode(mode) {
        this.mode = mode;
        this.render();
    }

    _computeAspects() {
        if (!this.chartA) { this.aspects = []; return; }
        const lonsA = {};
        for (const k of Object.keys(this.chartA.planets)) {
            lonsA[k] = this.chartA.planets[k].longitude;
        }
        if (this.mode === 'dual' && this.chartB) {
            const lonsB = {};
            for (const k of Object.keys(this.chartB.planets)) {
                lonsB[k] = this.chartB.planets[k].longitude;
            }
            this.aspects = AstrologyCompute.detectAspects(lonsA, lonsB, false);
        } else {
            this.aspects = AstrologyCompute.detectAspects(lonsA, lonsA, true);
        }
    }

    render() {
        const SVG_NS = 'http://www.w3.org/2000/svg';
        const size = this.size;
        const cx = size / 2, cy = size / 2;
        const rOuter = size * 0.48;
        const rZodiac = size * 0.42;
        const rInner = size * 0.30;
        const rPlanetA = size * 0.36; // 内側天体
        const rPlanetB = size * 0.46; // 外側天体（dual時）

        this.svg.setAttribute('viewBox', `0 0 ${size} ${size}`);
        this.svg.setAttribute('width', '100%');
        this.svg.setAttribute('height', size);
        while (this.svg.firstChild) this.svg.removeChild(this.svg.firstChild);

        if (!this.chartA) return;

        // 背景円
        const bg = document.createElementNS(SVG_NS, 'circle');
        bg.setAttribute('cx', cx); bg.setAttribute('cy', cy); bg.setAttribute('r', rOuter);
        bg.setAttribute('fill', '#fafaff'); bg.setAttribute('stroke', '#cbd5e1'); bg.setAttribute('stroke-width', 1);
        this.svg.appendChild(bg);

        // ハウス線（chartAのcuspsを基準に12分割）
        const cusps = this.chartA.cusps || [];
        for (let i = 0; i < 12; i++) {
            const ang = this._lonToAngle(cusps[i] || (i * 30));
            const x1 = cx + rInner * Math.cos(ang);
            const y1 = cy + rInner * Math.sin(ang);
            const x2 = cx + rOuter * Math.cos(ang);
            const y2 = cy + rOuter * Math.sin(ang);
            const line = document.createElementNS(SVG_NS, 'line');
            line.setAttribute('x1', x1); line.setAttribute('y1', y1);
            line.setAttribute('x2', x2); line.setAttribute('y2', y2);
            line.setAttribute('stroke', i === 0 ? '#4f46e5' : '#cbd5e1');
            line.setAttribute('stroke-width', i === 0 ? 2 : 1);
            this.svg.appendChild(line);

            // ハウス番号
            const houseAng = this._lonToAngle(((cusps[i] || (i * 30)) + 15) % 360);
            const hx = cx + (rInner + 8) * Math.cos(houseAng);
            const hy = cy + (rInner + 8) * Math.sin(houseAng);
            const t = document.createElementNS(SVG_NS, 'text');
            t.setAttribute('x', hx); t.setAttribute('y', hy);
            t.setAttribute('font-size', 10); t.setAttribute('fill', '#94a3b8');
            t.setAttribute('text-anchor', 'middle'); t.setAttribute('dominant-baseline', 'middle');
            t.textContent = (i + 1).toString();
            this.svg.appendChild(t);
        }

        // サイン記号
        const signs = AstrologyCompute.signSymbols();
        for (let i = 0; i < 12; i++) {
            const ang = this._lonToAngle(i * 30 + 15);
            const x = cx + (rZodiac + 6) * Math.cos(ang);
            const y = cy + (rZodiac + 6) * Math.sin(ang);
            const t = document.createElementNS(SVG_NS, 'text');
            t.setAttribute('x', x); t.setAttribute('y', y);
            t.setAttribute('font-size', 14); t.setAttribute('fill', '#64748b');
            t.setAttribute('text-anchor', 'middle'); t.setAttribute('dominant-baseline', 'middle');
            t.textContent = signs[i];
            this.svg.appendChild(t);
        }

        // 内輪
        const inner = document.createElementNS(SVG_NS, 'circle');
        inner.setAttribute('cx', cx); inner.setAttribute('cy', cy); inner.setAttribute('r', rInner);
        inner.setAttribute('fill', 'none'); inner.setAttribute('stroke', '#cbd5e1');
        this.svg.appendChild(inner);

        // アスペクトライン
        for (const a of this.aspects) {
            const lonA = (this.chartA.planets[a.p1] || {}).longitude;
            const lonB = this.mode === 'dual' && this.chartB
                ? (this.chartB.planets[a.p2] || {}).longitude
                : (this.chartA.planets[a.p2] || {}).longitude;
            if (lonA == null || lonB == null) continue;
            const ang1 = this._lonToAngle(lonA);
            const ang2 = this._lonToAngle(lonB);
            const x1 = cx + rInner * Math.cos(ang1);
            const y1 = cy + rInner * Math.sin(ang1);
            const x2 = cx + rInner * Math.cos(ang2);
            const y2 = cy + rInner * Math.sin(ang2);
            const ln = document.createElementNS(SVG_NS, 'line');
            ln.setAttribute('x1', x1); ln.setAttribute('y1', y1);
            ln.setAttribute('x2', x2); ln.setAttribute('y2', y2);
            ln.setAttribute('stroke', a.color); ln.setAttribute('stroke-width', 1);
            ln.setAttribute('opacity', 0.6);
            this.svg.appendChild(ln);
        }

        // 天体（A=内側）
        this._drawPlanets(this.chartA, rPlanetA, '#4f46e5', 'A');

        // 二重円モードならBも
        if (this.mode === 'dual' && this.chartB) {
            const ringB = document.createElementNS(SVG_NS, 'circle');
            ringB.setAttribute('cx', cx); ringB.setAttribute('cy', cy);
            ringB.setAttribute('r', rOuter * 0.93);
            ringB.setAttribute('fill', 'none'); ringB.setAttribute('stroke', '#fbbf24');
            ringB.setAttribute('stroke-dasharray', '3 3');
            this.svg.appendChild(ringB);
            this._drawPlanets(this.chartB, rPlanetB, '#f59e0b', 'B');
        }

        // ASC マーカー
        if (this.chartA.ASC != null) {
            const ang = this._lonToAngle(this.chartA.ASC);
            const x = cx + rOuter * Math.cos(ang);
            const y = cy + rOuter * Math.sin(ang);
            const t = document.createElementNS(SVG_NS, 'text');
            t.setAttribute('x', x - 4); t.setAttribute('y', y);
            t.setAttribute('font-size', 11); t.setAttribute('fill', '#4f46e5');
            t.setAttribute('font-weight', 'bold');
            t.setAttribute('text-anchor', 'end'); t.setAttribute('dominant-baseline', 'middle');
            t.textContent = 'ASC';
            this.svg.appendChild(t);
        }
    }

    /** 黄経 → SVG角度（ASCを左 = 9時方向 = 180°、反時計回り）*/
    _lonToAngle(lon) {
        // ホロスコープは ASC を左、黄経が反時計回りに増加
        const ascLon = (this.chartA && this.chartA.ASC) || 0;
        const rel = (((lon - ascLon) % 360) + 360) % 360;
        // SVG は時計回り、Y軸下向き → ASCを-X方向(180°)に置き、反時計回りに進める
        const deg = 180 - rel;
        return deg * Math.PI / 180;
    }

    _drawPlanets(chart, r, color, ringTag) {
        const SVG_NS = 'http://www.w3.org/2000/svg';
        const size = this.size;
        const cx = size / 2, cy = size / 2;
        for (const p of AstrologyCompute.planets()) {
            const pl = chart.planets[p.key];
            if (!pl) continue;
            const ang = this._lonToAngle(pl.longitude);
            const x = cx + r * Math.cos(ang);
            const y = cy + r * Math.sin(ang);
            // タップ領域（透明な大きめ円）
            const hit = document.createElementNS(SVG_NS, 'circle');
            hit.setAttribute('cx', x); hit.setAttribute('cy', y); hit.setAttribute('r', 13);
            hit.setAttribute('fill', 'rgba(255,255,255,0.001)');
            hit.style.cursor = 'pointer';
            hit.dataset.planet = p.key;
            hit.dataset.ring = ringTag;
            hit.addEventListener('click', (e) => {
                e.stopPropagation();
                this.selected = p.key;
                this.onPlanetTap(p.key, ringTag);
            });
            // 背景の小円
            const bg = document.createElementNS(SVG_NS, 'circle');
            bg.setAttribute('cx', x); bg.setAttribute('cy', y); bg.setAttribute('r', 11);
            bg.setAttribute('fill', '#fff');
            bg.setAttribute('stroke', this.selected === p.key ? '#ef4444' : color);
            bg.setAttribute('stroke-width', this.selected === p.key ? 2.5 : 1.5);
            // シンボル
            const sym = document.createElementNS(SVG_NS, 'text');
            sym.setAttribute('x', x); sym.setAttribute('y', y + 1);
            sym.setAttribute('font-size', 14); sym.setAttribute('fill', color);
            sym.setAttribute('text-anchor', 'middle');
            sym.setAttribute('dominant-baseline', 'middle');
            sym.textContent = p.symbol;
            this.svg.appendChild(bg);
            this.svg.appendChild(sym);
            this.svg.appendChild(hit);
        }
    }

    /** 選択中の天体ツールチップ用情報（要件§8 ツールチップ表示内容） */
    getTooltipInfo(planetKey, ring = 'A') {
        const chart = (ring === 'B' && this.chartB) ? this.chartB : this.chartA;
        if (!chart) return null;
        const pl = chart.planets[planetKey];
        if (!pl) return null;
        // 主要アスペクト
        const aspects = this.aspects.filter((a) => a.p1 === planetKey || a.p2 === planetKey);
        return {
            name_ja: pl.ja,
            name_en: pl.en,
            symbol: pl.symbol,
            sign: pl.signName,
            signSymbol: AstrologyCompute.signSymbols()[pl.signIndex],
            degInSign: pl.degInSign.toFixed(2),
            house: pl.house,
            meaning: pl.meaning,
            ring,
            aspects
        };
    }
}

window.HoroscopeRenderer = HoroscopeRenderer;
